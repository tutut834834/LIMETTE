import matplotlib
matplotlib.use('Agg')  # Use the non-GUI backend 'Agg' for rendering

from pprint import pprint
import scipy.stats
import numpy as np
import pandas as pd
import subprocess
import matplotlib.pyplot as plt

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector
from unfooling.pipeline import generate_explanations
from unfooling.pipeline import load_experiment_and_data
from unfooling.pipeline import compute_metrics

# Run setup_attacks.py script
subprocess.run(["python3", "unfooling/defense/setup_attacks.py"])

class C:  # Config
    experiment_name = 'COMPAS'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

P = load_experiment_and_data(C)

# Set up proportions
proportions = [0.1, 0.2, 0.3, 0.4, 0.5]

metrics_results = {
    'proportion': [],
    'fidelity_h_soft': [],
    'fidelity_h_hard': [],
    'cdf_Δ': [],
    'fidelity_CAD-DEFENSE': [],
    'infidelity_g_wrt_g': [],
}

# Assuming you have separate datasets for original and adversarial samples
X_train_original = P.X_train
y_train_original = P.y_train

# Generate adversarial examples
adversarial_data = generate_explanations(
    C, P,
    num_samples_explain=int(0.01 * len(P.X_train))  # 1% of the training samples
)

# Extracting LIME data and inspecting its structure
lime_data = adversarial_data.get('LIME')

if lime_data:
    print("Available model keys in LIME data:")
    pprint(lime_data.keys())

    # Let's inspect the first model's data
    for model_key in lime_data.keys():
        print(f"Inspecting data for model key: {model_key}")
        model_data = lime_data[model_key]
        pprint(model_data.keys())  # Inspect available keys for this model
        
        if 'X_samples' in model_data and 'y_samples_pred' in model_data:
            X_train_adversarial = model_data['X_samples']
            y_train_adversarial = model_data['y_samples_pred']
            break  # We found the data we needed, so we can exit the loop
    else:
        print("Could not find 'X_samples' or 'y_samples_pred' in any model data.")
        X_train_adversarial = None
        y_train_adversarial = None
else:
    print("Adversarial data generation failed. 'LIME' key not found in adversarial_data.")
    X_train_adversarial = None
    y_train_adversarial = None

if X_train_adversarial is not None and y_train_adversarial is not None:
    # Reshape the arrays to ensure they have the same number of dimensions
    if X_train_original.ndim == 1:
        X_train_original = X_train_original.reshape(-1, 1)
    if X_train_adversarial.ndim == 1:
        X_train_adversarial = X_train_adversarial.reshape(-1, 1)

    if y_train_original.ndim == 1:
        y_train_original = y_train_original.reshape(-1, 1)
    if y_train_adversarial.ndim == 1:
        y_train_adversarial = y_train_adversarial.reshape(-1, 1)

    for proportion in proportions:
        print(f"Evaluating with {proportion * 100}% original and {(1 - proportion) * 100}% adversarial data")
        
        # Combine the original and adversarial data here based on the `proportion`
        X_train_combined = np.concatenate([
            X_train_original[:int(proportion * len(X_train_original))],
            X_train_adversarial[:int((1 - proportion) * len(X_train_adversarial))]
        ])
        y_train_combined = np.concatenate([
            y_train_original[:int(proportion * len(y_train_original))],
            y_train_adversarial[:int((1 - proportion) * len(y_train_adversarial))]
        ])

        # Flatten y_train_combined to match expected input dimensions
        y_train_combined = y_train_combined.flatten()

        # Create new P object with combined data for evaluation
        P_combined = P._replace(X_train=X_train_combined, y_train=y_train_combined)

        # Incorporate the defense mechanism (e.g., ensemble adversarial training)
        # Pass the combined dataset to the detector, simulating adversarial defense
        hparams = dict(
            distance_agg='max',
            metric='minkowski',
            epsilon=0.1,
            n_neighbors=15,
            p=1,
            n_jobs=-1,
        )
        print(f'Using hparams for {C.detector_name}:')
        pprint(hparams)

        # Call evaluate_detector with the combined dataset
        results, detectors = evaluate_detector(C, P_combined, adversarial_data, hparams,
                                               n_explainer_samples=len(X_train_combined))

        # Get the metrics
        score = compute_metrics(results[0])

        # Print available keys in the score dictionary
        print("Available keys in score dictionary:")
        print(score.keys())

        # Collect metrics from the score dictionary based on the available keys
        metrics_results['proportion'].append(proportion)
        metrics_results['fidelity_h_soft'].append(score.get('fidelity_h_soft', np.nan))
        metrics_results['fidelity_h_hard'].append(score.get('fidelity_h_hard', np.nan))
        metrics_results['cdf_Δ'].append(score.get('cdf_Δ_expl_test', np.nan))
        metrics_results['fidelity_CAD-DEFENSE'].append(score.get('fidelity_CAD-DEFENSE', np.nan))
        metrics_results['infidelity_g_wrt_g'].append(score.get('infidelity_g_wrt_g', np.nan))

    # Convert results to a DataFrame for easy plotting
    df_metrics = pd.DataFrame(metrics_results)

    # Plotting the metrics
    fig, ax = plt.subplots(2, 2, figsize=(14, 10))

    ax[0, 0].plot(df_metrics['proportion'], df_metrics['fidelity_h_soft'], marker='o')
    ax[0, 0].set_title('Fidelity (soft) vs Original/Adversarial Proportion')
    ax[0, 0].set_xlabel('Original/Adversarial Proportion')
    ax[0, 0].set_ylabel('Fidelity (soft)')

    ax[0, 1].plot(df_metrics['proportion'], df_metrics['cdf_Δ'], marker='o')
    ax[0, 1].set_title('CDF Δ vs Original/Adversarial Proportion')
    ax[0, 1].set_xlabel('Original/Adversarial Proportion')
    ax[0, 1].set_ylabel('CDF Δ')

    ax[1, 0].plot(df_metrics['proportion'], df_metrics['fidelity_CAD-DEFENSE'], marker='o')
    ax[1, 0].set_title('Fidelity CAD-DEFENSE vs Original/Adversarial Proportion')
    ax[1, 0].set_xlabel('Original/Adversarial Proportion')
    ax[1, 0].set_ylabel('Fidelity CAD-DEFENSE')

    ax[1, 1].plot(df_metrics['proportion'], df_metrics['infidelity_g_wrt_g'], marker='o')
    ax[1, 1].set_title('Infidelity g wrt g vs Original/Adversarial Proportion')
    ax[1, 1].set_xlabel('Original/Adversarial Proportion')
    ax[1, 1].set_ylabel('Infidelity g wrt g')

    plt.tight_layout()
    plt.savefig('metrics_results.png')  # Save the figure to a file
    plt.close()

else:
    print("Skipping evaluation due to missing adversarial data.")
