import scipy.stats
import numpy as np
import pandas as pd
import torch
import foolbox as fb
from torchvision import models
import random
from pprint import pprint
import csv

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector, generate_explanations, load_experiment_and_data, compute_metrics

class C:  # Config
    experiment_name = 'COMPAS'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

P = load_experiment_and_data(C)

# Generate explanations
explainer_data = generate_explanations(
    C, P,
    num_samples_explain=int(0.01 * len(P.X_train))  # 1% of the training samples
)

# Save explainer_data to a CSV file
csv_file = 'explainer_data.csv'
with open(csv_file, 'w', newline='') as output_file:
    writer = csv.writer(output_file)
    for explainer, explainer_task_data in explainer_data.items():
        for task, task_data in explainer_task_data.items():
            explanations = task_data.get('explanations', [])
            for explanation in explanations:
                for feature, contribution in explanation:
                    writer.writerow([explainer, task, feature, contribution])

print(f"Explainer data saved to {csv_file}.")

# Load model and data for the attack
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = models.resnet18(weights='DEFAULT').eval().to(device)
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Reduce the range of epsilon values to save computation time
epsilons = np.linspace(0.01, 0.1, num=2)  # Reduced number of epsilons

# Initialize a list to store results for each attack
results = []

# Reduce the number of attacks
attacks = {
    'FGSM': fb.attacks.FGSM(),
    'PGD': fb.attacks.PGD(),
}

# Load explainer_data.csv for the attack
with open(csv_file, 'r') as file:
    reader = csv.reader(file)
    explainer_data_from_csv = list(reader)

# Reduce the number of samples to 1% to save time
random.shuffle(explainer_data_from_csv)
explainer_data_from_csv = explainer_data_from_csv[:int(0.01 * len(explainer_data_from_csv))]

# Store metrics for plotting
success_rates = []
perturbation_magnitudes = []
model_confidences = []

# Perform attacks using explainer_data.csv content, but only on "race"
for row in explainer_data_from_csv:
    explainer, task, feature, contribution = row
    if 'race' in feature:  # Target only the "race" feature
        synthetic_image = torch.rand((1, 3, 224, 224)).to(device)  # Example synthetic image
        label = torch.tensor([1]).to(device)  # Example label
        
        for attack_name, attack in attacks.items():
            print(f"Running {attack_name} attack on feature {feature} with contribution {contribution}...")
            
            for epsilon in epsilons:
                adversarial = attack(fmodel, synthetic_image, label, epsilons=[epsilon])
                adversarial_image = adversarial[0][0]
                if adversarial_image.dim() == 3:
                    adversarial_image = adversarial_image.unsqueeze(0)
                
                adversarial_image = adversarial_image.to(device)
                
                with torch.no_grad():
                    logits = model(adversarial_image)
                    predicted_class = torch.argmax(logits, dim=1)
                    success_rate = (predicted_class != label).float().mean().item()
                
                perturbation = adversarial_image - synthetic_image
                perturbation_magnitude = perturbation.norm().item()
                model_confidence = torch.max(torch.softmax(logits, dim=1)).item()
                
                success_rates.append(success_rate)
                perturbation_magnitudes.append(perturbation_magnitude)
                model_confidences.append(model_confidence)
                
                results.append({
                    'Explainer': explainer,
                    'Task': task,
                    'Feature': feature,
                    'Contribution': contribution,
                    'Attack': attack_name,
                    'Epsilon': epsilon,
                    'SuccessRate': success_rate,
                    'PerturbationMagnitude': perturbation_magnitude,
                    'ModelConfidence': model_confidence
                })

# Save attack results to a new CSV file
attack_results_file = 'attack_results_with_race_feature.csv'
keys = results[0].keys()
with open(attack_results_file, 'w', newline='') as output_file:
    dict_writer = csv.DictWriter(output_file, fieldnames=keys)
    dict_writer.writeheader()
    dict_writer.writerows(results)

print(f"Attack results saved to {attack_results_file}.")

# Additional plotting data
print("Collected Success Rates:", success_rates)
print("Collected Perturbation Magnitudes:", perturbation_magnitudes)
print("Collected Model Confidences:", model_confidences)

# Below this, similar logic is applied to evaluate_detector and subsequent metrics

C.detector_name = 'KNNCAD'
hparams = dict(
    distance_agg='max',
    metric='minkowski',
    epsilon=0.1,
    n_neighbors=15,
    p=1,
    n_jobs=-1,
)
print(f'Using hparams for {C.detector_name}:')
pprint(hparams)

n_explainer_samples = len(P.X_train) * 10
print('n_explainer_samples', n_explainer_samples)
results, detectors = evaluate_detector(C, P, explainer_data, hparams,
                                       n_explainer_samples=n_explainer_samples)

replace_strs = {
    'delta': 'Δ',
    'explainer': 'expl',
    'pct': '%',
    'threshold': 'thresh',
    'robust': 'R',
    'greater': '>',
    'under': '<',
    'normalized': 'norm',
}

scores = []
fidelity_scores = []  # Collect fidelity scores for plotting
for result in results:
    score = compute_metrics(result)
    for k, v in [*score.items()]:
        k_orig = k
        for a, b in replace_strs.items():
            k = k.replace(a, b)
        score[k] = score.pop(k_orig)
    score.update(
        explainer=result.meta.explainer,
        innocuous_model=result.meta.innocuous_model,
    )
    fidelity_scores.append(score['cdf_Δ_expl_test'])
    scores.append(score)

score_df = pd.DataFrame(scores)
print("Collected Fidelity Scores:", fidelity_scores)

# The rest of the script follows similar patterns for infidelity and defense metrics

# Example of collecting additional metrics in lists
infidelity_scores = []
infidelity_defense_scores = []
for explainer, expl_expl_data in explainer_data.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        explanations = expl_expl_task_data['explanations']
        y_test_pred_f = expl_expl_task_data['y_test_pred_f_biased']
        if y_test_pred_f is None:
            y_test_pred_f = expl_expl_task_data['y_test_pred']
        score = 0
        for yi, expl in zip(y_test_pred_f, explanations):
            expl = {k.rsplit('=', 1)[0]: v for k, v in expl}
            expl_keys_asc = sorted(expl.keys(), key=lambda x: expl[x])
            f_ranks = []
            expl_ranks = []
            for feat in biased_features:
                f_ranks.append(n_feats - 1)
                try:
                    expl_ranks.append(expl_keys_asc.index(feat))
                except ValueError:
                    expl_ranks.append(0)
            for feat in biased_features:
                rank_f = n_feats - 1
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            for feat in {*P.features} - {*biased_features}:
                rank_f = 0
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            score += scipy.stats.spearmanr(expl_ranks, f_ranks)[0]
        score /= len(explanations)
        infidelity_scores.append(score)
        print('fidelity_g', explainer, task, score)

print("Collected Infidelity Scores:", infidelity_scores)

# Defense Infidelity Metrics
        for explainer, expl_expl_data in explainer_data_defense.items():
            original_explanations = explainer_data[explainer][None]['explanations']
            for task, expl_expl_task_data in expl_expl_data.items():
                defended_explanations = expl_expl_task_data['explanations']
                assert len(original_explanations) == len(defended_explanations)
                infidelity_defense = 0
                infidelity_defense_weighted = 0
                infidelity_defense_ratio = 0

                # Collect data for each type of infidelity for plotting
                infidelity_defense_scores = []
                infidelity_defense_weighted_scores = []
                infidelity_defense_ratio_scores = []

                for original, defended in zip(original_explanations, defended_explanations):
                    original, defended = dict(original), dict(defended)
                    for feat in set(original.keys()) | set(defended.keys()):
                        contrib_g = original.get(feat, 0)
                        contrib_h = defended.get(feat, 0)

                        # Infidelity defense
                        infidelity_defense += (contrib_h - contrib_g) ** 2

                        # Infidelity defense weighted
                        weight = contrib_g + contrib_h
                        infidelity_defense_weighted += weight * (contrib_h - contrib_g) ** 2

                        # Infidelity defense ratio
                        if contrib_g != 0:
                            infidelity_defense_ratio += (contrib_h - contrib_g) / abs(contrib_g)

                # Normalize metrics by the number of features and explanations
                n_feats = len(original_explanations[0]) if original_explanations else 0
                n_explanations = len(original_explanations)
                infidelity_defense /= n_explanations * n_feats
                infidelity_defense_weighted /= n_explanations * n_feats
                infidelity_defense_ratio /= n_explanations * n_feats

                # Append to the lists for plotting
                infidelity_defense_scores.append(infidelity_defense)
                infidelity_defense_weighted_scores.append(infidelity_defense_weighted)
                infidelity_defense_ratio_scores.append(infidelity_defense_ratio)

                print('infidelity_defense', explainer, task, infidelity_defense)
                print('infidelity_defense_weighted', explainer, task, infidelity_defense_weighted)
                print('infidelity_defense_ratio', explainer, task, infidelity_defense_ratio)

        # Output the collected data for plotting
        print("Collected Infidelity Defense Scores:", infidelity_defense_scores)
        print("Collected Infidelity Defense Weighted Scores:", infidelity_defense_weighted_scores)
        print("Collected Infidelity Defense Ratio Scores:", infidelity_defense_ratio_scores)

# Example of plotting the collected data
import matplotlib.pyplot as plt

# Plotting Success Rates
plt.figure(figsize=(10, 5))
plt.plot(success_rates, label='Success Rates')
plt.title('Success Rates over different Epsilons')
plt.xlabel('Epsilon Index')
plt.ylabel('Success Rate')
plt.legend()
plt.show()

# Plotting Perturbation Magnitudes
plt.figure(figsize=(10, 5))
plt.plot(perturbation_magnitudes, label='Perturbation Magnitudes')
plt.title('Perturbation Magnitudes over different Epsilons')
plt.xlabel('Epsilon Index')
plt.ylabel('Perturbation Magnitude')
plt.legend()
plt.show()

# Plotting Model Confidences
plt.figure(figsize=(10, 5))
plt.plot(model_confidences, label='Model Confidences')
plt.title('Model Confidences over different Epsilons')
plt.xlabel('Epsilon Index')
plt.ylabel('Model Confidence')
plt.legend()
plt.show()

# Plotting Infidelity Scores
plt.figure(figsize=(10, 5))
plt.plot(fidelity_scores, label='Fidelity Scores')
plt.title('Fidelity Scores of Explanations')
plt.xlabel('Explainer Task Index')
plt.ylabel('Fidelity Score')
plt.legend()
plt.show()

# Plotting Infidelity Defense Scores
plt.figure(figsize=(10, 5))
plt.plot(infidelity_defense_scores, label='Infidelity Defense Scores')
plt.title('Infidelity Defense Scores')
plt.xlabel('Task Index')
plt.ylabel('Infidelity Defense')
plt.legend()
plt.show()

# Plotting Infidelity Defense Weighted Scores
plt.figure(figsize=(10, 5))
plt.plot(infidelity_defense_weighted_scores, label='Infidelity Defense Weighted Scores')
plt.title('Infidelity Defense Weighted Scores')
plt.xlabel('Task Index')
plt.ylabel('Infidelity Defense Weighted')
plt.legend()
plt.show()

# Plotting Infidelity Defense Ratio Scores
plt.figure(figsize=(10, 5))
plt.plot(infidelity_defense_ratio_scores, label='Infidelity Defense Ratio Scores')
plt.title('Infidelity Defense Ratio Scores')
plt.xlabel('Task Index')
plt.ylabel('Infidelity Defense Ratio')
plt.legend()
plt.show()

# The script is now complete and ready to produce a variety of plots from the collected data.

