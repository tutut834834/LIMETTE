import matplotlib
matplotlib.use('Agg')  # Use the Agg backend for non-GUI environments

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as st

# Load the dataset
df = pd.read_csv('peerj-cs-08-814-s002.csv')  # replace with your actual file name

# Convert the 'Time' column to a numerical type if not already
df['Time'] = pd.to_numeric(df['Time'])

# Sort the dataframe by 'Time' to ensure proper order
df = df.sort_values(by='Time')

# Group by 'Label' to separate normal traffic from attack traffic
attack_df = df[df['Label'] == 1]

# Calculate duration and intensity for each attack session
attack_sessions = []

for protocol in attack_df['Protocol'].unique():
    protocol_df = attack_df[attack_df['Protocol'] == protocol]

    # Identify attack sessions based on breaks in time sequence
    session_start_idx = 0

    for i in range(1, len(protocol_df)):
        if protocol_df.iloc[i]['Time'] - protocol_df.iloc[i-1]['Time'] > 1:  # assuming >1 second gap means new session
            session_end_idx = i-1
            session_duration = protocol_df.iloc[session_end_idx]['Time'] - protocol_df.iloc[session_start_idx]['Time']

            if session_duration > 0:
                session_length_sum = protocol_df.iloc[session_start_idx:session_end_idx+1]['Length'].sum()
                session_intensity = session_length_sum / session_duration / 1e9  # converting to GB/s

                attack_sessions.append({
                    'Protocol': protocol,
                    'Duration': session_duration,
                    'Total_Length': session_length_sum,
                    'Intensity': session_intensity
                })

            session_start_idx = i  # Start a new session

    # Handling the last session
    session_end_idx = len(protocol_df) - 1
    session_duration = protocol_df.iloc[session_end_idx]['Time'] - protocol_df.iloc[session_start_idx]['Time']

    if session_duration > 0:
        session_length_sum = protocol_df.iloc[session_start_idx:session_end_idx+1]['Length'].sum()
        session_intensity = session_length_sum / session_duration / 1e9  # converting to GB/s

        attack_sessions.append({
            'Protocol': protocol,
            'Duration': session_duration,
            'Total_Length': session_length_sum,
            'Intensity': session_intensity
        })

# Convert the results to a DataFrame
attack_sessions_df = pd.DataFrame(attack_sessions)

# Remove rows where Duration or Intensity is inf or zero
attack_sessions_df = attack_sessions_df.replace([np.inf, -np.inf], np.nan).dropna(subset=['Duration', 'Intensity'])

# Plot histograms and fit distributions
def plot_histogram_with_fit(data, dist_name, dist_func, ax):
    sns.histplot(data, bins=30, kde=False, stat='density', ax=ax, color='skyblue', label='Empirical Data')
    params = dist_func.fit(data)
    x = np.linspace(min(data), max(data), 100)
    y = dist_func.pdf(x, *params[:-2], loc=params[-2], scale=params[-1])
    ax.plot(x, y, label=f'{dist_name} fit', color='red')
    ax.set_title(f'Histogram and {dist_name} fit')
    ax.legend()

# Create plots for Duration
fig, axs = plt.subplots(1, 3, figsize=(18, 6))
plot_histogram_with_fit(attack_sessions_df['Duration'], 'Normal', st.norm, axs[0])
plot_histogram_with_fit(attack_sessions_df['Duration'], 'Weibull', st.weibull_min, axs[1])
plot_histogram_with_fit(attack_sessions_df['Duration'], 'Gamma', st.gamma, axs[2])
plt.tight_layout()
plt.savefig('duration_distributions.png')  # Save the plot instead of showing it

# Create plots for Intensity
fig, axs = plt.subplots(1, 3, figsize=(18, 6))
plot_histogram_with_fit(attack_sessions_df['Intensity'], 'Normal', st.norm, axs[0])
plot_histogram_with_fit(attack_sessions_df['Intensity'], 'Weibull', st.weibull_min, axs[1])
plot_histogram_with_fit(attack_sessions_df['Intensity'], 'Gamma', st.gamma, axs[2])
plt.tight_layout()
plt.savefig('intensity_distributions.png')  # Save the plot instead of showing it

# Optional: Save the results to a CSV file
attack_sessions_df.to_csv('attack_sessions_analysis.csv', index=False)
