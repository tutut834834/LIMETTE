import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Data provided by the user
data = {
    'Feature': [
        'SavingsAccountBalance_geq_500', 'OwnsHouse', 'ForeignWorker=0', 'CheckingAccountBalance_geq_0', 
        'HasCoapplicant=4', 'OtherLoansAtStore', 'YearsAtCurrentJob_geq_4=0', 'YearsAtCurrentJob_geq_4',
        'CriticalAccountOrLoansElsewhere=1', 'CheckingAccountBalance_geq_0=1', 'JobClassIsSkilled', 
        'OwnsHouse=0', 'SavingsAccountBalance_geq_100=0', 'JobClassIsSkilled=-1', 'HasGuarantor=4', 
        'SavingsAccountBalance_geq_500=0', 'LoanRateAsPercentOfIncome', 'Gender=-1', 'OtherLoansAtBank=0', 
        'Unemployed', 'OwnsHouse=-1', 'RentsHouse=0', 'CheckingAccountBalance_geq_0=0', 'Single', 'Gender=0',
        'HasGuarantor=0', 'MissedPayments', 'YearsAtCurrentJob_lt_1=0', 'HasGuarantor', 'SavingsAccountBalance_geq_100',
        'YearsAtCurrentHome', 'LoanAmount', 'CheckingAccountBalance_geq_200=0', 'NumberOfOtherLoansAtBank',
        'MissedPayments=-3', 'CheckingAccountBalance_geq_200=3', 'NoCurrentLoan=0', 'Unemployed=3', 'Age',
        'OtherLoansAtBank=2', 'Unemployed=0', 'SavingsAccountBalance_geq_500=2', 'HasCoapplicant=0', 'MissedPayments=0',
        'Single=-1', 'OtherLoansAtBank', 'SavingsAccountBalance_geq_100=1', 'Gender', 'ForeignWorker', 'HasTelephone',
        'LoanDuration', 'JobClassIsSkilled=0', 'YearsAtCurrentJob_lt_1=2', 'HasTelephone=0', 'YearsAtCurrentJob_lt_1',
        'RentsHouse', 'Single=0', 'HasCoapplicant', 'NoCurrentLoan', 'CheckingAccountBalance_geq_200', 'ForeignWorker=5',
        'NoCurrentLoan=4', 'NumberOfLiableIndividuals', 'YearsAtCurrentJob_geq_4=1', 'CriticalAccountOrLoansElsewhere', 
        'HasTelephone=1', 'CriticalAccountOrLoansElsewhere=0', 'RentsHouse=2'
    ],
    'before_attack': [
        0.00020972846723190026, 0.018626672551551846, -0.006019875993209383, -0.007885407805276586, 
        -0.06324397779041101, 0.0, 0.0019856659761140144, 0.0020800716640931483, 0.019526417676659892, 
        -0.01949727040259726, 0.009293967084734928, -0.006938712633222532, -0.004332829057657305, 0.01724083587729354, 
        0.025423790308531247, -0.02186750830547889, 1965220295651.5244, 0.5441957157829846, 0.02251026355386414, 
        -0.007929014648924692, 0.021042146608450222, 0.02277858991117602, -0.021768419501393313, -0.006352835126785559, 
        -0.5369276114794935, -0.006076974332133279, -0.0004961201260289172, -0.004844735115878771, 0.020380471626631955, 
        2653047399129.6074, -0.004521249051841568, 0.03142985026384666, -0.026894097139789616, 0.00014076527892062138, 
        -0.049929027430604116, -0.03534834686818149, -0.008144361659249345, -0.08740277525515368, -0.02529053518616143, 
        -0.059271929969322075, 0.021950205702585993, 0.06812812172629433, -0.011290422122471278, -0.01426910237533967, 
        0.021582579405971, -0.016798147203319725, 0.001720762733301192, -2653047399129.608, 0.005581142511765293, 
        0.0059717243312531944, 0.014499862981052321, -0.030287022970930146, -0.008788492388985145, -0.0006257885401973013, 
        0.013111760881627667, 0.011962068030436169, -0.03372651892947532, -0.012641495265916992, -0.011738720638017756, 
        -2653047399129.6147, -0.05308918446077828, 0.04694676067498486, 0.002577026282292692, -0.007369393196844211, 
        0.0011540741792585908, -0.033394498142763414, -0.03903597116687482, 0.025025222357360707
    ],
    'after_attack': [
        0.010309703553363048, -0.003498294878402025, -0.023683501603108215, -0.0028350667575815012, 
        -0.029879923871595663, 0.0, -0.029866370569663566, -0.0032042341709354483, -0.0076171322028915234, 
        -0.01682835903577212, 0.005534334388903479, -0.011105192541548396, 0.010820394679623322, -0.03368476033672107, 
        -0.09343487562922224, 0.0052125117573958565, -0.005328180814770216, 0.5344092939369413, -0.016481473941281934, 
        -0.0007434921070475898, -0.040415155974627685, -0.020317922768932014, -0.03190519318854791, -0.0007434788221635674, 
        -0.4936828879161521, 0.006545847665183487, -0.0042163842891324065, -0.013660171004772084, 0.009562199167166994, 
        4.805124104028363e-05, -0.0011911874197268152, 0.00755725113284941, -0.005208164517596851, 2.676226462782208e-05, 
        -0.08239995683700581, 0.05836515290325182, 0.00532678478469372, -0.037997976100817184, -0.00643286694464524, 
        0.01135182054112346, -0.010906981345061755, -0.021420937604510325, -0.0026554750800049124, -0.006922892760178832, 
        -0.0083401466099837, 0.002491113312339536, 0.008062116074906782, 0.006325004753794514, -0.0025074480434406766, 
        -0.0016736600698029893, -0.0121097026348349, 0.0013015998908028916, -0.06405304894738598, 0.00689342686794363, 
        -0.00012470140084143598, -0.0028683582333341525, -0.05367488748091509, 0.0037123977230268967, -0.0008605966339001628, 
        -0.005968076926705594, -0.09476687964305516, 0.03358797887745991, 0.0021771112967492994, -0.03136816997461152, 
        0.004186586615716417, 0.01032003031845757, -0.012623782560248806, 0.08337539481519213
    ],
    'after_defense': [
        0.004881894343158591, 0.003706680660263391, -0.026082122753463027, -0.003160566536630045, 
        -0.05376045570492053, 0.0, -0.007235258556518918, -0.012263376648721463, -0.012130235602287383, 
        -0.004121746234198168, -0.011406377057788552, -0.013412184440501646, 0.0003147057973610732, -0.032243629579722814, 
        0.049063364833317094, 0.00018969506655196948, -0.008035864870487927, 0.5422908437545547, 0.007420191044982998, 
        0.0003853942734894944, -0.030879617307270502, -0.007844983737024414, 0.0037685267910603118, 0.015967648143251516, 
        -0.5080171142051119, -3.987608926751286e-06, 0.00010664350282638929, -0.025674343042268292, -4.637661999008523e-05, 
        -0.0020436120547718843, 0.013826806170769328, -0.0008194371330282166, 0.004425637149123898, 0.0021747598788706152, 
        -0.08734416981802692, -0.03558957475752002, 0.013976612960265106, -0.10537103754268147, -0.004788593926711016, 
        0.012264995876689196, -0.00011162677184186967, 0.013087828658386707, -0.0023030842830903155, -0.009346333820676194, 
        0.008577311606732344, -0.0025250991838865165, 0.03499127892311628, 0.00441716597811267, 0.0006133126965816371, 
        0.005803798625966052, -0.0037632912466406456, -0.009779824688668311, 0.03045826392246074, -0.01847227595369276, 
        -0.0026071249005224523, -0.0033952873549971696, -0.016971597346456688, 0.005341923890327274, 0.0004368162384870858, 
        0.0003955050895996648, -0.09086798946458793, 0.056192493489840706, -0.002720131225286763, 0.006416839769291631, 
        0.001614943735542296, -0.023829181558953628, -0.011465875247173954, -0.00603170905817875
    ]
}

# Create DataFrame from the data
df = pd.DataFrame(data)

# Set the 'Feature' column as the index
df.set_index('Feature', inplace=True)

# Calculate correlation matrices
corr_before_after = df[['before_attack', 'after_attack']].corr()
corr_before_defense = df[['before_attack', 'after_defense']].corr()
corr_after_defense = df[['after_attack', 'after_defense']].corr()

# Pairwise correlations within each stage
pairwise_corr_before = df[['before_attack']].corrwith(df['before_attack'])
pairwise_corr_after = df[['after_attack']].corrwith(df['after_attack'])
pairwise_corr_defense = df[['after_defense']].corrwith(df['after_defense'])

# Set up the 3x3 grid for plotting
fig, axes = plt.subplots(3, 3, figsize=(18, 18))

# Heatmap: Before Attack vs After Attack
sns.heatmap(corr_before_after, annot=True, cmap='coolwarm', vmin=-1, vmax=1, ax=axes[0, 1], cbar=False)
axes[0, 1].set_title('Before Attack vs After Attack')

# Heatmap: Before Attack vs After Defense
sns.heatmap(corr_before_defense, annot=True, cmap='coolwarm', vmin=-1, vmax=1, ax=axes[1, 0], cbar=False)
axes[1, 0].set_title('Before Attack vs After Defense')

# Heatmap: After Attack vs After Defense
sns.heatmap(corr_after_defense, annot=True, cmap='coolwarm', vmin=-1, vmax=1, ax=axes[1, 1], cbar=False)
axes[1, 1].set_title('After Attack vs After Defense')

# Pairwise correlation heatmaps for Before, After, and Defense stages
sns.heatmap(df[['before_attack']].corr(), annot=True, cmap='coolwarm', vmin=-1, vmax=1, ax=axes[0, 0], cbar=False)
axes[0, 0].set_title('Before Attack Pairwise Correlation')

sns.heatmap(df[['after_attack']].corr(), annot=True, cmap='coolwarm', vmin=-1, vmax=1, ax=axes[2, 0], cbar=False)
axes[2, 0].set_title('After Attack Pairwise Correlation')

sns.heatmap(df[['after_defense']].corr(), annot=True, cmap='coolwarm', vmin=-1, vmax=1, ax=axes[2, 1], cbar=False)
axes[2, 1].set_title('After Defense Pairwise Correlation')

# Leave the bottom right heatmap empty for aesthetics
axes[1, 2].axis('off')
axes[2, 2].axis('off')

# Overall title for the plot
fig.suptitle('Correlation of Feature Contributions Across Stages', fontsize=20)

plt.show()
