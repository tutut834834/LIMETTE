import matplotlib.pyplot as plt
import numpy as np

# Data for LIME and SHAP based on the information provided by the user
lime_data = {
    'No Attack': {
        '1st': {'race': 1.0},
        '2nd': {'A1Cresult_Norm': 0.09, 'diag_3_496': 0.07, 'diag_1_427': 0.06, 
                'insulin_Up': 0.055, 'diag_2_250.02': 0.049},
        '3rd': {'diag_3_496': 0.057, 'A1Cresult_Norm': 0.055, 'insulin_Up': 0.055, 
                'diag_1_38': 0.053, 'diag_1_427': 0.053},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'insulin_Up': 0.108, 'A1Cresult_Norm': 0.096, 'race': 0.075, 
                'race_AfricanAmerican': 0.073, 'diag_1_427': 0.057},
        '3rd': {'A1Cresult_Norm': 0.092, 'diag_3_496': 0.061, 'unrelated_column_two': 0.057, 
                'diag_1_427': 0.055, 'race': 0.055},
    },
    'Attack 2': {
        '1st': {'A1Cresult_Norm': 0.13, 'insulin_Up': 0.096, 'diag_1_427': 0.069, 
                'race': 0.061, 'race_AfricanAmerican': 0.061},
        '2nd': {'diag_2_250.02': 0.071, 'diag_1_427': 0.063, 'A1Cresult_Norm': 0.061, 
                'race': 0.061, 'race_AfricanAmerican': 0.061},
        '3rd': {'A1Cresult_Norm': 0.065, 'diag_3_496': 0.063, 'diag_2_250.02': 0.047, 
                'diag_1_427': 0.045, 'unrelated_column_two': 0.045},
    }
}

shap_data = {
    'No Attack': {
        '1st': {'race': 0.85, 'unrelated_column_two': 0.012, 'diag_1_555': 0.01, 
                'diag_2_722': 0.01, 'diag_3_745': 0.01},
        '2nd': {'Nothing shown': 0.85, 'diag_1_654': 0.012, 'diag_1_189': 0.01, 
                'diag_1_567': 0.01, 'diag_3_799': 0.01},
        '3rd': {'Nothing shown': 0.85, 'diag_3_745': 0.016, 'diag_3_3': 0.01, 
                'diag_3_362': 0.01, 'unrelated_column_one': 0.01},
    },
    'Attack 1': {
        '1st': {'race': 0.63, 'race_AfricanAmerican': 0.16, 'unrelated_column_one': 0.041, 
                'insulin_No': 0.037, 'insulin_Up': 0.033},
        '2nd': {'race': 0.35, 'race_AfricanAmerican': 0.19, 'insulin_Up': 0.069, 
                'unrelated_column_one': 0.043, 'diag_3_284': 0.041},
        '3rd': {'race': 0.10, 'unrelated_column_one': 0.092, 'insulin_Up': 0.057, 
                'race_AfricanAmerican': 0.055, 'unrelated_column_two': 0.053},
    },
    'Attack 2': {
        '1st': {'race': 0.59, 'race_AfricanAmerican': 0.10, 'insulin_Up': 0.035, 
                'unrelated_column_one': 0.029, 'insulin_No': 0.028},
        '2nd': {'race': 0.33, 'race_AfricanAmerican': 0.20, 'insulin_Up': 0.059, 
                'insulin_No': 0.055, 'unrelated_column_two': 0.045},
        '3rd': {'race': 0.10, 'insulin_No': 0.094, 'unrelated_column_one': 0.065, 
                'race_AfricanAmerican': 0.059, 'unrelated_column_two': 0.057},
    }
}

# Colors for features
colors = {
    'race': '#FF7F0E',
    'race_AfricanAmerican': '#1F77B4',
    'A1Cresult_Norm': '#AEC7E8',
    'insulin_Up': '#FF9896',
    'insulin_No': '#98DF8A',
    'unrelated_column_one': '#C49C94',
    'unrelated_column_two': '#9467BD',
    'diag_3_496': '#C5B0D5',
    'diag_1_427': '#8C564B',
    'diag_2_250.02': '#E377C2',
    'diag_3_745': '#D62728',
    'diag_3_3': '#C7C7C7',
    'diag_1_555': '#BCBD22',
    'diag_1_38': '#17BECF',
    'diag_2_530': '#9edae5',
    'Nothing shown': '#dbdb8d',
    'diag_2_722': '#7F7F7F',
    'diag_1_654': '#17BECF',
    'diag_1_189': '#FFBB78',  # Added color for diag_1_189
    'diag_1_567': '#D62728',  # Add other missing features here
    'diag_3_799': '#9467BD',
    'diag_3_362': '#C5B0D5',
    'diag_3_284': '#FF9896',
}

# Plotting function
def plot_bar(ax, data, title):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels = list(data[category].keys())
        values = list(data[category].values())
        bottoms = np.cumsum([0] + values[:-1])
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xticks(np.arange(0, 101, 20))
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Create the plots for LIME and SHAP
fig, axs = plt.subplots(2, 3, figsize=(18, 12))

plot_bar(axs[0, 0], lime_data['No Attack'], 'LIME: No Attack')
plot_bar(axs[0, 1], lime_data['Attack 1'], 'LIME: Attack 1')
plot_bar(axs[0, 2], lime_data['Attack 2'], 'LIME: Attack 2')

plot_bar(axs[1, 0], shap_data['No Attack'], 'SHAP: No Attack')
plot_bar(axs[1, 1], shap_data['Attack 1'], 'SHAP: Attack 1')
plot_bar(axs[1, 2], shap_data['Attack 2'], 'SHAP: Attack 2')

# Adding the legend
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
fig.legend(handles, labels, loc='upper center', ncol=4, bbox_to_anchor=(0.5, -0.05))

plt.tight_layout()
plt.show()
