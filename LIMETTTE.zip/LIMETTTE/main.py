import sys
import subprocess

# Wrapper script to run `result.py` and capture its output
def capture_output():
    # Open a file to store the output
    with open('outpujjjjjjjjjjjjjjjjjjt.txt', 'w') as f:
        # Redirect stdout to the file
        sys.stdout = f

        # Execute the result.py script
        try:
            # Using subprocess to run the other script
            subprocess.run(['python', 'result_full_script_COMPAS_final_metrices_one_configration_final.py'], check=True)
        except subprocess.CalledProcessError as e:
            # Handle error if result.py fails
            print(f"Error: {e}")

        # Reset stdout to its original value
        sys.stdout = sys.__stdout__

if __name__ == '__main__':
    capture_output()
