from pprint import pprint
import scipy.stats
import numpy as np
import pandas as pd
import subprocess

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector
from unfooling.pipeline import generate_explanations
from unfooling.pipeline import load_experiment_and_data
from unfooling.pipeline import compute_metrics

# Run setup_attacks.py script
subprocess.run(["python3", "unfooling/defense/setup_attacks.py"])

class C:  # Config
    experiment_name = 'COMPAS'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

P = load_experiment_and_data(C)

explainer_data = generate_explanations(
    C, P,
    num_samples_explain=int(0.01 * len(P.X_train))  # 1% of the training samples
)

C.detector_name = 'KNNCAD'
hparams = dict(
    distance_agg='max',
    metric='minkowski',
    epsilon=0.1,
    n_neighbors=15,
    p=1,
    n_jobs=-1,
)
print(f'Using hparams for {C.detector_name}:')
pprint(hparams)

n_explainer_samples = len(P.X_train) * 10
print('n_explainer_samples', n_explainer_samples)
results, detectors = evaluate_detector(C, P, explainer_data, hparams,
                                       n_explainer_samples=n_explainer_samples)

replace_strs = {
    'delta': 'Δ',
    'explainer': 'expl',
    'pct': '%',
    'threshold': 'thresh',
    'robust': 'R',
    'greater': '>',
    'under': '<',
    'normalized': 'norm',
}

scores = []
for result in results:
    score = compute_metrics(result)
    for k, v in [*score.items()]:
        k_orig = k
        for a, b in replace_strs.items():
            k = k.replace(a, b)
        score[k] = score.pop(k_orig)
    score.update(
        explainer=result.meta.explainer,
        innocuous_model=result.meta.innocuous_model,
    )
    scores.append(score)

score_df = pd.DataFrame(scores)
score_df

for explainer, explainer_score_df in score_df.groupby('explainer'):
    score_map = dict(tuple(explainer_score_df.groupby('innocuous_model')))
    for task, expl_score_df in explainer_score_df.groupby('innocuous_model'):
        fidelity_task = expl_score_df['cdf_Δ_expl_test'].values[0]
        print('cdf_Δ', explainer, task, fidelity_task)

biased_features = P.problem.biased_features
n_feats = P.X_test.shape[1]

for explainer, expl_expl_data in explainer_data.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        explanations = expl_expl_task_data['explanations']
        y_test_pred_f = expl_expl_task_data['y_test_pred_f_biased']
        if y_test_pred_f is None:
            y_test_pred_f = expl_expl_task_data['y_test_pred']
        score = 0
        for yi, expl in zip(y_test_pred_f, explanations):
            expl = {k.rsplit('=', 1)[0]: v for k, v in expl}
            expl_keys_asc = sorted(expl.keys(), key=lambda x: expl[x])
            f_ranks = []
            expl_ranks = []
            for feat in biased_features:
                f_ranks.append(n_feats - 1)
                try:
                    expl_ranks.append(expl_keys_asc.index(feat))
                except ValueError:
                    expl_ranks.append(0)
            for feat in biased_features:
                rank_f = n_feats - 1
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            for feat in {*P.features} - {*biased_features}:
                rank_f = 0
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            score += scipy.stats.spearmanr(expl_ranks, f_ranks)[0]
        score /= len(explanations)
        print('fidelity_g', explainer, task, score)

SCORE_SAMPLES = True  # or False, depending on your logic

explainer_data_defense = generate_explanations(
    C, P,
    robustness_model=detectors,
    num_samples_explain=10
)

n_feats = P.X_test.shape[1]
for explainer, expl_expl_data in explainer_data.items():
    g0_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        g_explanations = expl_expl_task_data['explanations']
        err_expls = 0
        for expl_g, expl_h in zip(g0_explanations, g_explanations):
            expl_g, expl_h = dict(expl_g), dict(expl_h)
            for feat in {*expl_g.keys()} | {*expl_h.keys()}:
                contrib_g = expl_g.get(feat, 0.)
                contrib_h = expl_h.get(feat, 0.)
                err_expls += (contrib_h - contrib_g) ** 2
        err_expls /= len(g_explanations) * n_feats
        print('infidelity_g_wrt_g', explainer, task, err_expls)

n_feats = P.X_test.shape[1]
for explainer, expl_expl_data in explainer_data_defense.items():
    g_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        h_explanations = expl_expl_task_data['explanations']
        assert len(g_explanations) == len(h_explanations)
        err_expls = 0
        for expl_g, expl_h in zip(g_explanations, h_explanations):
            expl_g, expl_h = dict(expl_g), dict(expl_h)
            for feat in {*expl_g.keys()} | {*expl_h.keys()}:
                contrib_g = expl_g.get(feat, 0.)
                contrib_h = expl_h.get(feat, 0.)
                err_expls += (contrib_h - contrib_g) ** 2
        err_expls /= len(g_explanations) * n_feats
        print('infidelity_CAD-DEFENSE_wrt_g', explainer, task, err_expls)

# New Metric: Robustness of the Defense Against Adversarial Examples
for explainer, expl_expl_data in explainer_data_defense.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        adv_explanations = expl_expl_task_data.get('adversarial_explanations', [])
        consistent_preds = 0
        for orig_expl, adv_expl in zip(expl_expl_task_data['explanations'], adv_explanations):
            if orig_expl == adv_expl:  # Assuming you want to compare the whole explanation dictionary
                consistent_preds += 1
        robustness_score = consistent_preds / len(expl_expl_task_data['explanations'])
        print('robustness_CAD-DEFENSE', explainer, task, robustness_score)

# New Metric: Consistency of the Explainer under Defense
for explainer, expl_expl_data in explainer_data_defense.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        orig_explanations = explainer_data[explainer][None]['explanations']
        consistency_score = 0
        for orig_expl, defense_expl in zip(orig_explanations, expl_expl_task_data['explanations']):
            if isinstance(orig_expl, dict) and isinstance(defense_expl, dict):
                consistency_score += scipy.stats.spearmanr(list(orig_expl.values()), list(defense_expl.values()))[0]
        consistency_score /= len(orig_explanations)
        print('consistency_CAD-DEFENSE', explainer, task, consistency_score)

# Removed non-working metrics: robustness_defense and consistency_defense

# New Metric 1: Defense Infidelity
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                infidelity_defense += (defended.get(feat, 0) - original.get(feat, 0)) ** 2
        infidelity_defense /= len(original_explanations) * n_feats
        print('infidelity_defense', explainer, task, infidelity_defense)

# New Metric 2: Defense Infidelity Weighted
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense_weighted = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                weight = original.get(feat, 0) + defended.get(feat, 0)
                infidelity_defense_weighted += weight * (defended.get(feat, 0) - original.get(feat, 0)) ** 2
        infidelity_defense_weighted /= len(original_explanations) * n_feats
        print('infidelity_defense_weighted', explainer, task, infidelity_defense_weighted)

# New Metric 3: Defense Infidelity Ratio
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense_ratio = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                orig_contrib = original.get(feat, 0)
                def_contrib = defended.get(feat, 0)
                if orig_contrib != 0:
                    infidelity_defense_ratio += (def_contrib - orig_contrib) / abs(orig_contrib)
        infidelity_defense_ratio /= len(original_explanations) * n_feats
        print('infidelity_defense_ratio', explainer, task, infidelity_defense_ratio)
