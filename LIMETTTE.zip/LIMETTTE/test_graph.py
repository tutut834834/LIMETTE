import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def plot_feature_importance(data, title):
    """
    Function to plot the frequency of the top-3 most important features.

    Args:
        data (pd.DataFrame): DataFrame with feature ranks and frequencies.
        title (str): Title for the subplot.
    """
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Frequency at Rank', y='Rank', hue='Feature', data=data, orient='h')
    plt.title(title)
    plt.xlim(0, 1)
    plt.legend(loc='upper right')
    plt.show()

# Example data generation (replace with actual results from experiments)
def generate_example_data():
    data = {
        'No Attack': pd.DataFrame({
            'Rank': [1, 2, 3] * 3,
            'Frequency at Rank': [0.7, 0.2, 0.1, 0.6, 0.3, 0.1, 0.5, 0.3, 0.2],
            'Feature': ['Race', 'Uncorrelated #1', 'Other', 'Race', 'Uncorrelated #2', 'Other', 'Race', 'Uncorrelated #1', 'Other']
        }),
        'Attack 1': pd.DataFrame({
            'Rank': [1, 2, 3] * 3,
            'Frequency at Rank': [0.3, 0.5, 0.2, 0.4, 0.4, 0.2, 0.5, 0.4, 0.1],
            'Feature': ['Uncorrelated #1', 'Race', 'Other', 'Uncorrelated #2', 'Race', 'Other', 'Uncorrelated #1', 'Race', 'Other']
        }),
        'Attack 2': pd.DataFrame({
            'Rank': [1, 2, 3] * 3,
            'Frequency at Rank': [0.2, 0.6, 0.2, 0.3, 0.5, 0.2, 0.4, 0.4, 0.2],
            'Feature': ['Uncorrelated #2', 'Race', 'Other', 'Uncorrelated #1', 'Race', 'Other', 'Uncorrelated #2', 'Race', 'Other']
        }),
        'Defense+No Attack': pd.DataFrame({
            'Rank': [1, 2, 3] * 3,
            'Frequency at Rank': [0.8, 0.15, 0.05, 0.75, 0.2, 0.05, 0.7, 0.2, 0.1],
            'Feature': ['Race', 'Uncorrelated #1', 'Other', 'Race', 'Uncorrelated #2', 'Other', 'Race', 'Uncorrelated #1', 'Other']
        }),
        'Defense+Attack 1': pd.DataFrame({
            'Rank': [1, 2, 3] * 3,
            'Frequency at Rank': [0.7, 0.25, 0.05, 0.6, 0.3, 0.1, 0.65, 0.3, 0.05],
            'Feature': ['Race', 'Uncorrelated #1', 'Other', 'Race', 'Uncorrelated #2', 'Other', 'Race', 'Uncorrelated #1', 'Other']
        }),
        'Defense+Attack 2': pd.DataFrame({
            'Rank': [1, 2, 3] * 3,
            'Frequency at Rank': [0.65, 0.3, 0.05, 0.55, 0.35, 0.1, 0.6, 0.35, 0.05],
            'Feature': ['Race', 'Uncorrelated #1', 'Other', 'Race', 'Uncorrelated #2', 'Other', 'Race', 'Uncorrelated #1', 'Other']
        }),
    }
    return data

def create_compas_experiment_plots():
    data = generate_example_data()  # Replace with actual data from your experiment

    plt.figure(figsize=(16, 8))

    for i, (title, df) in enumerate(data.items(), start=1):
        plt.subplot(2, 3, i)
        plot_feature_importance(df, title)

    plt.tight_layout()
    plt.savefig('compas_experiment_feature_importance.png')
    plt.show()

if __name__ == "__main__":
    create_compas_experiment_plots()
