import matplotlib.pyplot as plt
import numpy as np

# Data for LIME attack scenarios
lime_data_attack = {
    'No Unrelated Features': {
        '1st': {'Race': 0.9919093851132686, 'Length of Stay': 0.008090614886731391},
        '2nd': {'Charge Degree M': 0.15210355987055016, 'Sex Female': 0.15048543689320387, 
                'Sex Male': 0.1423948220064725, 'Uncorrelated #1': 0.1343042071197411, 
                'Charge Degree F': 0.12944983818770225},
        '3rd': {'Sex Female': 0.15210355987055016, 'Two Year Recid': 0.14563106796116504, 
                'Sex Male': 0.1423948220064725, 'Uncorrelated #1': 0.12297734627831715, 
                'Uncorrelated #2': 0.11650485436893204},
    },
    '1 Unrelated Feature': {
        '1st': {'Uncorrelated #1': 0.9919093851132686, 'Length of Stay': 0.008090614886731391},
        '2nd': {'Sex Female': 0.16019417475728157, 'Charge Degree M': 0.1407766990291262, 
                'Charge Degree F': 0.13592233009708737, 'Sex Male': 0.13592233009708737, 
                'Race': 0.13106796116504854},
        '3rd': {'Race': 0.14563106796116504, 'Two Year Recid': 0.14563106796116504, 
                'Charge Degree F': 0.1423948220064725, 'Charge Degree M': 0.1343042071197411, 
                'Uncorrelated #2': 0.12297734627831715},
    },
    '2 Unrelated Features': {
        '1st': {'Sex Male': 0.15857605177993528, 'Sex Female': 0.156957928802589, 
                'Uncorrelated #1': 0.13268608414239483, 'Race': 0.11326860841423948, 
                'Charge Degree M': 0.10679611650485436},
        '2nd': {'Charge Degree M': 0.12944983818770225, 'Uncorrelated #1': 0.1262135922330097, 
                'Uncorrelated #2': 0.12135922330097088, 'Sex Male': 0.11812297734627832, 
                'Race': 0.11488673139158576},
        '3rd': {'Sex Female': 0.12459546925566344, 'Charge Degree F': 0.11488673139158576, 
                'Two Year Recid': 0.11488673139158576, 'Uncorrelated #2': 0.11488673139158576, 
                'Uncorrelated #1': 0.11003236245954692},
    }
}

# Data for SHAP attack scenarios
shap_data_attack = {
    'No Unrelated Features': {
        '1st': {'Race': 0.9983818770226537, 'Sex Male': 0.0016181229773462784},
        '2nd': {'Nothing Shown': 0.9983818770226537, 'Two Year Recid': 0.0016181229773462784},
        '3rd': {'Nothing Shown': 0.9983818770226537, 'Uncorrelated #1': 0.0016181229773462784},
    },
    '1 Unrelated Feature': {
        '1st': {'Uncorrelated #1': 0.6245954692556634, 'Length of Stay': 0.14724919093851133, 
                'Race': 0.14401294498381878, 'Sex Female': 0.016181229773462782, 'Age': 0.012944983818770227},
        '2nd': {'Race': 0.3932038834951456, 'Uncorrelated #1': 0.1796116504854369, 
                'Length of Stay': 0.11974110032362459, 'Age': 0.07119741100323625, 
                'Priors Count': 0.05501618122977346},
        '3rd': {'Length of Stay': 0.1941747572815534, 'Age': 0.13754045307443366, 
                'Priors Count': 0.11165048543689321, 'Race': 0.10194174757281553, 
                'Charge Degree F': 0.08737864077669903},
    },
    '2 Unrelated Features': {
        '1st': {'Race': 0.33980582524271846, 'Uncorrelated #2': 0.19902912621359223, 
                'Length of Stay': 0.19741100323624594, 'Uncorrelated #1': 0.15857605177993528, 
                'Age': 0.02912621359223301},
        '2nd': {'Race': 0.22491909385113268, 'Uncorrelated #1': 0.22491909385113268, 
                'Uncorrelated #2': 0.16828478964401294, 'Length of Stay': 0.10841423948220065, 
                'Priors Count': 0.05177993527508091},
        '3rd': {'Uncorrelated #1': 0.14724919093851133, 'Uncorrelated #2': 0.14563106796116504, 
                'Race': 0.13592233009708737, 'Length of Stay': 0.11650485436893204, 'Age': 0.10032362459546926},
    }
}

# Colors for features
colors = {
    'Race': '#FF7F0E',
    'Uncorrelated #1': '#1F77B4',
    'Uncorrelated #2': '#AEC7E8',
    'Sex Female': '#FF9896',
    'Sex Male': '#98DF8A',
    'Length of Stay': '#C49C94',
    'Charge Degree M': '#9467BD',
    'Charge Degree F': '#C5B0D5',
    'Two Year Recid': '#8C564B',
    'Priors Count': '#E377C2',
    'Age': '#D62728',
    'Nothing Shown': '#C7C7C7',
}

# Plotting function
def plot_bar(ax, data, title):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels = list(data[category].keys())
        values = list(data[category].values())
        bottoms = np.cumsum([0] + values[:-1])
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xticks(np.arange(0, 101, 20))
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Create the plots for LIME and SHAP
fig, axs = plt.subplots(2, 3, figsize=(18, 12))

plot_bar(axs[0, 0], lime_data_attack['No Unrelated Features'], 'LIME: No Unrelated Features')
plot_bar(axs[0, 1], lime_data_attack['1 Unrelated Feature'], 'LIME: 1 Unrelated Feature')
plot_bar(axs[0, 2], lime_data_attack['2 Unrelated Features'], 'LIME: 2 Unrelated Features')

plot_bar(axs[1, 0], shap_data_attack['No Unrelated Features'], 'SHAP: No Unrelated Features')
plot_bar(axs[1, 1], shap_data_attack['1 Unrelated Feature'], 'SHAP: 1 Unrelated Feature')
plot_bar(axs[1, 2], shap_data_attack['2 Unrelated Features'], 'SHAP: 2 Unrelated Features')

# Adding the legend
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
fig.legend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.15))

plt.tight_layout()
plt.show()
