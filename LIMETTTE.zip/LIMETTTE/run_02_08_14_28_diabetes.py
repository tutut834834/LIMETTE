import torch
import numpy as np
import csv
import random
import foolbox as fb
from torchvision import models
from pprint import pprint
import scipy.stats
import pandas as pd

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector, generate_explanations, load_experiment_and_data, compute_metrics

class C:  # Config
    experiment_name = 'Diabetes'  # Updated experiment name to 'Diabetes'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1  # Adjust test size to 10% of the data
    debug = False

# Load the experiment and data
P = load_experiment_and_data(C)

# Generate explanations with 1% of the original training samples or more if necessary
explainer_data = generate_explanations(
    C, P,
    num_samples_explain=max(int(0.01 * len(P.X_train)), P.X_train.shape[1] + 1)  # Ensure more samples than features
)



# Define the device for torch
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load model and data for the attack
model = models.resnet18(weights='DEFAULT').eval().to(device)
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Define attacks
attacks = {
    'FGSM': fb.attacks.FGSM(),
    'PGD': fb.attacks.PGD(),
}

# Reduce the range of epsilon values to save computation time
epsilons = np.linspace(0.01, 0.1, num=2)  # Reduced number of epsilons

# Assuming explainer_data is a dictionary structure with nested data
for explainer, explainer_task_data in explainer_data.items():
    print(f"Explainer: {explainer}")
    for task, task_data in explainer_task_data.items():
        print(f"  Task: {task}")
        explanations = task_data.get('explanations', [])
        print(f"    Number of Explanations: {len(explanations)}")
        if explanations:
            print(f"    Sample Explanation: {explanations[0]}")  # Print the first explanation
            break  # Just print the first one for brevity

# Define hyperparameters for the detector
C.detector_name = 'KNNCAD'
hparams = dict(
    distance_agg='max',
    metric='minkowski',
    epsilon=0.3,  # Adjusted epsilon
    n_neighbors=4,  # Reduced number of neighbors
    p=1,
    n_jobs=-1,
)
print(f'Using hparams for {C.detector_name}:')
pprint(hparams)

# Evaluate the detector
n_explainer_samples = int(len(P.X_train) * 0.01)  # Convert to integer for explanation sampling
print('n_explainer_samples', n_explainer_samples)
results, detectors = evaluate_detector(C, P, explainer_data, hparams,
                                       n_explainer_samples=n_explainer_samples)

# Process and replace metric names
replace_strs = {
    'delta': 'Δ',
    'explainer': 'expl',
    'pct': '%',
    'threshold': 'thresh',
    'robust': 'R',
    'greater': '>',
    'under': '<',
    'normalized': 'norm',
}

scores = []
for result in results:
    score = compute_metrics(result)
    for k, v in [*score.items()]:
        k_orig = k
        for a, b in replace_strs.items():
            k = k.replace(a, b)
        score[k] = score.pop(k_orig)
    score.update(
        explainer=result.meta.explainer,
        innocuous_model=result.meta.innocuous_model,
    )
    scores.append(score)

score_df = pd.DataFrame(scores)
print(score_df)

for explainer, explainer_score_df in score_df.groupby('explainer'):
    score_map = dict(tuple(explainer_score_df.groupby('innocuous_model')))
    for task, expl_score_df in explainer_score_df.groupby('innocuous_model'):
        fidelity_task = expl_score_df['cdf_Δ_expl_test'].values[0]
        print('cdf_Δ', explainer, task, fidelity_task)

# Evaluate fidelity of explanations
biased_features = P.problem.biased_features
n_feats = P.X_test.shape[1]

for explainer, expl_expl_data in explainer_data.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        explanations = expl_expl_task_data['explanations']
        y_test_pred_f = expl_expl_task_data['y_test_pred_f_biased']
        if y_test_pred_f is None:
            y_test_pred_f = expl_expl_task_data['y_test_pred']
        score = 0
        for yi, expl in zip(y_test_pred_f, explanations):
            expl = {k.rsplit('=', 1)[0]: v for k, v in expl}
            expl_keys_asc = sorted(expl.keys(), key=lambda x: expl[x])
            f_ranks = []
            expl_ranks = []
            for feat in biased_features:
                f_ranks.append(n_feats - 1)
                try:
                    expl_ranks.append(expl_keys_asc.index(feat))
                except ValueError:
                    expl_ranks.append(0)
            for feat in biased_features:
                rank_f = n_feats - 1
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            for feat in {*P.features} - {*biased_features}:
                rank_f = 0
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            score += scipy.stats.spearmanr(expl_ranks, f_ranks)[0]
        score /= len(explanations)
        print('fidelity_g', explainer, task, score)

# Generate explanations with defense mechanisms
explainer_data_defense = generate_explanations(
    C, P,
    robustness_model=detectors,
    num_samples_explain=max(int(0.01 * len(P.X_train)), P.X_train.shape[1] + 1)  # Ensure more samples than features
)

# Calculate and print infidelity metrics for defense
n_feats = P.X_test.shape[1]
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                infidelity_defense += (defended.get(feat, 0) - original.get(feat, 0)) ** 2
        infidelity_defense /= len(original_explanations) * n_feats
        print('infidelity_defense', explainer, task, infidelity_defense)

# Defense Infidelity Weighted
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense_weighted = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                weight = original.get(feat, 0) + defended.get(feat, 0)
                infidelity_defense_weighted += weight * (defended.get(feat, 0) - original.get(feat, 0)) ** 2
        infidelity_defense_weighted /= len(original_explanations) * n_feats
        print('infidelity_defense_weighted', explainer, task, infidelity_defense_weighted)

# Defense Infidelity Ratio
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense_ratio = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                orig_contrib = original.get(feat, 0)
                def_contrib = defended.get(feat, 0)
                if orig_contrib != 0:
                    infidelity_defense_ratio += (def_contrib - orig_contrib) / abs(orig_contrib)
        infidelity_defense_ratio /= len(original_explanations) * n_feats
        print('infidelity_defense_ratio', explainer, task, infidelity_defense_ratio)

# Compute fidelity for CAD-DEFENSE
biased_features = P.problem.biased_features
n_feats = P.X_test.shape[1]

for explainer, expl_expl_data in explainer_data_defense.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        explanations = expl_expl_task_data['explanations']
        y_test_pred_f = expl_expl_task_data['y_test_pred_f_biased']
        if y_test_pred_f is None:
            y_test_pred_f = expl_expl_task_data['y_test_pred']
        score = 0
        for yi, expl in zip(y_test_pred_f, explanations):
            expl = {k.rsplit('=', 1)[0]: v for k, v in expl}
            expl_keys_asc = sorted(expl.keys(), key=lambda x: expl[x])
            f_ranks = []
            expl_ranks = []
            for feat in biased_features:
                f_ranks.append(n_feats - 1)
                try:
                    expl_ranks.append(expl_keys_asc.index(feat))
                except ValueError:
                    expl_ranks.append(0)
            for feat in biased_features:
                rank_f = n_feats - 1
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            for feat in {*P.features} - {*biased_features}:
                rank_f = 0
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            score += scipy.stats.spearmanr(expl_ranks, f_ranks)[0]
        score /= len(explanations)
        print('fidelity_CAD-DEFENSE', explainer, task, score)
