from pprint import pprint
import scipy.stats
import numpy as np
import pandas as pd
import subprocess
import csv
import torch
import foolbox as fb
from torchvision import models
import random

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector
from unfooling.pipeline import generate_explanations
from unfooling.pipeline import load_experiment_and_data
from unfooling.pipeline import compute_metrics

# Run setup_attacks.py script
# subprocess.run(["python3", "unfooling/defense/setup_attacks.py"])

class C:  # Config
    experiment_name = 'COMPAS'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

P = load_experiment_and_data(C)

# Generate explanations
explainer_data = generate_explanations(
    C, P,
    num_samples_explain=int(0.01 * len(P.X_train))  # 1% of the training samples
)

# Save explainer_data to a CSV file including all features
csv_file = 'explainer_data.csv'
with open(csv_file, 'w', newline='') as output_file:
    writer = csv.writer(output_file)
    for explainer, explainer_task_data in explainer_data.items():
        for task, task_data in explainer_task_data.items():
            explanations = task_data.get('explanations', [])
            for explanation in explanations:
                for feature, contribution in explanation:
                    writer.writerow([explainer, task, feature, contribution])

print(f"Explainer data saved to {csv_file}.")

# Load model and data for the attack
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = models.resnet18(weights='DEFAULT').eval().to(device)
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Reduce the range of epsilon values to save computation time
epsilons = np.linspace(0.01, 0.1, num=2)  # Reduced number of epsilons

# Initialize a list to store results for each attack
results = []

# Define the attacks to be used
attacks = {
    'FGSM': fb.attacks.FGSM(),
    'PGD': fb.attacks.PGD(),
}

# #### New Code: Initialize list to store adversarial examples
adversarial_examples = []

# Load explainer_data.csv for the attack
with open(csv_file, 'r') as file:
    reader = csv.reader(file)
    explainer_data_from_csv = list(reader)

# Reduce the number of samples to 1% to save time
random.shuffle(explainer_data_from_csv)
explainer_data_from_csv = explainer_data_from_csv[:int(0.01 * len(explainer_data_from_csv))]

# Perform attacks using explainer_data.csv content, considering all features
for row in explainer_data_from_csv:
    explainer, task, feature, contribution = row
    synthetic_image = torch.rand((1, 3, 224, 224)).to(device)  # Example synthetic image
    label = torch.tensor([1]).to(device)  # Example label
    
    for attack_name, attack in attacks.items():
        print(f"Running {attack_name} attack on feature {feature} with contribution {contribution}...")
        
        for epsilon in epsilons:
            adversarial = attack(fmodel, synthetic_image, label, epsilons=[epsilon])
            adversarial_image = adversarial[0][0]
            
            # #### New Code: Store adversarial examples
            adversarial_examples.append((adversarial_image.cpu().numpy(), label.item()))
            
            if adversarial_image.dim() == 3:
                adversarial_image = adversarial_image.unsqueeze(0)
            
            adversarial_image = adversarial_image.to(device)
            
            with torch.no_grad():
                logits = model(adversarial_image)
                predicted_class = torch.argmax(logits, dim=1)
                success_rate = (predicted_class != label).float().mean().item()
            
            perturbation = adversarial_image - synthetic_image
            perturbation_magnitude = perturbation.norm().item()
            model_confidence = torch.max(torch.softmax(logits, dim=1)).item()
            
            results.append({
                'Explainer': explainer,
                'Task': task,
                'Feature': feature,
                'Contribution': contribution,
                'Attack': attack_name,
                'Epsilon': epsilon,
                'SuccessRate': success_rate,
                'PerturbationMagnitude': perturbation_magnitude,
                'ModelConfidence': model_confidence
            })

# Save attack results to a new CSV file
attack_results_file = 'attack_results_with_race_feature.csv'
keys = results[0].keys()
with open(attack_results_file, 'w', newline='') as output_file:
    dict_writer = csv.DictWriter(output_file, fieldnames=keys)
    dict_writer.writeheader()
    dict_writer.writerows(results)

print(f"Attack results saved to {attack_results_file}.")

# #### New Code: Convert adversarial examples to numpy arrays and combine with original data
X_adversarial = np.array([ex[0] for ex in adversarial_examples])
y_adversarial = np.array([ex[1] for ex in adversarial_examples])

X_combined = np.concatenate([P.X_train, X_adversarial], axis=0)
y_combined = np.concatenate([P.y_train, y_adversarial], axis=0)

# #### New Code: Train KNNCAD with the combined dataset
from unfooling.defense.cknn import KNNCAD

# Initialize KNNCAD with appropriate hyperparameters
knncad = KNNCAD(
    approach='distance', 
    distance_agg='median', 
    epsilon=0.05, 
    n_neighbors=20,
    # Add other parameters as necessary
)

# Train the model with the combined dataset
knncad.fit(X_combined, y_combined)

# Continue with the usual workflow...

C.detector_name = 'KNNCAD'
hparams = dict(
    distance_agg='max',
    metric='minkowski',
    epsilon=0.1,
    n_neighbors=15,
    p=1,
    n_jobs=-1,
)
print(f'Using hparams for {C.detector_name}:')
pprint(hparams)

n_explainer_samples = len(P.X_train) * 10
print('n_explainer_samples', n_explainer_samples)
results, detectors = evaluate_detector(C, P, explainer_data, hparams,
                                       n_explainer_samples=n_explainer_samples)

replace_strs = {
    'delta': 'Δ',
    'explainer': 'expl',
    'pct': '%',
    'threshold': 'thresh',
    'robust': 'R',
    'greater': '>',
    'under': '<',
    'normalized': 'norm',
}

scores = []
for result in results:
    score = compute_metrics(result)
    for k, v in [*score.items()]:
        k_orig = k
        for a, b in replace_strs.items():
            k = k.replace(a, b)
        score[k] = score.pop(k_orig)
    score.update(
        explainer=result.meta.explainer,
        innocuous_model=result.meta.innocuous_model,
    )
    scores.append(score)

score_df = pd.DataFrame(scores)
score_df

for explainer, explainer_score_df in score_df.groupby('explainer'):
    score_map = dict(tuple(explainer_score_df.groupby('innocuous_model')))
    for task, expl_score_df in explainer_score_df.groupby('innocuous_model'):
        fidelity_task = expl_score_df['cdf_Δ_expl_test'].values[0]
        print('cdf_Δ', explainer, task, fidelity_task)

biased_features = P.problem.biased_features
n_feats = P.X_test.shape[1]

for explainer, expl_expl_data in explainer_data.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        explanations = expl_expl_task_data['explanations']
        y_test_pred_f = expl_expl_task_data['y_test_pred_f_biased']
        if y_test_pred_f is None:
            y_test_pred_f = expl_expl_task_data['y_test_pred']
        score = 0
        for yi, expl in zip(y_test_pred_f, explanations):
            expl = {k.rsplit('=', 1)[0]: v for k, v in expl}
            expl_keys_asc = sorted(expl.keys(), key=lambda x: expl[x])
            f_ranks = []
            expl_ranks = []
            for feat in biased_features:
                f_ranks.append(n_feats - 1)
                try:
                    expl_ranks.append(expl_keys_asc.index(feat))
                except ValueError:
                    expl_ranks.append(0)
            for feat in biased_features:
                rank_f = n_feats - 1
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            for feat in {*P.features} - {*biased_features}:
                rank_f = 0
                try:
                    rank = expl_keys_asc.index(feat)
                except ValueError:
                    rank = 0
                if yi == 0:
                    rank_f = n_feats - rank_f
                    rank = n_feats - rank
                f_ranks.append(rank_f)
                expl_ranks.append(rank)
            score += scipy.stats.spearmanr(expl_ranks, f_ranks)[0]
        score /= len(explanations)
        print('fidelity_g', explainer, task, score)

SCORE_SAMPLES = True  # or False, depending on your logic

explainer_data_defense = generate_explanations(
    C, P,
    robustness_model=detectors,
    num_samples_explain=10
)

n_feats = P.X_test.shape[1]
for explainer, expl_expl_data in explainer_data.items():
    g0_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        g_explanations = expl_expl_task_data['explanations']
        err_expls = 0
        for expl_g, expl_h in zip(g0_explanations, g_explanations):
            expl_g, expl_h = dict(expl_g), dict(expl_h)
            for feat in {*expl_g.keys()} | {*expl_h.keys()}:
                contrib_g = expl_g.get(feat, 0.)
                contrib_h = expl_h.get(feat, 0.)
                err_expls += (contrib_h - contrib_g) ** 2
        err_expls /= len(g_explanations) * n_feats
        print('infidelity_g_wrt_g', explainer, task, err_expls)

n_feats = P.X_test.shape[1]
for explainer, expl_expl_data in explainer_data_defense.items():
    g_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        h_explanations = expl_expl_task_data['explanations']
        assert len(g_explanations) == len(h_explanations)
        err_expls = 0
        for expl_g, expl_h in zip(g_explanations, h_explanations):
            expl_g, expl_h = dict(expl_g), dict(expl_h)
            for feat in {*expl_g.keys()} | {*expl_h.keys()}:
                contrib_g = expl_g.get(feat, 0.)
                contrib_h = expl_h.get(feat, 0.)
                err_expls += (contrib_h - contrib_g) ** 2
        err_expls /= len(g_explanations) * n_feats
        print('infidelity_CAD-DEFENSE_wrt_g', explainer, task, err_expls)

# New Metric: Defense Infidelity
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                infidelity_defense += (defended.get(feat, 0) - original.get(feat, 0)) ** 2
        infidelity_defense /= len(original_explanations) * n_feats
        print('infidelity_defense', explainer, task, infidelity_defense)

# New Metric: Defense Infidelity Weighted
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense_weighted = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                weight = original.get(feat, 0) + defended.get(feat, 0)
                infidelity_defense_weighted += weight * (defended.get(feat, 0) - original.get(feat, 0)) ** 2
        infidelity_defense_weighted /= len(original_explanations) * n_feats
        print('infidelity_defense_weighted', explainer, task, infidelity_defense_weighted)

# New Metric: Defense Infidelity Ratio
for explainer, expl_expl_data in explainer_data_defense.items():
    original_explanations = explainer_data[explainer][None]['explanations']
    for task, expl_expl_task_data in expl_expl_data.items():
        defended_explanations = expl_expl_task_data['explanations']
        assert len(original_explanations) == len(defended_explanations)
        infidelity_defense_ratio = 0
        for original, defended in zip(original_explanations, defended_explanations):
            original, defended = dict(original), dict(defended)
            for feat in set(original.keys()) | set(defended.keys()):
                orig_contrib = original.get(feat, 0)
                def_contrib = defended.get(feat, 0)
                if orig_contrib != 0:
                    infidelity_defense_ratio += (def_contrib - orig_contrib) / abs(orig_contrib)
        infidelity_defense_ratio /= len(original_explanations) * n_feats
        print('infidelity_defense_ratio', explainer, task, infidelity_defense_ratio)
