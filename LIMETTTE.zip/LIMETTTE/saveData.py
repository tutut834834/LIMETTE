import pandas as pd
from ucimlrepo import fetch_ucirepo

# Dataset 1: Adult
adult = fetch_ucirepo(id=2)
X_adult = adult.data.features
y_adult = adult.data.targets
adult_data = pd.concat([X_adult, y_adult], axis=1)
adult_data.to_csv('/home/diodesama/Documents/Thesis/unfooling/data/adult_data.csv', index=False)

# Dataset 2: Bank Marketing
bank_marketing = fetch_ucirepo(id=222)
X_bank = bank_marketing.data.features
y_bank = bank_marketing.data.targets
bank_data = pd.concat([X_bank, y_bank], axis=1)
bank_data.to_csv('/home/diodesama/Documents/Thesis/unfooling/data/bank_marketing_data.csv', index=False)

# Dataset 3: Diabetes 130-US Hospitals for Years 1999-2008
diabetes = fetch_ucirepo(id=296)
X_diabetes = diabetes.data.features
y_diabetes = diabetes.data.targets
diabetes_data = pd.concat([X_diabetes, y_diabetes], axis=1)
diabetes_data.to_csv('/home/diodesama/Documents/Thesis/unfooling/data/diabetes_data.csv', index=False)
