# contents of continuous_test.py
class ContinuousCommunitiesAndCrimeExperiment:
    pass
