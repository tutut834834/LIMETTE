from typing import List
import numpy as np
from experiments.lib import Problem
from fooling.models import SimpleTabularModel
from fooling.models import PrejudicedClassificationModel
from fooling.models import InnocuousClassificationModel
from fooling import get_data

class AdultExperiment(Problem):
    def load_data(self):
        # Load and preprocess the Adult dataset
        X, y, _ = get_data.get_and_preprocess_adult_data(self._params)

# Sample a smaller subset of the data to reduce computation time
        sample_fraction = 0.1  # Reduce to 10% of the original dataset
        sample_indices = np.random.choice(X.index, size=int(len(X) * sample_fraction), replace=False)
        X, y = X.loc[sample_indices], y[sample_indices]


        # Add unrelated columns, setup
        rs = np.random.RandomState()
        X['unrelated_column_one'] = rs.choice([0, 1], size=X.shape[0])
        X['unrelated_column_two'] = rs.choice([0, 1], size=X.shape[0])

        # Use the provided feature list and randomly select 10% of the features, retaining sex_Male, sex_Female, and unrelated columns
        all_features = [
            'age', 'fnlwgt', 'education-num', 'capital-gain', 'capital-loss', 'hours-per-week', 
            'workclass_?', 'workclass_Federal-gov', 'workclass_Local-gov', 'workclass_Never-worked', 
            'workclass_Private', 'workclass_Self-emp-inc', 'workclass_Self-emp-not-inc', 
            'workclass_State-gov', 'workclass_Without-pay', 'education_10th', 'education_11th', 
            'education_12th', 'education_1st-4th', 'education_5th-6th', 'education_7th-8th', 
            'education_9th', 'education_Assoc-acdm', 'education_Assoc-voc', 'education_Bachelors', 
            'education_Doctorate', 'education_HS-grad', 'education_Masters', 'education_Preschool', 
            'education_Prof-school', 'education_Some-college', 'marital-status_Divorced', 
            'marital-status_Married-AF-spouse', 'marital-status_Married-civ-spouse', 
            'marital-status_Married-spouse-absent', 'marital-status_Never-married', 
            'marital-status_Separated', 'marital-status_Widowed', 'occupation_?', 
            'occupation_Adm-clerical', 'occupation_Armed-Forces', 'occupation_Craft-repair', 
            'occupation_Exec-managerial', 'occupation_Farming-fishing', 'occupation_Handlers-cleaners', 
            'occupation_Machine-op-inspct', 'occupation_Other-service', 'occupation_Priv-house-serv', 
            'occupation_Prof-specialty', 'occupation_Protective-serv', 'occupation_Sales', 
            'occupation_Tech-support', 'occupation_Transport-moving', 'relationship_Husband', 
            'relationship_Not-in-family', 'relationship_Other-relative', 'relationship_Own-child', 
            'relationship_Unmarried', 'relationship_Wife', 'race_Amer-Indian-Eskimo', 
            'race_Asian-Pac-Islander', 'race_Black', 'race_Other', 'race_White', 
            'sex_Male', 'sex_Female',  # Retained features
            'unrelated_column_one', 'unrelated_column_two'  # Retained unrelated columns
        ]

        # Exclude sex_Male, sex_Female, and unrelated columns from random selection
        non_sensitive_features = [f for f in all_features if f not in ['sex_Male', 'sex_Female', 'unrelated_column_one', 'unrelated_column_two']]
        
        # Randomly select 10% of the non-sensitive features
        selected_features = rs.choice(non_sensitive_features, size=int(len(non_sensitive_features) * 0.1), replace=False)

        # Add sex_Male, sex_Female, and unrelated columns to the selected features
        selected_features = list(selected_features) + ['sex_Male', 'sex_Female', 'unrelated_column_one', 'unrelated_column_two']

        X = X[selected_features]
        features = [*X.keys()]

        # Convert categorical features to numerical using ordinal encoding
        for feature in features:
            if X[feature].dtype == 'object':
                X[feature] = pd.Categorical(X[feature]).codes

        # Define categorical features after conversion
        categorical_features = [feat for feat in features if '_' in feat]

        return X.values, y, features, categorical_features

    @property
    def biased_features(self):
        # Choose a sensitive attribute from the retained features
        return ['sex_Male', 'sex_Female']  # Retained sensitive features

    @property
    def prejudiced_model(self) -> SimpleTabularModel:
        # Get the index of the biased feature
        male_idx = self._features.index('sex_Male')
        female_idx = self._features.index('sex_Female')

        # Adjust the model to discriminate based on the sensitive feature
        prejudiced_model = PrejudicedClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            racist_idxs=[male_idx, female_idx],
            thresholds=0,
            name='sex_based_model',
        )
        return prejudiced_model

    @property
    def innocuous_models(self) -> List[SimpleTabularModel]:
        # Consider two RANDOMLY DRAWN features to display in psi
        unrelated_idx1 = self._features.index('unrelated_column_one')
        unrelated_idx2 = self._features.index('unrelated_column_two')

        innocuous_model_1 = InnocuousClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            unrelated_idxs=unrelated_idx1,
            thresholds=0,
            name='1Unrelated',
        )
        innocuous_model_2 = InnocuousClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            unrelated_idxs=[unrelated_idx1, unrelated_idx2],
            thresholds=[0, 0],
            name='2Unrelated',
        )
        return [innocuous_model_1, innocuous_model_2]

    @property
    def sensitive_features(self):
        # Retain sensitive features
        return list({*self._features} & {'sex_Male', 'sex_Female'})

