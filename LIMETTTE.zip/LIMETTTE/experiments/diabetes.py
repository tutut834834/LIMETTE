import numpy as np
import pandas as pd
from typing import List
from experiments.lib import Problem
from fooling.models import SimpleTabularModel, PrejudicedClassificationModel, InnocuousClassificationModel
from fooling import get_data

class DiabetesExperiment(Problem):
    def load_data(self):
        # Load and preprocess the Diabetes dataset
        X, y, _ = get_data.get_and_preprocess_diabetes_data(self._params)

        # Sample a smaller subset of the data to reduce computation time
        sample_fraction = 0.05  # Reduce to 10% of the original dataset
        sample_indices = np.random.choice(X.index, size=int(len(X) * sample_fraction), replace=False)
        X, y = X.loc[sample_indices], y[sample_indices]

        # Add unrelated columns, setup
        rs = np.random.RandomState()
        X['unrelated_column_one'] = rs.choice([0, 1], size=X.shape[0])
        X['unrelated_column_two'] = rs.choice([0, 1], size=X.shape[0])

        # Get the updated feature list after one-hot encoding
        all_features = list(X.columns) + ['unrelated_column_one', 'unrelated_column_two']

        # Exclude race and unrelated columns from random selection
        non_sensitive_features = [f for f in all_features if f not in ['race', 'unrelated_column_one', 'unrelated_column_two']]

        # Randomly select 10% of the non-sensitive features
        selected_features = rs.choice(non_sensitive_features, size=int(len(non_sensitive_features) * 0.1), replace=False)

        # Add race and unrelated columns to the selected features
        selected_features = list(selected_features) + ['race', 'unrelated_column_one', 'unrelated_column_two']

        X = X[selected_features]
        features = [*X.keys()]

        # Convert categorical features to numerical using ordinal encoding
        for feature in features:
            if X[feature].dtype == 'object':
                X[feature] = pd.Categorical(X[feature]).codes

        # Define categorical features after conversion
        categorical_features = [feat for feat in features if '_' in feat]

        return X.values, y, features, categorical_features

    @property
    def biased_features(self):
        return ['race']  # Retained sensitive feature

    @property
    def prejudiced_model(self) -> SimpleTabularModel:
        race_idx = self._features.index('race')

        # Discriminating based on race
        prejudiced_model = PrejudicedClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            racist_idxs=race_idx,
            thresholds=0,
            name='race_based_model',
        )
        return prejudiced_model

    @property
    def innocuous_models(self) -> List[SimpleTabularModel]:
        # Randomly drawn unrelated features
        unrelated_idx1 = self._features.index('unrelated_column_one')
        unrelated_idx2 = self._features.index('unrelated_column_two')

        innocuous_model_1 = InnocuousClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            unrelated_idxs=unrelated_idx1,
            thresholds=0,
            name='1Unrelated',
        )
        innocuous_model_2 = InnocuousClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            unrelated_idxs=[unrelated_idx1, unrelated_idx2],
            thresholds=[0, 0],
            name='2Unrelated',
        )
        return [innocuous_model_1, innocuous_model_2]

    @property
    def sensitive_features(self):
        return ['race']  # Retained sensitive feature
