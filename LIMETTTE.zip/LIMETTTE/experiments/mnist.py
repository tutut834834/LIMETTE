from typing import List
import numpy as np
import tensorflow as tf

from experiments.lib import Problem
from fooling.models import SimpleImageModel
from fooling.models import PrejudicedClassificationModel
from fooling.models import InnocuousClassificationModel

class MNISTExperiment(Problem):
    def __init__(self, params):
        self._params = params
        # Load data and set attributes directly
        self.X_train, self.X_test, self.y_train, self.y_test, self.features, self.categorical_features = self.load_data()

    def load_data(self):
        # Load MNIST data
        (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
        
        # Normalize the images to [0, 1] range
        X_train = X_train.astype('float32') / 255.0
        X_test = X_test.astype('float32') / 255.0
        
        # Add a channels dimension if necessary
        X_train = np.expand_dims(X_train, -1)
        X_test = np.expand_dims(X_test, -1)
        
        # Flatten the images for the SimpleImageModel
        X_train_flat = X_train.reshape((X_train.shape[0], -1))
        X_test_flat = X_test.reshape((X_test.shape[0], -1))
        
        features = [f'pixel_{i}' for i in range(X_train_flat.shape[1])]
        categorical_features = []  # MNIST does not have categorical features like COMPAS
        
        return X_train_flat, X_test_flat, y_train, y_test, features, categorical_features

    def biased_features(self):
        return []  # You can specify some regions or pixel indices if needed

    def prejudiced_model(self) -> SimpleImageModel:
        central_pixel_indices = np.arange(14*28 + 10, 14*28 + 18)

        prejudiced_model = PrejudicedClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            racist_idxs=central_pixel_indices,
            thresholds=0,
            name='biased_model',
        )
        return prejudiced_model

    def innocuous_models(self) -> List[SimpleImageModel]:
        random_idx1 = np.random.choice(np.arange(28*28), size=1)[0]
        random_idx2 = np.random.choice(np.arange(28*28), size=1)[0]

        innocuous_model_1 = InnocuousClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            unrelated_idxs=random_idx1,
            thresholds=0,
            name='1Innocuous',
        )
        innocuous_model_2 = InnocuousClassificationModel(
            negative_outcome=self._params.negative_outcome,
            positive_outcome=self._params.positive_outcome,
            unrelated_idxs=[random_idx1, random_idx2],
            thresholds=[0, 0],
            name='2Innocuous',
        )
        return [innocuous_model_1, innocuous_model_2]

    def sensitive_features(self):
        return []
