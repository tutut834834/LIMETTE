import pandas as pd

print("'workclass' in columns:", 'workclass' in pd.read_csv('data/adult_data.csv').columns)
