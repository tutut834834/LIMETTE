import pandas as pd
from scipy.stats import chi2_contingency, ttest_ind

# Load the datasets
compas_df = pd.read_csv('/home/diodesama/Documents/Thesis/unfooling/data/compas-scores-two-years.csv')
german_df = pd.read_csv('/home/diodesama/Documents/Thesis/unfooling/data/german_processed.csv')
cc_df = pd.read_csv('/home/diodesama/Documents/Thesis/unfooling/data/communities_and_crime_new_version.csv')

# COMPAS Dataset Sensitivity Feature test: African American
# We will check if the race (specifically African-American) is associated with the risk of recidivism
contingency_table_compas = pd.crosstab(compas_df['race'], compas_df['is_recid'])
chi2_stat_compas, p_compas, _, _ = chi2_contingency(contingency_table_compas)

# German Credit Dataset Sensitivity Feature test: Gender
# We will check if gender is associated with being a good customer
contingency_table_german = pd.crosstab(german_df['Gender'], german_df['GoodCustomer'])
chi2_stat_german, p_german, _, _ = chi2_contingency(contingency_table_german)

# Communities and Crime Sensitivity Feature test: Count of White Population
# First, convert the 'ViolentCrimesPerPop numeric' column to numeric
cc_df['ViolentCrimesPerPop numeric'] = pd.to_numeric(cc_df['ViolentCrimesPerPop numeric'], errors='coerce')

# Remove any rows where 'ViolentCrimesPerPop numeric' could not be converted to a number
cc_df = cc_df.dropna(subset=['ViolentCrimesPerPop numeric'])

# Now perform the t-test
cc_df['ViolentCrimeRate'] = cc_df['ViolentCrimesPerPop numeric'].apply(lambda x: 1 if x > cc_df['ViolentCrimesPerPop numeric'].median() else 0)
t_stat_cc, p_cc = ttest_ind(cc_df[cc_df['ViolentCrimeRate'] == 1]['racePctWhite numeric'], 
                            cc_df[cc_df['ViolentCrimeRate'] == 0]['racePctWhite numeric'])

# Interpret and output the results
def interpret_p_value(p_value, feature_name):
    if p_value < 0.05:
        return f"The feature '{feature_name}' is likely a sensitive feature (p-value: {p_value:.4f})."
    else:
        return f"The feature '{feature_name}' is not likely a sensitive feature (p-value: {p_value:.4f})."

print(interpret_p_value(p_compas, "race in COMPAS"))
print(interpret_p_value(p_german, "Gender in German Credit"))
print(interpret_p_value(p_cc, "White Population Percentage in Communities & Crime"))
