for i in range(20):
    print("Hello HPC!")
