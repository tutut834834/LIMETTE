import matplotlib.pyplot as plt
import numpy as np

# Define feature importance data before defense for LIME
lime_feature_importance_before = {
    'No unrelated features': {
        1: [('race', 0.9983818770226537), ('length_of_stay', 0.0016181229773462784)],
        2: [('sex_Male', 0.20388349514563106), ('sex_Female', 0.18770226537216828), ('c_charge_degree_F', 0.1407766990291262), 
            ('c_charge_degree_M', 0.11812297734627832), ('two_year_recid', 0.10679611650485436)],
        3: [('c_charge_degree_F', 0.1423948220064725), ('sex_Female', 0.1423948220064725), ('two_year_recid', 0.1407766990291262), 
            ('sex_Male', 0.127831715210356), ('c_charge_degree_M', 0.11812297734627832)]
    },
    '1 unrelated feature': {
        1: [('unrelated_column_one', 0.9983818770226537), ('length_of_stay', 0.0016181229773462784)],
        2: [('sex_Female', 0.16019417475728157), ('race', 0.13915857605177995), ('c_charge_degree_M', 0.13754045307443366), 
            ('c_charge_degree_F', 0.13592233009708737), ('sex_Male', 0.13592233009708737)],
        3: [('c_charge_degree_M', 0.16666666666666666), ('race', 0.15210355987055016), ('c_charge_degree_F', 0.14724919093851133), 
            ('sex_Male', 0.13915857605177995), ('two_year_recid', 0.1262135922330097)]
    },
    '2 unrelated features': {
        1: [('unrelated_column_two', 0.22491909385113268), ('unrelated_column_one', 0.18608414239482202), 
            ('sex_Female', 0.13754045307443366), ('sex_Male', 0.11488673139158576), ('c_charge_degree_M', 0.09223300970873786)],
        2: [('unrelated_column_one', 0.16019417475728157), ('unrelated_column_two', 0.14724919093851133), 
            ('sex_Female', 0.13915857605177995), ('sex_Male', 0.11326860841423948), ('c_charge_degree_F', 0.10679611650485436)],
        3: [('sex_Male', 0.16990291262135923), ('c_charge_degree_M', 0.11812297734627832), ('two_year_recid', 0.11165048543689321), 
            ('unrelated_column_one', 0.11165048543689321), ('c_charge_degree_F', 0.10679611650485436)]
    }
}

# Function to plot feature importance
def plot_feature_importance(data, title):
    fig, ax = plt.subplots()
    for label, features in data.items():
        x = []
        y = []
        for group, feature_list in features.items():
            for feat, imp in feature_list:
                x.append(feat)
                y.append(imp)
        ax.scatter(x, y, label=label)

    ax.set_xlabel('Features')
    ax.set_ylabel('Importance')
    ax.set_title(title)
    plt.xticks(rotation=90)
    ax.legend(loc='upper right')
    plt.tight_layout()
    plt.show()

# Plot feature importance before defense for LIME
plot_feature_importance(lime_feature_importance_before, 'LIME Feature Importance Before Defense')
