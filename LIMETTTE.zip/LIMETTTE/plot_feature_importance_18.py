import matplotlib
matplotlib.use('Agg')  # Use the 'Agg' backend for non-GUI rendering

from pprint import pprint
import scipy.stats
import numpy as np
import pandas as pd
import subprocess
import matplotlib.pyplot as plt
import seaborn as sns

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector, generate_explanations, load_experiment_and_data, compute_metrics

# Run setup_attacks.py script
subprocess.run(["python3", "unfooling/defense/setup_attacks.py"])

class C:  # Config
    experiment_name = 'COMPAS'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

# Load the experiment and data
P = load_experiment_and_data(C)

# Plotting function to save feature importance rankings
def plot_feature_importance(data, title, filename):
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Frequency at Rank', y='Rank', hue='Feature', data=data, orient='h')
    plt.title(title)
    plt.xlim(0, 1)
    plt.legend(loc='upper right')
    plt.savefig(filename)
    plt.close()
    print(f"Plot saved as {filename}")

# Function to process and plot feature importance
def process_and_plot_feature_importance(explainer_data, filename_suffix):
    biased_features = P.problem.biased_features
    rank_data = {
        'Rank': [],
        'Frequency at Rank': [],
        'Feature': []
    }

    for explainer, expl_expl_data in explainer_data.items():
        for task, expl_expl_task_data in expl_expl_data.items():
            explanations = expl_expl_task_data['explanations']
            y_test_pred_f = expl_expl_task_data['y_test_pred_f_biased']
            if y_test_pred_f is None:
                y_test_pred_f = expl_expl_task_data['y_test_pred']
            for yi, expl in zip(y_test_pred_f, explanations):
                expl = {k.rsplit('=', 1)[0]: v for k, v in expl}
                expl_keys_asc = sorted(expl.keys(), key=lambda x: expl[x])
                for rank in range(1, 4):
                    if len(expl_keys_asc) >= rank:
                        feature = expl_keys_asc[rank-1]
                        if feature in biased_features:
                            feature_type = 'Biased'
                        elif 'unrelated' in feature:
                            feature_type = f'Uncorrelated #{rank}'
                        else:
                            feature_type = 'Other'
                        rank_data['Rank'].append(rank)
                        rank_data['Frequency at Rank'].append(1)
                        rank_data['Feature'].append(feature_type)

    rank_df = pd.DataFrame(rank_data)
    rank_df = rank_df.groupby(['Rank', 'Feature']).size().reset_index(name='Frequency')
    rank_df['Frequency at Rank'] = rank_df['Frequency'] / len(y_test_pred_f)

    # Create the plot
    plot_title = f"Feature Importance {filename_suffix}"
    plot_filename = f"feature_importance_{filename_suffix.replace(' ', '_').lower()}.png"
    plot_feature_importance(rank_df, plot_title, plot_filename)

# Generate explanations for "No Attack"
explainer_data_no_attack = generate_explanations(C, P)
process_and_plot_feature_importance(explainer_data_no_attack, "No Attack")

# Simulate an attack and generate explanations
C.detector_name = 'Attack'
explainer_data_attack = generate_explanations(C, P)
process_and_plot_feature_importance(explainer_data_attack, "With Attack")

# Generate explanations with defense
hparams = dict(
    distance_agg='max',
    metric='minkowski',
    epsilon=0.1,
    n_neighbors=15,
    p=1,
    n_jobs=-1,
)
results, detectors = evaluate_detector(C, P, explainer_data_attack, hparams)
explainer_data_defense = generate_explanations(C, P, robustness_model=detectors)
process_and_plot_feature_importance(explainer_data_defense, "With Defense")

print("Plots and calculations completed.")
