from pprint import pprint
import scipy.stats
import numpy as np
import pandas as pd
import tensorflow as tf

from unfooling.pipeline import evaluate_detector, generate_explanations, load_experiment_and_data, compute_metrics

# Download and load the MNIST dataset
class ImageDatasetProblem:
    def __init__(self):
        self.X_train, self.y_train, self.X_test, self.y_test = self.load_and_preprocess_data()

    def load_and_preprocess_data(self):
        # Load MNIST dataset
        (train_images, train_labels), (test_images, test_labels) = tf.keras.datasets.mnist.load_data()
        # Normalize images to [0, 1]
        train_images = train_images.astype("float32") / 255.0
        test_images = test_images.astype("float32") / 255.0
        return train_images, train_labels, test_images, test_labels

P = ImageDatasetProblem()  # Initialize and load the dataset

class C:  # Config
    experiment_name = 'ImageDataset'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

# Generate explanations for the dataset
explainer_data = generate_explanations(
    C, P,
    num_samples_explain=int(0.01 * len(P.X_train))  # 1% of the training samples
)

C.detector_name = 'KNNCAD'
hparams = dict(
    distance_agg='max',
    metric='minkowski',
    epsilon=0.1,
    n_neighbors=15,
    p=1,
    n_jobs=-1,
)
print(f'Using hparams for {C.detector_name}:')
pprint(hparams)

n_explainer_samples = len(P.X_train) * 10
print('n_explainer_samples', n_explainer_samples)
results, detectors = evaluate_detector(C, P, explainer_data, hparams,
                                       n_explainer_samples=n_explainer_samples)

replace_strs = {
    'delta': 'Δ',
    'explainer': 'expl',
    'pct': '%',
    'threshold': 'thresh',
    'robust': 'R',
    'greater': '>',
    'under': '<',
    'normalized': 'norm',
}

scores = []
for result in results:
    score = compute_metrics(result)
    for k, v in [*score.items()]:
        k_orig = k
        for a, b in replace_strs.items():
            k = k.replace(a, b)
        score[k] = score.pop(k_orig)
    score.update(
        explainer=result.meta.explainer,
        innocuous_model=result.meta.innocuous_model,
    )
    scores.append(score)

score_df = pd.DataFrame(scores)
print(score_df)

# Example output and processing for image data fidelity
biased_features = []  # Define biased features if any
n_feats = np.prod(P.X_train.shape[1:])  # Total number of features in the image

for explainer, expl_expl_data in explainer_data.items():
    for task, expl_expl_task_data in expl_expl_data.items():
        explanations = expl_expl_task_data['explanations']
        y_test_pred_f = expl_expl_task_data['y_test_pred_f_biased']
        if y_test_pred_f is None:
            y_test_pred_f = expl_expl_task_data['y_test_pred']
        score = 0
        for yi, expl in zip(y_test_pred_f, explanations):
            expl = {k.rsplit('=', 1)[0]: v for k, v in expl}
            # ascending
            expl_keys_asc = sorted(expl.keys(), key=lambda x: expl[x])
            f_ranks = []
            expl_ranks = []
            for feat in biased_features:  # Modify based on image features
                f_ranks.append(n_feats - 1)
                try:
                    expl_ranks.append(expl_keys_asc.index(feat))
                except ValueError:
                    expl_ranks.append(0)
            score += scipy.stats.spearmanr(expl_ranks, f_ranks)[0]
        score /= len(explanations)
        print('fidelity_g', explainer, task, score)

# Proceed with the defense evaluation similarly
explainer_data_defense = generate_explanations(
    C, P,
    robustness_model=detectors,
    num_samples_explain=10
)

# Continue evaluating the defenses as before
