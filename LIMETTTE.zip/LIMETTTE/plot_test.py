import matplotlib.pyplot as plt
import numpy as np

# Data from the summary table
lime_data = {
    'Racist model only': {
        '1st': {'Race': 0.592},
        '2nd': {'Two-Year Recidivism': 0.061, 'Length of Stay': 0.056, 'Sex (Female)': 0.055, 'Age': 0.045},
    },
    '1 Unrelated Feature': {
        '1st': {'Unrelated Column One': 0.531},
        '2nd': {'Race': 0.094, 'Charge Degree (M)': 0.059, 'Two-Year Recidivism': 0.056, 'Sex (Female)': 0.055},
    },
    '2 Unrelated Features': {
        '1st': {'Race': 0.453},
        '2nd': {'Unrelated Column One': 0.074, 'Unrelated Column Two': 0.071, 'Sex (Female)': 0.064, 'Age': 0.053},
    }
}

shap_data = {
    'Racist model only': {
        '1st': {'Race': 0.468},
        '2nd': {'Length of Stay': 0.094, 'Charge Degree (F)': 0.087, 'Age': 0.065, 'Charge Degree (M)': 0.063},
    },
    '1 Unrelated Feature': {
        '1st': {'Unrelated Column One': 0.193},
        '2nd': {'Race': 0.185, 'Length of Stay': 0.133, 'Charge Degree (F)': 0.094, 'Charge Degree (M)': 0.071},
    },
    '2 Unrelated Features': {
        '1st': {'Race': 0.241},
        '2nd': {'Length of Stay': 0.126, 'Unrelated Column One': 0.100, 'Charge Degree (F)': 0.086, 'Age': 0.070},
    }
}

# Colors for the features
colors = {
    'Race': '#FF7F0E',
    'Two-Year Recidivism': '#1F77B4',
    'Length of Stay': '#AEC7E8',
    'Sex (Female)': '#FF9896',
    'Age': '#98DF8A',
    'Unrelated Column One': '#C49C94',
    'Unrelated Column Two': '#9467BD',
    'Charge Degree (M)': '#C5B0D5',
    'Charge Degree (F)': '#8C564B',
}

# Plotting function
def plot_bar(ax, data, title):
    categories = ['1st', '2nd']
    for i, category in enumerate(categories):
        labels = list(data[category].keys())
        values = list(data[category].values())
        bottoms = np.cumsum([0] + values[:-1])
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xticks(np.arange(0, 101, 20))
    ax.set_xlabel('% Importance')
    ax.set_ylabel('Rank')

# Create the plots for LIME and SHAP
fig, axs = plt.subplots(2, 3, figsize=(18, 12))

plot_bar(axs[0, 0], lime_data['Racist model only'], 'LIME: Racist model only')
plot_bar(axs[0, 1], lime_data['1 Unrelated Feature'], 'LIME: 1 Unrelated Feature')
plot_bar(axs[0, 2], lime_data['2 Unrelated Features'], 'LIME: 2 Unrelated Features')

plot_bar(axs[1, 0], shap_data['Racist model only'], 'SHAP: Racist model only')
plot_bar(axs[1, 1], shap_data['1 Unrelated Feature'], 'SHAP: 1 Unrelated Feature')
plot_bar(axs[1, 2], shap_data['2 Unrelated Features'], 'SHAP: 2 Unrelated Features')

# Adding the legend
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
fig.legend(handles, labels, loc='upper center', ncol=4, bbox_to_anchor=(0.5, -0.05))

plt.tight_layout()
plt.show()
