import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Data for LIME and SHAP for all 5 runs, including 'Attack 1 Defense' and 'Attack 2 Defense'
lime_data = {
    'Run 1 - No Attack': {
        '1st': {'racePctWhite': 0.735, 'unrelated_column_two': 0.025, 'unrelated_column_one': 0.015},
        '2nd': {'unrelated_column_one': 0.14, 'unrelated_column_two': 0.12},
        '3rd': {'unrelated_column_two': 0.085, 'unrelated_column_one': 0.05}
    },
    'Run 1 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.16},
        '3rd': {'unrelated_column_two': 0.06}
    },
    'Run 1 - Attack 2': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.21},
        '3rd': {'unrelated_column_two': 0.17}
    },
    'Run 1 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.17},
        '3rd': {'unrelated_column_two': 0.065}
    },
    'Run 1 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.23},
        '3rd': {'unrelated_column_two': 0.18}
    },
    'Run 2 - No Attack': {
        '1st': {'racePctWhite': 0.71, 'unrelated_column_one': 0.04, 'OwnOccLowQuart': 0.015},
        '2nd': {'unrelated_column_one': 0.135, 'unrelated_column_two': 0.11},
        '3rd': {'unrelated_column_one': 0.07, 'unrelated_column_two': 0.065}
    },
    'Run 2 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.135},
        '3rd': {'unrelated_column_two': 0.075}
    },
    'Run 2 - Attack 2': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.22},
        '3rd': {'unrelated_column_two': 0.08}
    },
    'Run 2 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.225},
        '3rd': {'unrelated_column_two': 0.08}
    },
    'Run 2 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.23},
        '3rd': {'unrelated_column_two': 0.12}
    },
    'Run 3 - No Attack': {
        '1st': {'racePctWhite': 0.74, 'unrelated_column_one': 0.055},
        '2nd': {'unrelated_column_one': 0.115, 'unrelated_column_two': 0.115},
        '3rd': {'unrelated_column_one': 0.09, 'unrelated_column_two': 0.065}
    },
    'Run 3 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.1},
        '3rd': {'unrelated_column_two': 0.075}
    },
    'Run 3 - Attack 2': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.225},
        '3rd': {'unrelated_column_two': 0.09}
    },
    'Run 3 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.23},
        '3rd': {'unrelated_column_two': 0.11}
    },
    'Run 3 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.22},
        '3rd': {'unrelated_column_two': 0.13}
    },
    'Run 4 - No Attack': {
        '1st': {'racePctWhite': 0.725, 'unrelated_column_one': 0.055},
        '2nd': {'unrelated_column_one': 0.115, 'unrelated_column_two': 0.1},
        '3rd': {'unrelated_column_one': 0.06, 'unrelated_column_two': 0.06}
    },
    'Run 4 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.15},
        '3rd': {'unrelated_column_two': 0.075}
    },
    'Run 4 - Attack 2': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.22},
        '3rd': {'unrelated_column_two': 0.08}
    },
    'Run 4 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.225},
        '3rd': {'unrelated_column_two': 0.11}
    },
    'Run 4 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.23},
        '3rd': {'unrelated_column_two': 0.12}
    },
    'Run 5 - No Attack': {
        '1st': {'racePctWhite': 0.73, 'unrelated_column_two': 0.03},
        '2nd': {'unrelated_column_two': 0.12, 'unrelated_column_one': 0.105},
        '3rd': {'unrelated_column_two': 0.075, 'unrelated_column_one': 0.06}
    },
    'Run 5 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.115},
        '3rd': {'unrelated_column_two': 0.075}
    },
    'Run 5 - Attack 2': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.225},
        '3rd': {'unrelated_column_two': 0.12}
    },
    'Run 5 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.23},
        '3rd': {'unrelated_column_two': 0.12}
    },
    'Run 5 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.23},
        '3rd': {'unrelated_column_two': 0.12}
    }
}

shap_data = {
    'Run 1 - No Attack': {
        '1st': {'racePctWhite': 0.75, 'MedNumBR': 0.015},
        '2nd': {'Nothing shown': 0.85},
        '3rd': {'Nothing shown': 0.85}
    },
    'Run 1 - Attack 1': {
        '1st': {'unrelated_column_one': 0.235},
        '2nd': {'racePctWhite': 0.07},
        '3rd': {'unrelated_column_one': 0.055}
    },
    'Run 1 - Attack 2': {
        '1st': {'unrelated_column_one': 0.145},
        '2nd': {'racePctWhite': 0.075},
        '3rd': {'unrelated_column_one': 0.055}
    },
    'Run 1 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 0.145},
        '2nd': {'racePctWhite': 0.065},
        '3rd': {'unrelated_column_one': 0.06}
    },
    'Run 1 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 0.12},
        '2nd': {'racePctWhite': 0.075},
        '3rd': {'unrelated_column_one': 0.05}
    },
    'Run 2 - No Attack': {
        '1st': {'racePctWhite': 0.705, 'OwnOccMedVal': 0.015},
        '2nd': {'Nothing shown': 0.7},
        '3rd': {'Nothing shown': 0.7}
    },
    'Run 2 - Attack 1': {
        '1st': {'unrelated_column_one': 0.255},
        '2nd': {'racePctWhite': 0.085},
        '3rd': {'unrelated_column_one': 0.065}
    },
    'Run 2 - Attack 2': {
        '1st': {'unrelated_column_one': 0.195},
        '2nd': {'racePctWhite': 0.065},
        '3rd': {'unrelated_column_one': 0.045}
    },
    'Run 2 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 0.195},
        '2nd': {'racePctWhite': 0.075},
        '3rd': {'unrelated_column_one': 0.045}
    },
    'Run 2 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 0.18},
        '2nd': {'racePctWhite': 0.07},
        '3rd': {'unrelated_column_one': 0.06}
    },
    'Run 3 - No Attack': {
        '1st': {'racePctWhite': 0.63, 'PctIlleg': 0.02},
        '2nd': {'Nothing shown': 0.62},
        '3rd': {'Nothing shown': 0.62}
    },
    'Run 3 - Attack 1': {
        '1st': {'unrelated_column_one': 0.195},
        '2nd': {'racePctWhite': 0.065},
        '3rd': {'unrelated_column_one': 0.045}
    },
    'Run 3 - Attack 2': {
        '1st': {'unrelated_column_one': 0.15},
        '2nd': {'racePctWhite': 0.075},
        '3rd': {'unrelated_column_one': 0.055}
    },
    'Run 3 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 0.145},
        '2nd': {'racePctWhite': 0.075},
        '3rd': {'unrelated_column_one': 0.065}
    },
    'Run 3 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 0.12},
        '2nd': {'racePctWhite': 0.08},
        '3rd': {'unrelated_column_one': 0.055}
    },
    'Run 4 - No Attack': {
        '1st': {'racePctWhite': 0.655, 'PctKids2Par': 0.02},
        '2nd': {'Nothing shown': 0.655},
        '3rd': {'Nothing shown': 0.655}
    },
    'Run 4 - Attack 1': {
        '1st': {'unrelated_column_one': 0.275},
        '2nd': {'racePctWhite': 0.075},
        '3rd': {'unrelated_column_one': 0.045}
    },
    'Run 4 - Attack 2': {
        '1st': {'unrelated_column_one': 0.195},
        '2nd': {'racePctWhite': 0.065},
        '3rd': {'unrelated_column_one': 0.045}
    },
    'Run 4 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 0.145},
        '2nd': {'racePctWhite': 0.075},
        '3rd': {'unrelated_column_one': 0.055}
    },
    'Run 4 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 0.12},
        '2nd': {'racePctWhite': 0.065},
        '3rd': {'unrelated_column_one': 0.06}
    },
    'Run 5 - No Attack': {
        '1st': {'racePctWhite': 0.65, 'unrelated_column_two': 0.025},
        '2nd': {'Nothing shown': 0.65},
        '3rd': {'Nothing shown': 0.65}
    },
    'Run 5 - Attack 1': {
        '1st': {'unrelated_column_one': 0.265},
        '2nd': {'racePctWhite': 0.08},
        '3rd': {'unrelated_column_one': 0.03}
    },
    'Run 5 - Attack 2': {
        '1st': {'unrelated_column_one': 0.145},
        '2nd': {'racePctWhite': 0.07},
        '3rd': {'unrelated_column_one': 0.045}
    },
    'Run 5 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 0.235},
        '2nd': {'racePctWhite': 0.065},
        '3rd': {'unrelated_column_one': 0.055}
    },
    'Run 5 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 0.12},
        '2nd': {'racePctWhite': 0.07},
        '3rd': {'unrelated_column_one': 0.06}
    }
}

# Color mapping for features
colors = {
    'racePctWhite': '#FF7F0E',
    'unrelated_column_two': '#1F77B4',
    'unrelated_column_one': '#2CA02C',
    'MedNumBR': '#D62728',
    'Nothing shown': '#7F7F7F',
    'OwnOccLowQuart': '#9467BD',
    'PctIlleg': '#C49C94',
    'PctKids2Par': '#E377C2',
    'OwnOccMedVal': '#8C564B'
}

# Adjust the subplot grid to have 10 columns to accommodate all the scenarios (5 for LIME, 5 for SHAP)
fig, axs = plt.subplots(5, 10, figsize=(30, 30))  # 5 rows for each run, 10 columns for each scenario

# Plotting LIME scenarios for all 5 runs (No Attack, Attack 1, Attack 1 Defense, Attack 2, Attack 2 Defense)
for i in range(5):
    run_name = f'Run {i+1}'
    plot_bar(axs[i, 0], lime_data[f'{run_name} - No Attack'], f'{run_name} - LIME: No Attack', colors)
    plot_bar(axs[i, 1], lime_data[f'{run_name} - Attack 1'], f'{run_name} - LIME: Attack 1', colors)
    plot_bar(axs[i, 2], lime_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - LIME: Attack 1 Defense', colors)
    plot_bar(axs[i, 3], lime_data[f'{run_name} - Attack 2'], f'{run_name} - LIME: Attack 2', colors)
    plot_bar(axs[i, 4], lime_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - LIME: Attack 2 Defense', colors)

    # Plotting SHAP scenarios for all 5 runs (No Attack, Attack 1, Attack 1 Defense, Attack 2, Attack 2 Defense)
    plot_bar(axs[i, 5], shap_data[f'{run_name} - No Attack'], f'{run_name} - SHAP: No Attack', colors)
    plot_bar(axs[i, 6], shap_data[f'{run_name} - Attack 1'], f'{run_name} - SHAP: Attack 1', colors)
    plot_bar(axs[i, 7], shap_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - SHAP: Attack 1 Defense', colors)
    plot_bar(axs[i, 8], shap_data[f'{run_name} - Attack 2'], f'{run_name} - SHAP: Attack 2', colors)
    plot_bar(axs[i, 9], shap_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - SHAP: Attack 2 Defense', colors)

# Adding the legend
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.05), fontsize=12)

# Adjust the layout for better visualization
plt.tight_layout()

# Save the plot as a PNG file
plt.savefig("attack_defense_graph_runs_cccccc_final_big_plot.png", bbox_inches='tight', dpi=300)
plt.savefig("attack_defense_graph_runs_caaaaaaaaaaccccc_final_big_plot.jpeg", bbox_inches='tight', dpi=300)

# Show the plot
plt.show()
