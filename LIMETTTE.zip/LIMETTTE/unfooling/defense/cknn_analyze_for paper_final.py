import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.base import OutlierMixin, BaseEstimator
from sklearn.neighbors import KNeighborsClassifier, KernelDensity, NearestNeighbors
from statsmodels.tsa.arima.model import ARIMA
from arch import arch_model

np.set_printoptions(threshold=np.inf)
dynamic_thresholds1 = []
dynamic_thresholds2 = []
recent_scoreslist1 = []
lipschitzlink = []
trust_score_list = []
noisy_scores_list = []  # Store noisy scores for plotting
original_scores_list = []  # Store original scores

class KNNCAD(OutlierMixin, BaseEstimator):

    def __init__(
            self,
            approach='distance',  # Default to 'distance'
            distance_agg='median',
            epsilon=0.05,
            n_neighbors=20,
            weights='distance',
            algorithm='auto',
            distance_penalize_accurate=True,
            leaf_size=None,
            p=2,
            metric=None,
            metric_params=None,
            n_jobs=-1,
            bandwidth=1.0,
            atol=0,
            rtol=0,
            breadth_first=True,
            radius=1.0,
            window_size=100,
            alpha=1.0,
            beta=0.1,
            arima_order=(5, 1, 0),
            garch_p=2,
            garch_q=2,
            lipschitz_constant=1.0,
            gamma=0.01
    ):
        self.approach = approach
        self.epsilon = epsilon
        self.window_size = window_size
        self.alpha = alpha
        self.beta = beta
        self.arima_order = arima_order
        self.garch_p = garch_p
        self.garch_q = garch_q
        self.lipschitz_constant = lipschitz_constant
        self.gamma = gamma
        self.recent_scores = []
        self.trust_score = 1.0
        self.threshold_ = None
        self.arima_model_ = None
        self.garch_model_ = None
        self.arima_preds = []
        self.garch_vols = []
        self.lipschitz_adjustments = []
        self.privacy_scores = []

        self.distance_agg = self._get_agg_function(distance_agg)
        self.distance_penalize_accurate = distance_penalize_accurate

        if approach == 'distance':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = NearestNeighbors(
                n_neighbors=n_neighbors,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                radius=radius,
                n_jobs=n_jobs,
            )
        else:
            raise ValueError(f"Unknown approach: {approach}")

    def _get_agg_function(self, agg):
        """Convert a string aggregation function name to an actual numpy function."""
        if isinstance(agg, str):
            if agg in ['mean', 'median', 'max', 'min', 'sum']:
                return getattr(np, agg)
            else:
                raise ValueError(f"Unknown aggregation function: {agg}")
        return agg

    def fit(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        print("Fitting the model...")
        self.X_train, self.y_train = X, y
        self._estimator.fit(X, y)

        # Fit ARIMA model on the output (y) to capture temporal dependencies
        self.arima_model_ = ARIMA(y, order=self.arima_order).fit()

        # Residuals from ARIMA model
        residuals = self.arima_model_.resid
        residual_variance = np.var(residuals)
        print("Variance of Residuals:", residual_variance)
        if residual_variance < 1e-5:
            print("Warning: Low variability in residuals, GARCH may not perform well.")
    
        # Differencing the residuals to ensure stationarity
        diff_residuals = np.diff(residuals)
        self.garch_model_ = arch_model(diff_residuals, p=self.garch_p, q=self.garch_q).fit(disp="on")

        self.garch_vols = self.garch_model_.conditional_volatility[:len(diff_residuals)]

        # Determine initial static threshold
        scores = self.score_samples(X, y)

        # Store original scores for comparison
        original_scores_list.append(scores.copy())

        # Apply differential privacy noise
        noisy_scores = self.differential_privacy_noise(scores)
        noisy_scores_list.append(noisy_scores.copy())

        # Sort the noisy scores and get the initial threshold based on epsilon
        noisy_scores.sort()
        thresh_idx = round(self.epsilon * len(X))
        self.threshold_ = noisy_scores[thresh_idx]

        # Update dynamic thresholds based on recent scores
        dynamic_thresholds1.append(self.threshold_)

        # If we have enough recent scores, update the threshold dynamically
        if len(self.recent_scores) < self.window_size:
            self.threshold_ = noisy_scores[thresh_idx]
        else:
            mean_score = np.mean(self.recent_scores)
            variance_score = np.var(self.recent_scores)
            self.threshold_ = mean_score + self.alpha * variance_score
        
        # Adjust the threshold based on trust_score
        trust_adjusted_threshold = self.trust_aware_threshold(self.threshold_)
        dynamic_thresholds2.append(trust_adjusted_threshold)
        print("Trust score list: ", trust_score_list)
        print(f"Adjusted Threshold using Trust Score: {trust_adjusted_threshold}")

        # Update the trust score based on the final adjusted threshold
        self.update_trust_score(trust_adjusted_threshold)

        # Save the trust score and check for plotting
        trust_score_list.append(self.trust_score)
        self.check_and_plot_trust_scores()

        # Plot noisy and original scores
        self.plot_noisy_scores()

        return self

    def plot_noisy_scores(self):
        """Plot comparisons between original and noisy scores, and visualize Laplace noise."""
        fig, axs = plt.subplots(2, 2, figsize=(14, 10))

        # Plot 1: Original Scores Distribution
        axs[0, 0].hist(np.concatenate(original_scores_list), bins=50, color='blue', alpha=0.5, label='Original Scores')
        axs[0, 0].set_title("Original Scores Distribution")
        axs[0, 0].set_xlabel("Score")
        axs[0, 0].set_ylabel("Frequency")
        axs[0, 0].legend()

        # Plot 2: Noisy Scores Distribution
        axs[0, 1].hist(np.concatenate(noisy_scores_list), bins=50, color='red', alpha=0.5, label='Noisy Scores')
        axs[0, 1].set_title("Noisy Scores Distribution (Differential Privacy)")
        axs[0, 1].set_xlabel("Noisy Score")
        axs[0, 1].set_ylabel("Frequency")
        axs[0, 1].legend()

        # Plot 3: Original vs Noisy Scores Over Time
        axs[1, 0].plot(np.concatenate(original_scores_list), label="Original Scores", color='blue', alpha=0.7)
        axs[1, 0].plot(np.concatenate(noisy_scores_list), label="Noisy Scores", color='red', alpha=0.7)
        axs[1, 0].set_title("Original vs Noisy Scores Over Time")
        axs[1, 0].set_xlabel("Data Point Index")
        axs[1, 0].set_ylabel("Score")
        axs[1, 0].legend()

        # Plot 4: Laplace Noise Distribution
        noise = np.random.laplace(0, 1.0 / self.epsilon, size=1000)
        axs[1, 1].hist(noise, bins=50, color='green', alpha=0.5, label='Laplace Noise')
        axs[1, 1].set_title("Laplace Noise Distribution (Differential Privacy)")
        axs[1, 1].set_xlabel("Noise Value")
        axs[1, 1].set_ylabel("Frequency")
        axs[1, 1].legend()

        plt.tight_layout()
        plt.show()

    def differential_privacy_noise(self, scores):
        """Applies differential privacy noise to the scores."""
        noise = np.random.laplace(0, 1.0 / self.epsilon, size=scores.shape)
        noisy_scores = scores + noise
        return noisy_scores

    def score_samples(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        if self.approach == 'clf':
            probas = self._estimator.predict_proba(X)
            scores = probas[np.arange(len(y)), y]
        elif self.approach == 'distance':
            dists, idxs = self._estimator.kneighbors(X)
            scores = self.calculate_distance_scores(dists, idxs, y)
        elif self.approach == 'density':
            scores = self._estimator.score_samples(X)
        else:
            raise RuntimeError(self.approach)

        arima_pred = self.arima_model_.predict(start=0, end=len(y) - 1)
        garch_pred = self.garch_vols[:len(y)]

        # Ensure GARCH and ARIMA predictions match in size
        if garch_pred.shape[0] != arima_pred.shape[0]:
            garch_pred = np.resize(garch_pred, arima_pred.shape)

        lipschitz_adjustment = self.calculate_lipschitz_adjustment(arima_pred, garch_pred)

        self.arima_preds = arima_pred
        self.garch_vols = garch_pred
        self.lipschitz_adjustments = lipschitz_adjustment
        self.privacy_scores = scores

        scores += arima_pred + garch_pred + lipschitz_adjustment

        self.recent_scores.extend(scores)
        recent_scoreslist1.append(self.recent_scores)

        if len(self.recent_scores) > self.window_size:
            self.recent_scores = self.recent_scores[-self.window_size:]

        return scores

    def calculate_dynamic_threshold(self, scores):
        if len(self.recent_scores) < self.window_size:
            return self.threshold_

        mean_score = np.mean(self.recent_scores)
        variance_score = np.var(self.recent_scores)
        dynamic_threshold = mean_score + self.alpha * variance_score
        return dynamic_threshold

    def update_trust_score(self, new_score):
        self.trust_score = max(0, min(1, self.trust_score - (0.1 * new_score)))

    def trust_aware_threshold(self, dynamic_threshold):
        trust_adjusted_threshold = dynamic_threshold - (1 - self.trust_score) * self.beta
        return trust_adjusted_threshold

    def calculate_lipschitz_adjustment(self, arima_pred, garch_pred):
        """Calculates the Lipschitz adjustment between ARIMA and GARCH predictions."""
        adjustment = self.gamma * np.abs(garch_pred - arima_pred)
        self.lipschitz_constant += adjustment.mean()
        lipschitzlink.append(self.lipschitz_constant)
        return self.lipschitz_constant * adjustment

    def calculate_distance_scores(self, dists, idxs, y):
        scores = []
        for dist, idx, yi in zip(dists, idxs, y):
            yi = int(yi)
            assert yi in {0, 1}, yi

            pop_yi = self.y_train[idx]
            dist_0 = self.calculate_aggregate_distance(dist, pop_yi, 0)
            dist_1 = self.calculate_aggregate_distance(dist, pop_yi, 1)

            if yi == 1:
                dist_yi, dist_other = dist_1, dist_0
            else:
                dist_yi, dist_other = dist_0, dist_1

            score = self.calculate_score(dist_yi, dist_other)
            scores.append(score)
        return np.asarray(scores)

    def calculate_aggregate_distance(self, dist, pop_yi, class_label):
        where_class = np.where(pop_yi == class_label)
        dists_class = dist[where_class]
        if dists_class.size:
            return self.distance_agg(dists_class)
        else:
            return np.inf

    def calculate_score(self, dist_yi, dist_other):
        if not self.distance_penalize_accurate and dist_yi < dist_other:
            return 1.0
        else:
            if dist_yi == dist_other == 0:
                return 1.0
            else:
                with np.errstate(divide='ignore'):
                    return 1 / (1 + dist_yi / dist_other)

    def save_results_to_csv(self, filename='results.csv'):
        """Save ARIMA predictions, GARCH volatility, Lipschitz adjustments, and Privacy scores to a CSV file."""
        df = pd.DataFrame({
            'ARIMA Predictions': self.arima_preds,
            'GARCH Volatility': self.garch_vols,
            'Lipschitz Adjustments': self.lipschitz_adjustments,
            'Privacy Scores': self.privacy_scores
        })
        df.to_csv(filename, index=False)
        print(f"Results saved to {filename}")

    def check_and_plot_trust_scores(self):
        """Check if trust score list exceeds 4000 and plot similar to Lipschitz logic."""
        if len(trust_score_list) > 4000:
            print(f"Trust scores list has exceeded 4000 elements. Proceeding with plots.")

            # Calculate the moving average
            window_size = 100
            if len(trust_score_list) >= window_size:
                moving_avg_trust = np.convolve(trust_score_list, np.ones(window_size) / window_size, mode='valid')
                moving_avg_x = range(window_size - 1, len(trust_score_list))
            else:
                moving_avg_trust = []
                moving_avg_x = []

            # Set up the different visualizations for the Trust scores
            fig, axs = plt.subplots(2, 2, figsize=(14, 10))

            # Plot 1: Complete time series with moving average for Trust scores
            axs[0, 0].plot(trust_score_list, label="Trust Scores", alpha=0.7)
            if len(moving_avg_trust) > 0:
                axs[0, 0].plot(moving_avg_x, moving_avg_trust, color='red', label="Moving Avg", linewidth=2)
            axs[0, 0].set_title("Trust Scores with Moving Average")
            axs[0, 0].set_xlabel("Time")
            axs[0, 0].set_ylabel("Score")
            axs[0, 0].legend()

            # Plot 2: Distribution of Trust scores
            axs[0, 1].hist(trust_score_list, bins=50, color='skyblue', edgecolor='black')
            axs[0, 1].set_title("Histogram of Trust Scores")
            axs[0, 1].set_xlabel("Trust Score")
            axs[0, 1].set_ylabel("Frequency")

            # Plot 3: Z-scores for Trust values
            mean_trust = np.mean(trust_score_list)
            std_trust = np.std(trust_score_list)
            z_scores_trust = (trust_score_list - mean_trust) / std_trust
            axs[1, 0].plot(z_scores_trust, color='orange', label="Z-scores")
            axs[1, 0].axhline(3, color='red', linestyle='--', label="Threshold (+3 SD)")
            axs[1, 0].axhline(-3, color='red', linestyle='--', label="Threshold (-3 SD)")
            axs[1, 0].set_title("Z-Scores of Trust Scores (Anomaly Detection)")
            axs[1, 0].set_xlabel("Time")
            axs[1, 0].set_ylabel("Z-score")
            axs[1, 0].legend()

            # Plot 4: Trust scores segmented into early, middle, and late portions (boxplot)
            early_trust = trust_score_list[:len(trust_score_list)//3]
            middle_trust = trust_score_list[len(trust_score_list)//3:2*len(trust_score_list)//3]
            late_trust = trust_score_list[2*len(trust_score_list)//3:]

            axs[1, 1].boxplot([early_trust, middle_trust, late_trust], labels=['Early', 'Middle', 'Late'])
            axs[1, 1].set_title("Segmented Trust Scores (Early, Middle, Late)")
            axs[1, 1].set_ylabel("Trust Score")

            plt.tight_layout()
            plt.show()
