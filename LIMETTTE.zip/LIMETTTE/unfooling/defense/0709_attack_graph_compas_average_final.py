import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Average data calculated from the 5 runs
lime_data_avg = {
    'No Attack': {
        '1st': {'race': 0.9913, 'length_of_stay': 0.0081},
        '2nd': {'sex_Female': 0.1754, 'sex_Male': 0.1666, 'c_charge_degree_M': 0.1417, 
                'unrelated_column_two': 0.1265, 'unrelated_column_one': 0.1186},
        '3rd': {'sex_Female': 0.1490, 'unrelated_column_two': 0.1417, 'c_charge_degree_F': 0.1267, 
                'unrelated_column_one': 0.1244, 'two_year_recid': 0.1181},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.9926, 'length_of_stay': 0.0074},
        '2nd': {'sex_Male': 0.1728, 'sex_Female': 0.1543, 'c_charge_degree_M': 0.1481, 
                'two_year_recid': 0.1278, 'c_charge_degree_F': 0.1262},
        '3rd': {'two_year_recid': 0.1555, 'c_charge_degree_F': 0.1426, 'sex_Female': 0.1367, 
                'c_charge_degree_M': 0.1270, 'sex_Male': 0.1245},
    },
    'Attack 2': {
        '1st': {'sex_Female': 0.1682, 'sex_Male': 0.1484, 'unrelated_column_one': 0.1186, 
                'unrelated_column_two': 0.1162, 'c_charge_degree_M': 0.1100},
        '2nd': {'sex_Female': 0.1309, 'unrelated_column_two': 0.1262, 'sex_Male': 0.1197, 
                'unrelated_column_one': 0.1197, 'c_charge_degree_F': 0.1181},
        '3rd': {'c_charge_degree_M': 0.1278, 'c_charge_degree_F': 0.1197, 'unrelated_column_two': 0.1165, 
                'race': 0.1133, 'two_year_recid': 0.1133},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.5490, 'race': 0.0820, 'sex_Female': 0.0666, 
                'two_year_recid': 0.0470, 'length_of_stay': 0.0450},
        '2nd': {'race': 0.3395, 'unrelated_column_one': 0.1889, 'sex_Female': 0.0834, 
                'c_charge_degree_M': 0.0731, 'two_year_recid': 0.0694},
        '3rd': {'sex_Female': 0.1246, 'c_charge_degree_M': 0.1081, 'c_charge_degree_F': 0.1045, 
                'age': 0.0982, 'unrelated_column_two': 0.0965},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.4637, 'unrelated_column_one': 0.0807, 'c_charge_degree_M': 0.0615, 
                'unrelated_column_two': 0.0600, 'sex_Female': 0.0611},
        '2nd': {'race': 0.1555, 'c_charge_degree_M': 0.1091, 'unrelated_column_one': 0.1081, 
                'unrelated_column_two': 0.1037, 'sex_Female': 0.0975},
        '3rd': {'sex_Female': 0.1176, 'unrelated_column_two': 0.1090, 'unrelated_column_one': 0.1076, 
                'two_year_recid': 0.0999, 'c_charge_degree_M': 0.0990},
    }
}

shap_data_avg = {
    'No Attack': {
        '1st': {'race': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.6197, 'race': 0.2201, 'length_of_stay': 0.1262, 
                'age': 0.0081, 'sex_Female': 0.0065},
        '2nd': {'race': 0.3560, 'unrelated_column_one': 0.2379, 'length_of_stay': 0.1618, 
                'age': 0.0696, 'priors_count': 0.0372},
        '3rd': {'race': 0.1505, 'priors_count': 0.1343, 'age': 0.1327, 
                'length_of_stay': 0.0955, 'c_charge_degree_F': 0.0906},
    },
    'Attack 2': {
        '1st': {'race': 0.4676, 'length_of_stay': 0.1521, 'unrelated_column_one': 0.1408, 
                'unrelated_column_two': 0.1375, 'age': 0.0243},
        '2nd': {'unrelated_column_two': 0.2362, 'unrelated_column_one': 0.2314, 'length_of_stay': 0.1408, 
                'race': 0.1327, 'age': 0.0566},
        '3rd': {'unrelated_column_one': 0.1796, 'unrelated_column_two': 0.1537, 'race': 0.1424, 
                'priors_count': 0.0971, 'age': 0.0890},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.1926, 'race': 0.1845, 'length_of_stay': 0.1327, 
                'c_charge_degree_F': 0.0939, 'c_charge_degree_M': 0.0712},
        '2nd': {'race': 0.1359, 'c_charge_degree_M': 0.1230, 'c_charge_degree_F': 0.1117, 
                'unrelated_column_one': 0.1019, 'age': 0.0809},
        '3rd': {'c_charge_degree_F': 0.1052, 'priors_count': 0.1036, 'c_charge_degree_M': 0.0955, 
                'sex_Female': 0.0955, 'unrelated_column_two': 0.0922},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.2411, 'length_of_stay': 0.1262, 'unrelated_column_one': 0.1003, 
                'c_charge_degree_F': 0.0858, 'age': 0.0696},
        '2nd': {'unrelated_column_one': 0.1197, 'unrelated_column_two': 0.1019, 'c_charge_degree_M': 0.1003, 
                'length_of_stay': 0.1003,                 'c_charge_degree_F': 0.0987},
        '3rd': {'Nothing shown': 0.1149, 'c_charge_degree_M': 0.1117, 'c_charge_degree_F': 0.1100, 
                'age': 0.0955, 'priors_count': 0.0906},
    }
}

# Completing the color mapping and ensuring plot generation.
colors = {
    'race': '#FF7F0E',
    'unrelated_column_one': '#1F77B4',
    'unrelated_column_two': '#AEC7E8',
    'sex_Female': '#FF9896',
    'sex_Male': '#98DF8A',
    'length_of_stay': '#C49C94',
    'c_charge_degree_M': '#9467BD',
    'c_charge_degree_F': '#C5B0D5',
    'two_year_recid': '#8C564B',
    'priors_count': '#E377C2',
    'age': '#D62728',
    'Nothing shown': '#C7C7C7',
}

# Creating the plot for LIME and SHAP comparisons
fig, axs = plt.subplots(2, 5, figsize=(18, 10))

# Plotting LIME scenarios
plot_bar(axs[0, 0], lime_data_avg['No Attack'], 'LIME: No Attack', colors)
plot_bar(axs[0, 1], lime_data_avg['Attack 1'], 'LIME: Attack 1', colors)
plot_bar(axs[0, 2], lime_data_avg['Attack 2'], 'LIME: Attack 2', colors)
plot_bar(axs[0, 3], lime_data_avg['Defense + Attack 1'], 'LIME: Defense + Attack 1', colors)
plot_bar(axs[0, 4], lime_data_avg['Defense + Attack 2'], 'LIME: Defense + Attack 2', colors)

# Plotting SHAP scenarios
plot_bar(axs[1, 0], shap_data_avg['No Attack'], 'SHAP: No Attack', colors)
plot_bar(axs[1, 1], shap_data_avg['Attack 1'], 'SHAP: Attack 1', colors)
plot_bar(axs[1, 2], shap_data_avg['Attack 2'], 'SHAP: Attack 2', colors)
plot_bar(axs[1, 3], shap_data_avg['Defense + Attack 1'], 'SHAP: Defense + Attack 1', colors)
plot_bar(axs[1, 4], shap_data_avg['Defense + Attack 2'], 'SHAP: Defense + Attack 2', colors)

# Adding the legend below the plot, centered and larger
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.15), fontsize=12)

plt.tight_layout()

# Save the plot as a PNG file
output_path = "defense_scenarios_avg_plot.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()

output_path

