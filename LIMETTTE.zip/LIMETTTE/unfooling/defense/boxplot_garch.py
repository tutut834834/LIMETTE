import matplotlib.pyplot as plt
import numpy as np

# GARCH Volatility values (first 10)
garch_volatility = [0.97565238, 0.98123808, 0.95479877, 0.95803691, 0.93194897, 
                    0.93728234, 0.91157664, 0.91629055, 0.89639571, 0.90042713]

# Create a box plot for the GARCH volatility values
plt.figure(figsize=(8, 6))
plt.boxplot(garch_volatility, patch_artist=True, boxprops=dict(facecolor='lightblue'))
plt.title("Box Plot of GARCH Volatility (First 10 Values)")
plt.ylabel("Volatility")
plt.grid(True)
plt.show()
