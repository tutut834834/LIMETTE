import numpy as np
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.base import OutlierMixin, BaseEstimator
from sklearn.neighbors import KNeighborsClassifier, KernelDensity, NearestNeighbors
from statsmodels.tsa.arima.model import ARIMA
import matplotlib.pyplot as plt
import statsmodels.api as sm
from arch import arch_model

np.set_printoptions(threshold=np.inf)

class KNNCAD(OutlierMixin, BaseEstimator):
    def __init__(
            self,
            approach='distance',  # Default to 'distance'
            distance_agg='median',
            epsilon=0.05,
            n_neighbors=20,
            weights='distance',
            algorithm='auto',
            distance_penalize_accurate=True,
            leaf_size=None,
            p=2,
            metric=None,
            metric_params=None,
            n_jobs=-1,
            bandwidth=1.0,
            atol=0,
            rtol=0,
            breadth_first=True,
            radius=1.0,
            window_size=100,
            alpha=1.0,
            beta=0.1,
            arima_order=(5, 1, 0),
            garch_p=2,
            garch_q=2,
            lipschitz_constant=1.0,
            gamma=0.01
    ):
        self.approach = approach
        self.epsilon = epsilon
        self.window_size = window_size
        self.alpha = alpha
        self.beta = beta
        self.arima_order = arima_order
        self.garch_p = garch_p
        self.garch_q = garch_q
        self.lipschitz_constant = lipschitz_constant
        self.gamma = gamma
        self.recent_scores = []
        self.trust_score = 1.0
        self.threshold_ = None
        self.arima_model_ = None
        self.garch_model_ = None
        self.arima_preds = []
        self.garch_vols = []
        self.lipschitz_adjustments = []
        self.privacy_scores = []

        self.distance_agg = self._get_agg_function(distance_agg)
        self.distance_penalize_accurate = distance_penalize_accurate

        # Initialize _estimator based on the approach
        if approach == 'clf':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = KNeighborsClassifier(
                n_neighbors=n_neighbors,
                weights=weights,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                n_jobs=n_jobs,
            )
        elif approach == 'distance':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = NearestNeighbors(
                n_neighbors=n_neighbors,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                radius=radius,
                n_jobs=n_jobs,
            )
        elif approach == 'density':
            metric = metric or 'euclidean'
            leaf_size = leaf_size or 40
            self._estimator = KernelDensity(
                bandwidth=bandwidth,
                algorithm=algorithm,
                leaf_size=leaf_size,
                metric=metric,
                metric_params=metric_params,
                atol=atol,
                rtol=rtol,
                breadth_first=breadth_first,
            )
        else:
            raise ValueError(f"Unknown approach: {approach}")
        
        # Ensure _estimator is set
        assert self._estimator is not None, "Failed to initialize the _estimator."

    def _get_agg_function(self, agg):
        """Convert a string aggregation function name to an actual numpy function."""
        if isinstance(agg, str):
            if agg in ['mean', 'median', 'max', 'min', 'sum']:
                return getattr(np, agg)
            else:
                raise ValueError(f"Unknown aggregation function: {agg}")
        return agg

    def fit(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        print("Fitting the model...")
        self.X_train, self.y_train = X, y
        self._estimator.fit(X, y)

        
        # Fit ARIMA model on the output (y) to capture temporal dependencies
        self.arima_model_ = ARIMA(y, order=self.arima_order).fit()

        # Print ARIMA model summary
        print("ARIMA Model Summary:\n", self.arima_model_.summary())

        # Residuals from ARIMA model
        residuals = self.arima_model_.resid
        print("ARIMA Residuals (first 10):", residuals)
        # Plotting the differenced residuals
       # Create a box plot for the GARCH volatility values
        plt.figure(figsize=(8, 6))
        plt.boxplot(residuals, patch_artist=True, boxprops=dict(facecolor='lightblue'))
        plt.title("Box Plot of Residuals ARIMA model")
        plt.ylabel("Residuals")
        plt.grid(True)
        plt.show()
        
        # # Create subplots for various residual plots
        # fig, axes = plt.subplots(2, 2, figsize=(14, 12))

        # # 1. Residuals vs Predictor Variables
        # x = np.linspace(0, 10, len(residuals))  # Example predictor
        # axes[0, 0].scatter(y, residuals)
        # axes[0, 0].axhline(0, color='red', linestyle='--')
        # axes[0, 0].set_title('Residuals vs Predictor Variable')
        # axes[0, 0].set_xlabel('Predictor Variable')
        # axes[0, 0].set_ylabel('Residuals')

        # # 2. QQ Plot
        # sm.qqplot(residuals, line='s', ax=axes[0, 1])
        # axes[0, 1].set_title('QQ Plot of Residuals')

        # # 3. Histogram of Residuals
        # axes[1, 0].hist(residuals, bins=15, color='lightblue', edgecolor='black')
        # axes[1, 0].set_title('Histogram of Residuals')
        # axes[1, 0].set_xlabel('Residuals')
        # axes[1, 0].set_ylabel('Frequency')

        # # 4. Standardized Residuals Plot
        # standardized_residuals = (residuals - np.mean(residuals)) / np.std(residuals)
        # axes[1, 1].scatter(x, standardized_residuals)
        # axes[1, 1].axhline(0, color='red', linestyle='--')
        # axes[1, 1].set_title('Standardized Residuals Plot')
        # axes[1, 1].set_xlabel('Predictor Variable')
        # axes[1, 1].set_ylabel('Standardized Residuals')

        # plt.tight_layout()
        # plt.show()
        # Check if residuals have enough variability
        residual_variance = np.var(residuals)
        print("Variance of Residuals:", residual_variance)
        if residual_variance < 1e-5:
            print("Warning: Low variability in residuals, GARCH may not perform well.")
    
        # Differencing the residuals to ensure stationarity
        diff_residuals = np.diff(residuals)  # Apply first differencing to make residuals stationary
        #print("Differenced Residuals (first 10):", diff_residuals)
        # Fit GARCH model on the differenced residuals
        self.garch_model_ = arch_model(diff_residuals, p=self.garch_p, q=self.garch_q).fit(disp="on")
        #print(f"GARCH model (p={self.garch_p}, q={self.garch_q}) fitted.")

        # Save GARCH volatility for analysis
        self.garch_vols = self.garch_model_.conditional_volatility[:len(diff_residuals)]

        # Create subplots for GARCH volatility plots
        fig, axes = plt.subplots(2, 2, figsize=(14, 12))

        # 1. GARCH Volatility vs Time
        time = np.arange(len(self.garch_vols))  # Assuming time as predictor
        axes[0, 0].plot(time, self.garch_vols, color='blue')
        axes[0, 0].set_title('GARCH Volatility vs Time')
        axes[0, 0].set_xlabel('Time')
        axes[0, 0].set_ylabel('Volatility')

        # 2. QQ Plot for GARCH Volatilities
        sm.qqplot(self.garch_vols, line='s', ax=axes[0, 1])
        axes[0, 1].set_title('QQ Plot of GARCH Volatilities')

        # 3. Histogram of GARCH Volatilities
        axes[1, 0].hist(self.garch_vols, bins=15, color='lightblue', edgecolor='black')
        axes[1, 0].set_title('Histogram of GARCH Volatilities')
        axes[1, 0].set_xlabel('Volatility')
        axes[1, 0].set_ylabel('Frequency')

        # 4. Standardized GARCH Volatilities Plot
        standardized_vols = (self.garch_vols - np.mean(self.garch_vols)) / np.std(self.garch_vols)
        axes[1, 1].scatter(time, standardized_vols)
        axes[1, 1].axhline(0, color='red', linestyle='--')
        axes[1, 1].set_title('Standardized GARCH Volatilities Plot')
        axes[1, 1].set_xlabel('Time')
        axes[1, 1].set_ylabel('Standardized Volatility')

        plt.tight_layout()
        plt.show()
        
        squared_vols = garch_vols ** 2
        acf_values = sm.tsa.acf(squared_vols, nlags=lags)
        assert np.any(np.abs(acf_values[1:]) > 0.2), f"Test failed: No significant volatility clustering found."
        print("Test passed: Volatility clustering detected.")

        z_scores = (garch_vols - np.mean(garch_vols)) / np.std(garch_vols)
        outliers = np.where(np.abs(z_scores) > 3)[0]
        assert len(outliers) == 0, f"Test failed: Extreme outliers detected in GARCH volatility at indices {outliers}."
        print("Test passed: No extreme outliers in GARCH volatility.")
        
        from statsmodels.tsa.stattools import adfuller
        adf_stat, p_value, _, _, _, _ = adfuller(garch_vols)
        assert p_value < 0.05, f"Test failed: GARCH volatility does not show mean reversion (p-value: {p_value})"
        print("Test passed: GARCH volatility is mean-reverting.")

        garch_vols= self.garch_vols
        # Print the GARCH results to check for variability
        #print("GARCH Volatility :", self.garch_vols)

        # Determine initial static threshold
        scores = self.score_samples(X, y)
        scores.sort()
        thresh_idx = round(self.epsilon * len(X))
        self.threshold_ = scores[thresh_idx]

        return self

    def fit_predict(self, X, y):
        return self.fit(X, y).predict(X, y)

    def predict(self, X, y):
        scores = self.score_samples(X, y)

        scores = self.differential_privacy_noise(scores)

        dynamic_threshold = self.calculate_dynamic_threshold(scores)
        trust_adjusted_threshold = self.trust_aware_threshold(dynamic_threshold)

        preds = np.ones_like(scores, dtype=int)
        preds[scores < trust_adjusted_threshold] = -1

        self.save_results_to_csv()

        self.update_trust_score(dynamic_threshold)

        return preds

    def score_samples(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        if self.approach == 'clf':
            probas = self._estimator.predict_proba(X)
            scores = probas[np.arange(len(y)), y]
        elif self.approach == 'distance':
            dists, idxs = self._estimator.kneighbors(X)
            scores = self.calculate_distance_scores(dists, idxs, y)
        elif self.approach == 'density':
            scores = self._estimator.score_samples(X)
        else:
            raise RuntimeError(self.approach)

        arima_pred = self.arima_model_.predict(start=0, end=len(y) - 1)
        garch_pred = self.garch_vols[:len(y)]

        # Ensure GARCH and ARIMA predictions match in size
        if garch_pred.shape[0] != arima_pred.shape[0]:
            garch_pred = np.resize(garch_pred, arima_pred.shape)

        lipschitz_adjustment = self.calculate_lipschitz_adjustment(arima_pred, garch_pred)

        self.arima_preds = arima_pred
        self.garch_vols = garch_pred
        self.lipschitz_adjustments = lipschitz_adjustment
        self.privacy_scores = scores

        scores += arima_pred + garch_pred + lipschitz_adjustment

        self.recent_scores.extend(scores)
        if len(self.recent_scores) > self.window_size:
            self.recent_scores = self.recent_scores[-self.window_size:]

        return scores

    def calculate_dynamic_threshold(self, scores):
        if len(self.recent_scores) < self.window_size:
            return self.threshold_

        mean_score = np.mean(self.recent_scores)
        variance_score = np.var(self.recent_scores)
        dynamic_threshold = mean_score + self.alpha * variance_score
        return dynamic_threshold
    
    def update_trust_score(self, new_score):
        self.trust_score = max(0, min(1, self.trust_score - (0.1 * new_score)))

    def trust_aware_threshold(self, dynamic_threshold):
        trust_adjusted_threshold = dynamic_threshold - (1 - self.trust_score) * self.beta
        return trust_adjusted_threshold

    def differential_privacy_noise(self, scores):
        noise = np.random.laplace(0, 1.0 / self.epsilon, size=scores.shape)
        noisy_scores = scores + noise
        return noisy_scores

    def calculate_lipschitz_adjustment(self, arima_pred, garch_pred):
        adjustment = self.gamma * np.abs(garch_pred - arima_pred)
        self.lipschitz_constant += adjustment.mean()
        return self.lipschitz_constant * adjustment

    def calculate_distance_scores(self, dists, idxs, y):
        scores = []
        for dist, idx, yi in zip(dists, idxs, y):
            yi = int(yi)
            assert yi in {0, 1}, yi

            pop_yi = self.y_train[idx]
            dist_0 = self.calculate_aggregate_distance(dist, pop_yi, 0)
            dist_1 = self.calculate_aggregate_distance(dist, pop_yi, 1)

            if yi == 1:
                dist_yi, dist_other = dist_1, dist_0
            else:
                dist_yi, dist_other = dist_0, dist_1

            score = self.calculate_score(dist_yi, dist_other)
            scores.append(score)
        return np.asarray(scores)

    def calculate_aggregate_distance(self, dist, pop_yi, class_label):
        where_class = np.where(pop_yi == class_label)
        dists_class = dist[where_class]
        if dists_class.size:
            return self.distance_agg(dists_class)
        else:
            return np.inf

    def calculate_score(self, dist_yi, dist_other):
        if not self.distance_penalize_accurate and dist_yi < dist_other:
            return 1.0
        else:
            if dist_yi == dist_other == 0:
                return 1.0
            else:
                with np.errstate(divide='ignore'):
                    return 1 / (1 + dist_yi / dist_other)

    def save_results_to_csv(self, filename='results.csv'):
        """Save ARIMA predictions, GARCH volatility, Lipschitz adjustments, and Privacy scores to a CSV file."""
        df = pd.DataFrame({
            'ARIMA Predictions': self.arima_preds,
            'GARCH Volatility': self.garch_vols,
            'Lipschitz Adjustments': self.lipschitz_adjustments,
            'Privacy Scores': self.privacy_scores
        })
        df.to_csv(filename, index=False)
        print(f"Results saved to {filename}")
