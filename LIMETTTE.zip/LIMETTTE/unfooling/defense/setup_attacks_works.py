import foolbox as fb  # Ensure foolbox is imported
import torch
from torchvision import models, transforms
import matplotlib
matplotlib.use('Agg')  # Set the backend to 'Agg' for script-based usage
import matplotlib.pyplot as plt
import numpy as np

# Check for GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load model and data
model = models.resnet18(weights='DEFAULT').eval().to(device)  # Move model to the same device
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Create synthetic image data
synthetic_image = torch.rand((1, 3, 224, 224)).to(device)  # Move input to the same device
label = torch.tensor([1]).to(device)  # Move label to the same device

# Convert tensor to NumPy array for plotting
image_np = synthetic_image.squeeze(0).permute(1, 2, 0).cpu().numpy()  # Move back to CPU for plotting

# Plot synthetic image
plt.figure()
plt.imshow(image_np)
plt.title('Synthetic Image')
plt.axis('off')  # Hide axis
plt.savefig('synthetic_image.png')  # Save the plot as a PNG file
print("Synthetic image saved as 'synthetic_image.png'.")

# Define epsilon values for the attack
epsilons = [0.01, 0.03, 0.05, 0.07, 0.1]

# Initialize lists to store results
success_rates = []
perturbation_magnitudes = []
model_confidences = []

for epsilon in epsilons:
    # Perform the attack
    attack = fb.attacks.FGSM()
    adversarial = attack(fmodel, synthetic_image, label, epsilons=[epsilon])

    # Extract the adversarial image tensor from the first list within the tuple
    adversarial_image = adversarial[0][0]  # The first element of the first list
    
    # Ensure the adversarial_image tensor is on the correct device
    adversarial_image = adversarial_image.to(device)
    
    # Calculate the success rate
    with torch.no_grad():
        logits = model(adversarial_image)
        predicted_class = torch.argmax(logits, dim=1)
        success_rate = (predicted_class != label).float().mean().item()
        success_rates.append(success_rate)
    
    # Calculate the perturbation magnitude
    perturbation = adversarial_image - synthetic_image
    perturbation_magnitude = perturbation.norm().item()
    perturbation_magnitudes.append(perturbation_magnitude)
    
    # Calculate model confidence
    model_confidence = torch.max(torch.softmax(logits, dim=1)).item()
    model_confidences.append(model_confidence)

# Plot success rates
plt.figure()
plt.plot(epsilons, success_rates, marker='o', linestyle='-', color='b')
plt.xlabel('Epsilon')
plt.ylabel('Success Rate')
plt.title('Attack Success Rate vs. Epsilon')
plt.grid(True)
plt.savefig('attack_success_rate.png')  # Save the plot as a PNG file
print("Attack success rate plot saved as 'attack_success_rate.png'.")

# Plot perturbation magnitudes
plt.figure()
plt.plot(epsilons, perturbation_magnitudes, marker='o', linestyle='-', color='r')
plt.xlabel('Epsilon')
plt.ylabel('Perturbation Magnitude')
plt.title('Perturbation Magnitude vs. Epsilon')
plt.grid(True)
plt.savefig('perturbation_magnitude.png')  # Save the plot as a PNG file
print("Perturbation magnitude plot saved as 'perturbation_magnitude.png'.")

# Plot model confidences
plt.figure()
plt.plot(epsilons, model_confidences, marker='o', linestyle='-', color='g')
plt.xlabel('Epsilon')
plt.ylabel('Model Confidence')
plt.title('Model Confidence vs. Epsilon')
plt.grid(True)
plt.savefig('model_confidence.png')  # Save the plot as a PNG file
print("Model confidence plot saved as 'model_confidence.png'.")

print("Foolbox attack complete.")
