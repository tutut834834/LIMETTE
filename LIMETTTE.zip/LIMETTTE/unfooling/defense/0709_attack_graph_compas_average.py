import matplotlib.pyplot as plt
import numpy as np

# Updated LIME and SHAP data with the averaged results
lime_avg_data = {
    'No Attack': {
        '1st': {'race': 0.9919},
        '2nd': {'length_of_stay': 0.00778},
        '3rd': {'priors_count': 0.00032},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.9919},
        '2nd': {'length_of_stay': 0.00778},
        '3rd': {},
    },
    'Attack 2': {
        '1st': {'sex_Female': 0.1644, 'sex_Male': 0.14982},
        '2nd': {'unrelated_column_one': 0.11876},
        '3rd': {'unrelated_column_two': 0.11846},
    }
}

shap_avg_data = {
    'No Attack': {
        '1st': {'race': 1.0},
        '2nd': {},
        '3rd': {},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.61068, 'race': 0.17574},
        '2nd': {},
        '3rd': {},
    },
    'Attack 2': {
        '1st': {'race': 0.40064},
        '2nd': {'length_of_stay': 0.15858},
        '3rd': {'unrelated_column_one': 0.15082, 'unrelated_column_two': 0.15694},
    }
}

# Colors for the features
colors = {
    'race': '#FF7F0E',
    'length_of_stay': '#1F77B4',
    'priors_count': '#2CA02C',
    'sex_Female': '#D62728',
    'sex_Male': '#9467BD',
    'unrelated_column_one': '#8C564B',
    'unrelated_column_two': '#E377C2'
}

# Plotting function
def plot_bar(ax, data, title):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels = list(data[category].keys())
        values = list(data[category].values())
        bottoms = np.cumsum([0] + values[:-1])
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xticks(np.arange(0, 101, 20))
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Create the plots for LIME and SHAP
fig, axs = plt.subplots(2, 3, figsize=(18, 12))

plot_bar(axs[0, 0], lime_avg_data['No Attack'], 'LIME: No Attack')
plot_bar(axs[0, 1], lime_avg_data['Attack 1'], 'LIME: Attack 1')
plot_bar(axs[0, 2], lime_avg_data['Attack 2'], 'LIME: Attack 2')

plot_bar(axs[1, 0], shap_avg_data['No Attack'], 'SHAP: No Attack')
plot_bar(axs[1, 1], shap_avg_data['Attack 1'], 'SHAP: Attack 1')
plot_bar(axs[1, 2], shap_avg_data['Attack 2'], 'SHAP: Attack 2')

# Adding the legend
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
fig.legend(handles, labels, loc='upper center', ncol=4, bbox_to_anchor=(0.5, -0.05))

plt.tight_layout()
plt.show()
