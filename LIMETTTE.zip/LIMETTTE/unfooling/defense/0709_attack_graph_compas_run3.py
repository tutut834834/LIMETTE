import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Data for LIME and SHAP based on the new information
lime_data = {
    'No Attack': {
        '1st': {'race': 0.9919, 'length_of_stay': 0.0081},
        '2nd': {'sex_Female': 0.1942, 'sex_Male': 0.1537, 'unrelated_column_two': 0.1311, 'unrelated_column_one': 0.1197, 'c_charge_degree_F': 0.1165},
        '3rd': {'sex_Male': 0.1618, 'two_year_recid': 0.1327, 'unrelated_column_one': 0.1327, 'c_charge_degree_F': 0.1246, 'sex_Female': 0.1230},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.9935, 'length_of_stay': 0.0065},
        '2nd': {'sex_Male': 0.1796, 'c_charge_degree_F': 0.1472, 'sex_Female': 0.1456, 'two_year_recid': 0.1278, 'race': 0.1262},
        '3rd': {'c_charge_degree_M': 0.1505, 'race': 0.1489, 'c_charge_degree_F': 0.1343, 'sex_Female': 0.1327, 'two_year_recid': 0.1181},
    },
    'Attack 2': {
        '1st': {'unrelated_column_two': 0.1408, 'sex_Male': 0.1375, 'sex_Female': 0.1359, 'unrelated_column_one': 0.1197, 'c_charge_degree_M': 0.1100},
        '2nd': {'sex_Male': 0.1440, 'unrelated_column_two': 0.1262, 'c_charge_degree_M': 0.1181, 'c_charge_degree_F': 0.1149, 'sex_Female': 0.1117},
        '3rd': {'c_charge_degree_F': 0.1246, 'race': 0.1214, 'sex_Female': 0.1181, 'two_year_recid': 0.1117, 'unrelated_column_two': 0.1052},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.5583, 'race': 0.0858, 'c_charge_degree_M': 0.0599, 'sex_Female': 0.0469, 'unrelated_column_two': 0.0453},
        '2nd': {'race': 0.3414, 'unrelated_column_one': 0.1828, 'sex_Female': 0.0987, 'c_charge_degree_M': 0.0809, 'two_year_recid': 0.0647},
        '3rd': {'sex_Female': 0.1392, 'c_charge_degree_F': 0.1036, 'c_charge_degree_M': 0.1036, 'two_year_recid': 0.0955, 'unrelated_column_two': 0.0939},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.4871, 'unrelated_column_one': 0.0841, 'sex_Female': 0.0825, 'unrelated_column_two': 0.0534, 'c_charge_degree_M': 0.0518},
        '2nd': {'race': 0.1456, 'two_year_recid': 0.1214, 'sex_Female': 0.1084, 'unrelated_column_two': 0.1019, 'c_charge_degree_M': 0.0890},
        '3rd': {'sex_Female': 0.1133, 'unrelated_column_two': 0.1068, 'unrelated_column_one': 0.1019, 'c_charge_degree_M': 0.1003, 'race': 0.0939},
    }
}

shap_data = {
    'No Attack': {
        '1st': {'race': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.6052, 'race': 0.1408, 'length_of_stay': 0.1246, 'age': 0.0324, 'c_charge_degree_F': 0.0210},
        '2nd': {'race': 0.3722, 'unrelated_column_one': 0.1845, 'length_of_stay': 0.1149, 'age': 0.0712, 'priors_count': 0.0502},
        '3rd': {'length_of_stay': 0.2152, 'age': 0.1197, 'race': 0.1181, 'priors_count': 0.1100, 'two_year_recid': 0.0955},
    },
    'Attack 2': {
        '1st': {'race': 0.3673, 'unrelated_column_one': 0.1748, 'unrelated_column_two': 0.1489, 'length_of_stay': 0.1117, 'age': 0.0566},
        '2nd': {'unrelated_column_two': 0.2201, 'unrelated_column_one': 0.1683, 'race': 0.1472, 'length_of_stay': 0.1117, 'age': 0.0712},
        '3rd': {'unrelated_column_one': 0.1262, 'length_of_stay': 0.1165, 'unrelated_column_two': 0.1084, 'age': 0.1036, 'race': 0.1036},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.1877, 'race': 0.1602, 'length_of_stay': 0.1375, 'c_charge_degree_M': 0.0874, 'c_charge_degree_F': 0.0761},
        '2nd': {'race': 0.1440, 'length_of_stay': 0.1181, 'priors_count': 0.1003, 'unrelated_column_one': 0.0971, 'sex_Female': 0.0955},
        '3rd': {'c_charge_degree_M': 0.1019, 'sex_Female': 0.1003, 'c_charge_degree_F': 0.0971, 'length_of_stay': 0.0971, 'sex_Male': 0.0971},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.1909, 'length_of_stay': 0.1294, 'unrelated_column_one': 0.1052, 'c_charge_degree_F': 0.1036, 'priors_count': 0.0841},
        '2nd': {'length_of_stay': 0.1117, 'c_charge_degree_F': 0.1100, 'race': 0.1100, 'c_charge_degree_M': 0.0987, 'unrelated_column_two': 0.0955},
        '3rd': {'length_of_stay': 0.1197, 'c_charge_degree_M': 0.0955, 'unrelated_column_two': 0.0922, 'age': 0.0890, 'unrelated_column_one': 0.0858},
    }
}

# Completing the color mapping and ensuring plot generation.

colors = {
    'race': '#FF7F0E',
    'unrelated_column_one': '#1F77B4',
    'unrelated_column_two': '#AEC7E8',
    'sex_Female': '#FF9896',
    'sex_Male': '#98DF8A',
    'length_of_stay': '#C49C94',
    'c_charge_degree_M': '#9467BD',
    'c_charge_degree_F': '#C5B0D5',
    'two_year_recid': '#8C564B',
    'priors_count': '#E377C2',
    'age': '#D62728',
    'Nothing shown': '#C7C7C7',
}

# Creating the plot for LIME and SHAP comparisons
fig, axs = plt.subplots(2, 5, figsize=(18, 10))

# Plotting LIME scenarios
plot_bar(axs[0, 0], lime_data['No Attack'], 'LIME: No Attack', colors)
plot_bar(axs[0, 1], lime_data['Attack 1'], 'LIME: Attack 1', colors)
plot_bar(axs[0, 2], lime_data['Attack 2'], 'LIME: Attack 2', colors)
plot_bar(axs[0, 3], lime_data['Defense + Attack 1'], 'LIME: Defense + Attack 1', colors)
plot_bar(axs[0, 4], lime_data['Defense + Attack 2'], 'LIME: Defense + Attack 2', colors)

# Plotting SHAP scenarios
plot_bar(axs[1, 0], shap_data['No Attack'], 'SHAP: No Attack', colors)
plot_bar(axs[1, 1], shap_data['Attack 1'], 'SHAP: Attack 1', colors)
plot_bar(axs[1, 2], shap_data['Attack 2'], 'SHAP: Attack 2', colors)
plot_bar(axs[1, 3], shap_data['Defense + Attack 1'], 'SHAP: Defense + Attack 1', colors)
plot_bar(axs[1, 4], shap_data['Defense + Attack 2'], 'SHAP: Defense + Attack 2', colors)

# Adding the legend below the plot, centered and larger
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.15), fontsize=12)

plt.tight_layout()

# Save the plot as a PNG file
output_path = "defense_scenarios_plot_run_3.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()

output_path

