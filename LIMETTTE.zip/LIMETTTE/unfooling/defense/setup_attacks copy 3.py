import foolbox as fb
import torch
from torchvision import models
import numpy as np
import csv
from unfooling.explainers import get_explainer

# Ensure foolbox is imported, model is set up
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = models.resnet18(weights='DEFAULT').eval().to(device)
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Synthetic image data
synthetic_image = torch.rand((1, 3, 224, 224)).to(device)
label = torch.tensor([1]).to(device)

# Epsilon values
epsilons = np.linspace(0.01, 0.3, 10)  # More epsilon values

# Explainers and attacks
explainers = ['LIME', 'SHAP']
attacks = {
    'FGSM': fb.attacks.FGSM(),
    'BIM': fb.attacks.LinfBasicIterativeAttack(),
    'PGD': fb.attacks.PGD(),
    'L2PGD': fb.attacks.L2PGD(),
    'DeepFool': fb.attacks.L2DeepFoolAttack(),
    'Spatial': fb.attacks.SpatialAttack(),
    'LinfFastGradientMethod': fb.attacks.FGSM(),
    'DataPerturbation': None,
    'BackdoorAttack': None,
}

# Load your training data here
X_train = synthetic_image.cpu().numpy()  # Dummy data, replace with your own
features = [f'feature_{i}' for i in range(X_train.shape[1])]
categorical_feature_idxs = []

# Open CSV to store results
with open('large_attack_explanation_results.csv', 'w', newline='') as csvfile:
    fieldnames = ['Explainer', 'Attack', 'Epsilon', 'Feature', 'Importance', 'PerturbedData']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()

    # Loop over explainers and generate perturbations
    for explainer_name in explainers:
        explainer = get_explainer(explainer_name, model, X_train, features, categorical_feature_idxs)
        for attack_name, attack in attacks.items():
            print(f"Running {attack_name} with {explainer_name} explainer...")

            for epsilon in epsilons:
                if attack_name == 'DataPerturbation':
                    adversarial_image = synthetic_image + epsilon * torch.randn_like(synthetic_image).to(device)
                elif attack_name == 'BackdoorAttack':
                    adversarial_image = synthetic_image.clone()
                    adversarial_image[:, :, :10, :10] = 1.0  # Example backdoor pattern
                else:
                    adversarial = attack(fmodel, synthetic_image, label, epsilons=[epsilon])
                    adversarial_image = adversarial[0][0]
                    if adversarial_image.dim() == 3:
                        adversarial_image = adversarial_image.unsqueeze(0)

                adversarial_image = adversarial_image.to(device)
                explanation = explainer.explain(adversarial_image.cpu().numpy().squeeze(), num_samples=5000)
                perturbed_data = explainer.perturbed_data

                for feature, importance in explanation:
                    writer.writerow({
                        'Explainer': explainer_name,
                        'Attack': attack_name,
                        'Epsilon': epsilon,
                        'Feature': feature,
                        'Importance': importance,
                        'PerturbedData': perturbed_data.tolist()
                    })

                print(f"Completed epsilon {epsilon} for {attack_name} with {explainer_name}")
