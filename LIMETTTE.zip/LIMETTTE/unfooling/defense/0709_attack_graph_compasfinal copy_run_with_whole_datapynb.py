import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Data for LIME and SHAP based on the provided information for run 6
lime_data = {
    'No Attack': {
        '1st': {'race': 0.9984, 'length_of_stay': 0.0016},
        '2nd': {'sex_Male': 0.2104, 'sex_Female': 0.1926, 'c_charge_degree_F': 0.1472, 
                'unrelated_column_one': 0.1246, 'unrelated_column_two': 0.1068},
        '3rd': {'c_charge_degree_F': 0.1375, 'sex_Female': 0.1375, 'unrelated_column_two': 0.1343, 
                'c_charge_degree_M': 0.1327, 'sex_Male': 0.1311},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.9984, 'length_of_stay': 0.0016},
        '2nd': {'race': 0.2540, 'sex_Male': 0.1650, 'sex_Female': 0.1570, 
                'c_charge_degree_F': 0.1165, 'c_charge_degree_M': 0.1019},
        '3rd': {'race': 0.2670, 'unrelated_column_two': 0.1667, 'two_year_recid': 0.1343, 
                'c_charge_degree_M': 0.1149, 'sex_Female': 0.1003},
    },
    'Attack 2': {
        '1st': {'unrelated_column_one': 0.4919, 'unrelated_column_two': 0.4159, 'sex_Female': 0.0307, 
                'sex_Male': 0.0259, 'c_charge_degree_F': 0.0129},
        '2nd': {'unrelated_column_two': 0.3835, 'unrelated_column_one': 0.2233, 'sex_Female': 0.1052, 
                'sex_Male': 0.0890, 'c_charge_degree_F': 0.0534},
        '3rd': {'sex_Male': 0.1343, 'sex_Female': 0.1311, 'c_charge_degree_F': 0.1214, 
                'race': 0.1197, 'two_year_recid': 0.1149},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.9984, 'length_of_stay': 0.0016},
        '2nd': {'race': 0.9417, 'sex_Male': 0.0356, 'sex_Female': 0.0146, 
                'c_charge_degree_F': 0.0065, 'unrelated_column_one': 0.0016},
        '3rd': {'sex_Female': 0.4789, 'c_charge_degree_F': 0.1683, 'sex_Male': 0.1521, 
                'unrelated_column_two': 0.0534, 'c_charge_degree_M': 0.0469},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.9984, 'length_of_stay': 0.0016},
        '2nd': {'unrelated_column_two': 0.2460, 'unrelated_column_one': 0.2152, 'sex_Male': 0.1845, 
                'sex_Female': 0.1586, 'priors_count': 0.1052},
        '3rd': {'unrelated_column_one': 0.2476, 'sex_Female': 0.1893, 'unrelated_column_two': 0.1828, 
                'priors_count': 0.1019, 'sex_Male': 0.0858},
    }
}

shap_data = {
    'No Attack': {
        '1st': {'race': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.7977, 'length_of_stay': 0.1472, 'race': 0.0550},
        '2nd': {'race': 0.5275, 'unrelated_column_one': 0.2023, 'length_of_stay': 0.1683, 
                'priors_count': 0.0453, 'age': 0.0356},
        '3rd': {'length_of_stay': 0.3074, 'race': 0.2751, 'priors_count': 0.2362, 
                'age': 0.1036, 'two_year_recid': 0.0259},
    },
    'Attack 2': {
        '1st': {'race': 0.4579, 'length_of_stay': 0.1780, 'unrelated_column_two': 0.1780, 
                'unrelated_column_one': 0.1553, 'priors_count': 0.0194},
        '2nd': {'unrelated_column_two': 0.2945, 'race': 0.2799, 'unrelated_column_one': 0.2767, 
                'length_of_stay': 0.0922, 'age': 0.0307},
        '3rd': {'unrelated_column_one': 0.2751, 'unrelated_column_two': 0.2476, 'race': 0.1618, 
                'length_of_stay': 0.1117, 'age': 0.0841},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.8000, 'length_of_stay': 0.1440, 'race': 0.0485, 
                'age': 0.0032, 'priors_count': 0.0032},
        '2nd': {'race': 0.6036, 'unrelated_column_one': 0.1974, 'length_of_stay': 0.1278, 
                'age': 0.0307, 'priors_count': 0.0259},
        '3rd': {'length_of_stay': 0.4660, 'race': 0.2379, 'age': 0.1375, 
                'priors_count': 0.0955, 'two_year_recid': 0.0194},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.4612, 'length_of_stay': 0.1845, 'unrelated_column_two': 0.1731, 
                'unrelated_column_one': 0.1553, 'priors_count': 0.0194},
        '2nd': {'unrelated_column_two': 0.3074, 'race': 0.2783, 'unrelated_column_one': 0.2767, 
                'length_of_stay': 0.0744, 'age': 0.0291},
        '3rd': {'unrelated_column_one': 0.2411, 'unrelated_column_two': 0.2087, 'length_of_stay': 0.1586, 
                'race': 0.1586, 'age': 0.1068},
    }
}

# Completing the color mapping and ensuring plot generation
colors = {
    'race': '#FF7F0E',
    'unrelated_column_one': '#1F77B4',
    'unrelated_column_two': '#AEC7E8',
    'sex_Female': '#FF9896',
    'sex_Male': '#98DF8A',
    'length_of_stay': '#C49C94',
    'c_charge_degree_M': '#9467BD',
    'c_charge_degree_F': '#C5B0D5',
    'two_year_recid': '#8C564B',
    'priors_count': '#E377C2',
    'age': '#D62728',
    'Nothing shown': '#C7C7C7',
}

# Creating the plot for LIME and SHAP comparisons
fig, axs = plt.subplots(2, 5, figsize=(18, 10))

# Plotting LIME scenarios
plot_bar(axs[0, 0], lime_data['No Attack'], 'LIME: No Attack', colors)
plot_bar(axs[0, 1], lime_data['Attack 1'], 'LIME: Attack 1', colors)
plot_bar(axs[0, 2], lime_data['Attack 2'], 'LIME: Attack 2', colors)
plot_bar(axs[0, 3], lime_data['Defense + Attack 1'], 'LIME: Defense + Attack 1', colors)
plot_bar(axs[0, 4], lime_data['Defense + Attack 2'], 'LIME: Defense + Attack 2', colors)

# Plotting SHAP scenarios
plot_bar(axs[1, 0], shap_data['No Attack'], 'SHAP: No Attack', colors)
plot_bar(axs[1, 1], shap_data['Attack 1'], 'SHAP: Attack 1', colors)
plot_bar(axs[1, 2], shap_data['Attack 2'], 'SHAP: Attack 2', colors)
plot_bar(axs[1, 3], shap_data['Defense + Attack 1'], 'SHAP: Defense + Attack 1', colors)
plot_bar(axs[1, 4], shap_data['Defense + Attack 2'], 'SHAP: Defense + Attack 2', colors)

# Adding the legend below the plot, centered and larger
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.15), fontsize=12)

plt.tight_layout()

# Save the plot as a PNG file
output_path = "defense_scenarios_final_pynb_plot -------.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()

output_path

