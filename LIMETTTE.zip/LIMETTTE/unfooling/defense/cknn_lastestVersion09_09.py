import numpy as np
from sklearn.base import OutlierMixin, BaseEstimator
from sklearn.neighbors import KNeighborsClassifier, KernelDensity, NearestNeighbors
from statsmodels.tsa.arima.model import ARIMA
from arch import arch_model

class KNNCAD(OutlierMixin, BaseEstimator):
    def __init__(
            self,
            approach='distance',
            distance_agg='median',
            epsilon=0.05,
            n_neighbors=20,
            weights='distance',
            algorithm='auto',
            distance_penalize_accurate=True,
            leaf_size=None,
            p=2,
            metric=None,
            metric_params=None,
            n_jobs=-1,
            bandwidth=1.0,
            atol=0,
            rtol=0,
            breadth_first=True,
            radius=1.0,
            window_size=100,
            alpha=1.0,
            beta=0.1,
            arima_order=(5, 1, 0),
            garch_p=1,
            garch_q=1,
            lipschitz_constant=1.0,
            gamma=0.01
    ):
        self.approach = approach
        self.epsilon = epsilon
        self.window_size = window_size
        self.alpha = alpha
        self.beta = beta
        self.arima_order = arima_order
        self.garch_p = garch_p
        self.garch_q = garch_q
        self.lipschitz_constant = lipschitz_constant
        self.gamma = gamma
        self.recent_scores = []
        self.trust_score = 1.0
        self.threshold_ = None
        self.arima_model_ = None
        self.garch_model_ = None

        self.distance_agg = self._get_agg_function(distance_agg)
        self.distance_penalize_accurate = distance_penalize_accurate

        if approach == 'clf':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = KNeighborsClassifier(
                n_neighbors=n_neighbors,
                weights=weights,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                n_jobs=n_jobs,
            )
        elif approach == 'distance':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = NearestNeighbors(
                n_neighbors=n_neighbors,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                radius=radius,
                n_jobs=n_jobs,
            )
        elif approach == 'density':
            metric = metric or 'euclidean'
            leaf_size = leaf_size or 40
            self._estimator = KernelDensity(
                bandwidth=bandwidth,
                algorithm=algorithm,
                leaf_size=leaf_size,
                metric=metric,
                metric_params=metric_params,
                atol=atol,
                rtol=rtol,
                breadth_first=breadth_first,
            )
        else:
            raise ValueError(f"Unknown approach: {approach}")

    def _get_agg_function(self, agg):
        """Convert a string aggregation function name to an actual numpy function."""
        if isinstance(agg, str):
            if agg in ['mean', 'median', 'max', 'min', 'sum']:
                return getattr(np, agg)
            else:
                raise ValueError(f"Unknown aggregation function: {agg}")
        return agg

    def fit(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        print("Fitting the model...")
        self.X_train, self.y_train = X, y
        self._estimator.fit(X, y)

        # Fit ARIMA model on the output (y) to capture temporal dependencies
        self.arima_model_ = ARIMA(y, order=self.arima_order).fit()
        print(f"ARIMA model fitted with order {self.arima_order}.")

        # Fit GARCH model on the residuals of ARIMA to capture volatility clustering
        residuals = self.arima_model_.resid
        print("Residuals from ARIMA model:", residuals[:10])

        self.garch_model_ = arch_model(residuals, p=self.garch_p, q=self.garch_q).fit(disp="off")
        print(f"GARCH model (p={self.garch_p}, q={self.garch_q}) fitted.")
        print("Conditional volatility from GARCH model:", self.garch_model_.conditional_volatility[:10])

        # Determine initial static threshold
        scores = self.score_samples(X, y)
        scores.sort()
        thresh_idx = round(self.epsilon * len(X))
        self.threshold_ = scores[thresh_idx]
        print(f"Initial static threshold set at: {self.threshold_}")

        return self

    def fit_predict(self, X, y):
        return self.fit(X, y).predict(X, y)

    def predict(self, X, y):
        print("Predicting labels...")
        scores = self.score_samples(X, y)

        print("Scores before differential privacy noise:", scores)
        scores = self.differential_privacy_noise(scores)

        dynamic_threshold = self.calculate_dynamic_threshold(scores)
        print(f"Dynamic threshold used for prediction: {dynamic_threshold}")

        preds = np.ones_like(scores, dtype=int)
        preds[scores < dynamic_threshold] = -1
        print(f"Predictions: {preds}")

        self.update_trust_score(dynamic_threshold)
        print(f"Updated trust score: {self.trust_score}")

        return preds

    def score_samples(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        if self.approach == 'clf':
            probas = self._estimator.predict_proba(X)
            scores = probas[np.arange(len(y)), y]
        elif self.approach == 'distance':
            dists, idxs = self._estimator.kneighbors(X)
            scores = self.calculate_distance_scores(dists, idxs, y)
        elif self.approach == 'density':
            scores = self._estimator.score_samples(X)
        else:
            raise RuntimeError(self.approach)

        arima_pred = self.arima_model_.predict(start=0, end=len(y) - 1)
        garch_pred = self.garch_model_.conditional_volatility[:len(y)]

        if garch_pred.shape[0] != arima_pred.shape[0]:
            garch_pred = np.resize(garch_pred, arima_pred.shape)

        print("ARIMA predictions:", arima_pred[:10])
        print("GARCH conditional volatility:", garch_pred[:10])

        lipschitz_adjustment = self.calculate_lipschitz_adjustment(arima_pred, garch_pred)
        print("Lipschitz adjustment:", lipschitz_adjustment[:10])

        scores += arima_pred + garch_pred + lipschitz_adjustment

        self.recent_scores.extend(scores)
        if len(self.recent_scores) > self.window_size:
            self.recent_scores = self.recent_scores[-self.window_size:]

        return scores

    def calculate_dynamic_threshold(self, scores):
        if len(self.recent_scores) < self.window_size:
            print("Not enough recent scores, using initial static threshold.")
            return self.threshold_

        mean_score = np.mean(self.recent_scores)
        variance_score = np.var(self.recent_scores)
        dynamic_threshold = mean_score + self.alpha * variance_score
        print(f"Recent scores mean: {mean_score}")
        print(f"Recent scores variance: {variance_score}")
        print(f"Calculated dynamic threshold: {dynamic_threshold}")
        return dynamic_threshold
    
    def update_trust_score(self, new_score):
        self.trust_score = max(0, min(1, self.trust_score - (0.1 * new_score)))
        print(f"Trust score updated: {self.trust_score}")

    def trust_aware_threshold(self, dynamic_threshold):
        trust_adjusted_threshold = dynamic_threshold - (1 - self.trust_score) * self.beta
        print(f"Trust-aware dynamic threshold: {trust_adjusted_threshold}")
        return trust_adjusted_threshold

    def differential_privacy_noise(self, scores):
        noise = np.random.laplace(0, 1.0 / self.epsilon, size=scores.shape)
        noisy_scores = scores + noise
        print(f"Noise added for differential privacy: {noise[:10]}")
        print(f"Noisy scores after applying differential privacy: {noisy_scores[:10]}")
        return noisy_scores

    def calculate_lipschitz_adjustment(self, arima_pred, garch_pred):
        adjustment = self.gamma * np.abs(garch_pred - arima_pred)
        self.lipschitz_constant += adjustment.mean()
        print(f"Lipschitz constant updated: {self.lipschitz_constant}")
        return self.lipschitz_constant * adjustment

    def calculate_distance_scores(self, dists, idxs, y):
        scores = []
        for dist, idx, yi in zip(dists, idxs, y):
            yi = int(yi)
            assert yi in {0, 1}, yi

            pop_yi = self.y_train[idx]
            dist_0 = self.calculate_aggregate_distance(dist, pop_yi, 0)
            dist_1 = self.calculate_aggregate_distance(dist, pop_yi, 1)

            if yi == 1:
                dist_yi, dist_other = dist_1, dist_0
            else:
                dist_yi, dist_other = dist_0, dist_1

            score = self.calculate_score(dist_yi, dist_other)
            scores.append(score)
        return np.asarray(scores)

    def calculate_aggregate_distance(self, dist, pop_yi, class_label):
        where_class = np.where(pop_yi == class_label)
        dists_class = dist[where_class]
        if dists_class.size:
            return self.distance_agg(dists_class)
        else:
            return np.inf

    def calculate_score(self, dist_yi, dist_other):
        if not self.distance_penalize_accurate and dist_yi < dist_other:
            return 1.0
        else:
            if dist_yi == dist_other == 0:
                return 1.0
            else:
                with np.errstate(divide='ignore'):
                    return 1 / (1 + dist_yi / dist_other)
