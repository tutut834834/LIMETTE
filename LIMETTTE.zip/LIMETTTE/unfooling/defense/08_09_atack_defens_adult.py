import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors.get(label, '#000000'), edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Data for LIME and SHAP for all 5 runs
lime_data = {
    'Run 1 - No Attack': {
        '1st': {'sex_Male': 1.0},
        '2nd': {'sex_Female': 1.0},
        '3rd': {'occupation_Protective-serv': 0.3169, 'race_Asian-Pac-Islander': 0.2904, 'workclass_Self-emp-inc': 0.1922, 'workclass_?': 0.1677, 'unrelated_column_two': 0.0164}
    },
    'Run 1 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'occupation_Protective-serv': 0.2229, 'race_Asian-Pac-Islander': 0.1636, 'workclass_?': 0.1411, 'workclass_Self-emp-inc': 0.1370, 'unrelated_column_two': 0.1207},
        '3rd': {'sex_Male': 0.1779, 'workclass_?': 0.1411, 'unrelated_column_two': 0.1370, 'occupation_Protective-serv': 0.1350, 'sex_Female': 0.1329}
    },
    'Run 1 - Attack 2': {
        '1st': {'occupation_Protective-serv': 0.2843, 'race_Asian-Pac-Islander': 0.2372, 'workclass_?': 0.1943, 'workclass_Self-emp-inc': 0.1595, 'unrelated_column_one': 0.0450},
        '2nd': {'race_Asian-Pac-Islander': 0.1861, 'workclass_Self-emp-inc': 0.1840, 'occupation_Protective-serv': 0.1820, 'workclass_?': 0.1738, 'unrelated_column_two': 0.0961},
        '3rd': {'workclass_?': 0.1738, 'race_Asian-Pac-Islander': 0.1493, 'workclass_Self-emp-inc': 0.1350, 'occupation_Protective-serv': 0.1268, 'unrelated_column_two': 0.1186}
    },
    'Run 1 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 1 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 2 - No Attack': {
        '1st': {'sex_Male': 1.0},
        '2nd': {'sex_Female': 1.0},
        '3rd': {'education_Doctorate': 0.2986, 'marital-status_Married-spouse-absent': 0.2843, 'education_Preschool': 0.2372, 'education_Masters': 0.1145, 'workclass_Local-gov': 0.0593}
    },
    'Run 2 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'marital-status_Married-spouse-absent': 0.1984, 'education_Doctorate': 0.1881, 'education_Preschool': 0.1820, 'unrelated_column_two': 0.1125, 'sex_Male': 0.0838},
        '3rd': {'marital-status_Married-spouse-absent': 0.1411, 'education_Doctorate': 0.1391, 'education_Preschool': 0.1288, 'sex_Male': 0.1247, 'unrelated_column_two': 0.1247}
    },
    'Run 2 - Attack 2': {
        '1st': {'education_Preschool': 0.3476, 'marital-status_Married-spouse-absent': 0.2638, 'education_Doctorate': 0.2249, 'education_Masters': 0.0736, 'workclass_Local-gov': 0.0491},
        '2nd': {'education_Doctorate': 0.2249, 'marital-status_Married-spouse-absent': 0.1943, 'education_Preschool': 0.1595, 'education_Masters': 0.1411, 'workclass_Local-gov': 0.1186},
        '3rd': {'marital-status_Married-spouse-absent': 0.1595, 'education_Masters': 0.1411, 'workclass_Local-gov': 0.1370, 'unrelated_column_two': 0.1349, 'education_Doctorate': 0.1207}
    },
    'Run 2 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 2 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 3 - No Attack': {
        '1st': {'sex_Male': 1.0},
        '2nd': {'sex_Female': 1.0},
        '3rd': {'occupation_Farming-fishing': 0.4560, 'occupation_Sales': 0.1943, 'race_White': 0.1534, 'education_Some-college': 0.0798, 'unrelated_column_two': 0.0654}
    },
    'Run 3 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'occupation_Farming-fishing': 0.2270, 'race_White': 0.1636, 'occupation_Sales': 0.1431, 'education_Some-college': 0.1370, 'sex_Female': 0.1166},
        '3rd': {'sex_Male': 0.1881, 'unrelated_column_two': 0.1616, 'sex_Female': 0.1350, 'occupation_Sales': 0.1268, 'occupation_Farming-fishing': 0.1227}
    },
    'Run 3 - Attack 2': {
        '1st': {'occupation_Farming-fishing': 0.3783, 'unrelated_column_two': 0.1370, 'occupation_Sales': 0.1268, 'unrelated_column_one': 0.1125, 'race_White': 0.1022},
        '2nd': {'unrelated_column_two': 0.1902, 'occupation_Sales': 0.1575, 'occupation_Farming-fishing': 0.1472, 'race_White': 0.1166, 'education_Some-college': 0.1125},
        '3rd': {'unrelated_column_one': 0.1656, 'race_White': 0.1329, 'unrelated_column_two': 0.1247, 'sex_Male': 0.1186, 'occupation_Sales': 0.1166}
    },
    'Run 3 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
      'Run 3 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 4 - No Attack': {
        '1st': {'sex_Male': 1.0},
        '2nd': {'sex_Female': 1.0},
        '3rd': {'education_1st-4th': 0.4131, 'occupation_Protective-serv': 0.2393, 'occupation_Farming-fishing': 0.1534, 'education_Assoc-voc': 0.1452, 'occupation_Craft-repair': 0.0368}
    },
    'Run 4 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'education_1st-4th': 0.2393, 'occupation_Protective-serv': 0.1534, 'occupation_Farming-fishing': 0.1452, 'education_Assoc-voc': 0.1186, 'sex_Male': 0.0941},
        '3rd': {'occupation_Protective-serv': 0.1493, 'sex_Female': 0.1452, 'education_Assoc-voc': 0.1288, 'occupation_Farming-fishing': 0.1268, 'sex_Male': 0.1186}
    },
    'Run 4 - Attack 2': {
        '1st': {'education_1st-4th': 0.3824, 'occupation_Protective-serv': 0.2352, 'occupation_Farming-fishing': 0.1616, 'education_Assoc-voc': 0.1431, 'occupation_Craft-repair': 0.0327},
        '2nd': {'occupation_Protective-serv': 0.2147, 'education_1st-4th': 0.1984, 'education_Assoc-voc': 0.1656, 'occupation_Farming-fishing': 0.1595, 'occupation_Craft-repair': 0.0716},
        '3rd': {'occupation_Farming-fishing': 0.1636, 'education_Assoc-voc': 0.1513, 'occupation_Protective-serv': 0.1452, 'occupation_Craft-repair': 0.1104, 'unrelated_column_one': 0.1104}
    },
    'Run 4 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 4 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 5 - No Attack': {
        '1st': {'sex_Male': 1.0},
        '2nd': {'sex_Female': 1.0},
        '3rd': {'occupation_Tech-support': 0.3906, 'education_11th': 0.3088, 'education_Masters': 0.2025, 'unrelated_column_two': 0.0368, 'education_HS-grad': 0.0348}
    },
    'Run 5 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'occupation_Tech-support': 0.1800, 'education_11th': 0.1718, 'education_HS-grad': 0.1575, 'unrelated_column_two': 0.1431, 'education_Masters': 0.1288},
        '3rd': {'sex_Male': 0.1800, 'unrelated_column_two': 0.1677, 'sex_Female': 0.1595, 'education_11th': 0.1452, 'education_HS-grad': 0.1084}
    },
    'Run 5 - Attack 2': {
        '1st': {'occupation_Tech-support': 0.3517, 'education_11th': 0.2638, 'education_Masters': 0.1759, 'unrelated_column_one': 0.0654, 'unrelated_column_two': 0.0654},
        '2nd': {'education_11th': 0.1922, 'education_Masters': 0.1902, 'unrelated_column_two': 0.1554, 'occupation_Tech-support': 0.1513, 'unrelated_column_one': 0.1207},
        '3rd': {'unrelated_column_one': 0.1472, 'education_Masters': 0.1329, 'occupation_Tech-support': 0.1288, 'education_11th': 0.1268, 'sex_Male': 0.1207}
    },
    'Run 5 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 5 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    }
}

shap_data = {
    'Run 1 - No Attack': {
        '1st': {'sex_Female': 0.5215, 'sex_Male': 0.4785},
        '2nd': {'sex_Male': 0.5215, 'sex_Female': 0.4785},
        '3rd': {'unrelated_column_two': 0.1472, 'workclass_Self-emp-inc': 0.1472, 'occupation_Protective-serv': 0.1309, 'workclass_?': 0.1268, 'hours-per-week': 0.1186}
    },
    'Run 1 - Attack 1': {
        '1st': {'unrelated_column_one': 0.7771, 'hours-per-week': 0.1943, 'race_Asian-Pac-Islander': 0.0102, 'occupation_Protective-serv': 0.0041, 'unrelated_column_two': 0.0041},
        '2nd': {'hours-per-week': 0.4029, 'unrelated_column_one': 0.2065, 'sex_Male': 0.1350, 'sex_Female': 0.1207, 'education-num': 0.0532},
        '3rd': {'sex_Male': 0.2658, 'sex_Female': 0.2577, 'education-num': 0.2147, 'hours-per-week': 0.1145, 'unrelated_column_two': 0.0859}
    },
    'Run 1 - Attack 2': {
        '1st': {'hours-per-week': 0.7157, 'unrelated_column_two': 0.1554, 'unrelated_column_one': 0.0552, 'education-num': 0.0307, 'sex_Female': 0.0164},
        '2nd': {'unrelated_column_one': 0.4213, 'unrelated_column_two': 0.3108, 'education-num': 0.0961, 'hours-per-week': 0.0798, 'sex_Male': 0.0286},
        '3rd': {'unrelated_column_one': 0.3006, 'unrelated_column_two': 0.2270, 'education-num': 0.2147, 'hours-per-week': 0.0818, 'sex_Female': 0.0613}
    },
    'Run 1 - Attack 1 Defense': {
        '1st': {'Nothing shown': 0.9979550102249489},
        '2nd': {'Nothing shown': 0.9979550102249489},
        '3rd': {'Nothing shown': 0.9979550102249489}
    },
    'Run 1 - Attack 2 Defense': {
        '1st': {'Nothing shown': 0.9938650306748467},
        '2nd': {'Nothing shown': 0.9938650306748467},
        '3rd': {'Nothing shown': 0.9938650306748467}
    },
    'Run 2 - No Attack': {
        '1st': {'sex_Female': 0.5235, 'sex_Male': 0.4765},
        '2nd': {'sex_Male': 0.5235, 'sex_Female': 0.4765},
        '3rd': {'education_Doctorate': 0.1493, 'marital-status_Married-spouse-absent': 0.1411, 'education_Preschool': 0.1329, 'unrelated_column_one': 0.1288, 'workclass_Local-gov': 0.1207}
    },
    'Run 2 - Attack 1': {
        '1st': {'unrelated_column_one': 0.9959, 'marital-status_Married-spouse-absent': 0.0041},
        '2nd': {'sex_Female': 0.4622, 'sex_Male': 0.4458, 'education-num': 0.0470, 'education_Masters': 0.0225, 'marital-status_Married-spouse-absent': 0.0143},
        '3rd': {'sex_Male': 0.4560, 'sex_Female': 0.4397, 'education-num': 0.0491, 'education_Masters': 0.0429, 'workclass_Local-gov': 0.0061}
    },
    'Run 2 - Attack 2': {
        '1st': {'unrelated_column_two': 0.3926, 'unrelated_column_one': 0.3845, 'sex_Male': 0.1125, 'sex_Female': 0.0961, 'marital-status_Married-spouse-absent': 0.0102},
        '2nd': {'unrelated_column_one': 0.2761, 'unrelated_column_two': 0.2761, 'sex_Female': 0.2311, 'sex_Male': 0.1902, 'marital-status_Married-spouse-absent': 0.0102},
        '3rd': {'unrelated_column_two': 0.2413, 'sex_Male': 0.2352, 'unrelated_column_one': 0.2290, 'sex_Female': 0.2270, 'education-num': 0.0368}
    },
    'Run 2 - Attack 1 Defense': {
        '1st': {'Nothing shown': 0.9979550102249489},
        '2nd': {'Nothing shown': 0.9979550102249489},
        '3rd': {'Nothing shown': 0.9979550102249489}
    },
    'Run 2 - Attack 2 Defense': {
        '1st': {'Nothing shown': 0.9938650306748467},
        '2nd': {'Nothing shown': 0.9938650306748467},
        '3rd': {'Nothing shown': 0.9938650306748467}
    },
    'Run 3 - No Attack': {
        '1st': {'sex_Male': 0.5051, 'sex_Female': 0.4949},
        '2nd': {'sex_Female': 0.5051, 'sex_Male': 0.4949},
        '3rd': {'hours-per-week': 0.1697, 'occupation_Farming-fishing': 0.1288, 'unrelated_column_one': 0.1247, 'unrelated_column_two': 0.1247, 'education_Some-college': 0.1207}
    },
    'Run 3 - Attack 1': {
        '1st': {'unrelated_column_one': 0.9550, 'hours-per-week': 0.0307, 'education-num': 0.0143},
        '2nd': {'education-num': 0.4274, 'hours-per-week': 0.4233, 'education_Some-college': 0.0491, 'unrelated_column_one': 0.0450, 'race_White': 0.0245},
        '3rd': {'hours-per-week': 0.3845, 'education-num': 0.2454, 'unrelated_column_two': 0.1575, 'education_Some-college': 0.0900, 'sex_Female': 0.0470}
    },
    'Run 3 - Attack 2': {
        '1st': {'unrelated_column_two': 0.2781, 'unrelated_column_one': 0.2658, 'hours-per-week': 0.2434, 'education-num': 0.1616, 'education_Some-college': 0.0389},
        '2nd': {'hours-per-week': 0.4683, 'education-num': 0.2699, 'unrelated_column_one': 0.0961, 'unrelated_column_two': 0.0736, 'education_Some-college': 0.0511},
        '3rd': {'unrelated_column_two': 0.2393, 'unrelated_column_one': 0.1820, 'education-num': 0.1738, 'hours-per-week': 0.1554, 'sex_Female': 0.0634}
    },
    'Run 3 - Attack 1 Defense': {
        '1st': {'Nothing shown': 0.9979550102249489},
        '2nd': {'Nothing shown': 0.9979550102249489},
        '3rd': {'Nothing shown': 0.9979550102249489}
    },
    'Run 3 - Attack 2 Defense': {
        '1st': {'Nothing shown': 0.9938650306748467},
        '2nd': {'Nothing shown': 0.9938650306748467},
        '3rd': {'Nothing shown': 0.9938650306748467}
    },
    'Run 4 - No Attack': {
        '1st': {'sex_Female': 0.5215, 'sex_Male': 0.4785},
        '2nd': {'sex_Male': 0.5215, 'sex_Female': 0.4785},
        '3rd': {'education_1st-4th': 0.1595, 'unrelated_column_two': 0.1493, 'education-num': 0.1268, 'education_Assoc-voc': 0.1268, 'unrelated_column_one': 0.1207}
    },
    'Run 4 - Attack 1': {
        '1st': {'unrelated_column_one': 0.9673, 'occupation_Farming-fishing': 0.0245, 'education-num': 0.0041, 'occupation_Protective-serv': 0.0041},
        '2nd': {'sex_Female': 0.4479, 'sex_Male': 0.3926, 'education-num': 0.0450, 'occupation_Craft-repair': 0.0348, 'education_Assoc-voc': 0.0225},
        '3rd': {'sex_Male': 0.4499, 'sex_Female': 0.3967, 'education-num': 0.0552, 'occupation_Craft-repair': 0.0552, 'education_Assoc-voc': 0.0245}
    },
    'Run 4 - Attack 2': {
        '1st': {'unrelated_column_two': 0.3640, 'unrelated_column_one': 0.3190, 'sex_Male': 0.1268, 'sex_Female': 0.1063, 'occupation_Craft-repair': 0.0389},
        '2nd': {'unrelated_column_two': 0.2495, 'sex_Female': 0.2331, 'sex_Male': 0.2331, 'unrelated_column_one': 0.1902, 'occupation_Craft-repair': 0.0736},
        '3rd': {'unrelated_column_one': 0.2474, 'sex_Female': 0.2454, 'sex_Male': 0.2393, 'unrelated_column_two': 0.2045, 'education-num': 0.0266}
    },
    'Run 4 - Attack 1 Defense': {
        '1st': {'Nothing shown': 0.9979550102249489},
        '2nd': {'Nothing shown': 0.9979550102249489},
        '3rd': {'Nothing shown': 0.9979550102249489}
    },
    'Run 4 - Attack 2 Defense': {
        '1st': {'Nothing shown': 0.9938650306748467},
        '2nd': {'Nothing shown': 0.9938650306748467},
        '3rd': {'Nothing shown': 0.9938650306748467}
    },
    'Run 5 - No Attack': {
        '1st': {'sex_Male': 0.5399, 'sex_Female': 0.4601},
        '2nd': {'sex_Female': 0.5399, 'sex_Male': 0.4601},
            '3rd': {'Nothing shown': 0.4499, 'unrelated_column_two': 0.0941, 'education_Masters': 0.0920, 'education_11th': 0.0838, 'occupation_Tech-support': 0.0798}
    },
    'Run 5 - Attack 1': {
        '1st': {'unrelated_column_one': 0.7055, 'hours-per-week': 0.2761, 'occupation_Tech-support': 0.0082, 'education_11th': 0.0061, 'education_HS-grad': 0.0041},
        '2nd': {'hours-per-week': 0.5051, 'unrelated_column_one': 0.2822, 'sex_Male': 0.0818, 'sex_Female': 0.0593, 'education_11th': 0.0348},
        '3rd': {'sex_Female': 0.3845, 'sex_Male': 0.3272, 'education_HS-grad': 0.1800, 'hours-per-week': 0.0389, 'unrelated_column_two': 0.0286}
    },
    'Run 5 - Attack 2': {
        '1st': {'hours-per-week': 0.7423, 'unrelated_column_two': 0.1063, 'unrelated_column_one': 0.0695, 'sex_Female': 0.0368, 'sex_Male': 0.0307},
        '2nd': {'unrelated_column_two': 0.3845, 'unrelated_column_one': 0.2413, 'sex_Male': 0.1370, 'sex_Female': 0.1084, 'hours-per-week': 0.0982},
        '3rd': {'unrelated_column_one': 0.4049, 'unrelated_column_two': 0.1881, 'sex_Female': 0.1575, 'sex_Male': 0.1166, 'hours-per-week': 0.1104}
    },
    'Run 5 - Attack 1 Defense': {
        '1st': {'Nothing shown': 0.9877},
        '2nd': {'Nothing shown': 0.9877},
        '3rd': {'Nothing shown': 0.9877}
    },
    'Run 5 - Attack 2 Defense': {
        '1st': {'Nothing shown': 0.9939},
        '2nd': {'Nothing shown': 0.9939},
        '3rd': {'Nothing shown': 0.9939}
    }
}

# Color mapping for features
colors = {
    'sex_Male': '#FF7F0E',
    'sex_Female': '#1F77B4',
    'occupation_Protective-serv': '#2CA02C',
    'race_Asian-Pac-Islander': '#D62728',
    'workclass_Self-emp-inc': '#9467BD',
    'workclass_?': '#8C564B',
    'unrelated_column_two': '#E377C2',
    'unrelated_column_one': '#17BECF',
    'hours-per-week': '#BCBD22',
    'education-num': '#FFBB78',
    'education_Preschool': '#C49C94',
    'education_Doctorate': '#7F7F7F',
    'education_1st-4th': '#98DF8A',
    'occupation_Farming-fishing': '#17BECF',
    'occupation_Sales': '#FF9896',
    'education_HS-grad': '#CCCCCC',
    'education_Masters': '#9B9B9B',
    'occupation_Tech-support': '#C7C7C7',
    'Nothing shown': '#CCCCCC'
}

# Adjust the subplot grid to accommodate all the scenarios
fig, axs = plt.subplots(5, 10, figsize=(30, 30))  # 5 rows for each run, 10 columns for each scenario

# Plotting LIME scenarios for all 5 runs
for i in range(5):
    run_name = f'Run {i+1}'
    plot_bar(axs[i, 0], lime_data[f'{run_name} - No Attack'], f'{run_name} - LIME: No Attack', colors)
    plot_bar(axs[i, 1], lime_data[f'{run_name} - Attack 1'], f'{run_name} - LIME: Attack 1', colors)
    plot_bar(axs[i, 2], lime_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - LIME: Attack 1 Defense', colors)
    plot_bar(axs[i, 3], lime_data[f'{run_name} - Attack 2'], f'{run_name} - LIME: Attack 2', colors)
    plot_bar(axs[i, 4], lime_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - LIME: Attack 2 Defense', colors)

    # Plotting SHAP scenarios for all 5 runs
    plot_bar(axs[i, 5], shap_data[f'{run_name} - No Attack'], f'{run_name} - SHAP: No Attack', colors)
    plot_bar(axs[i, 6], shap_data[f'{run_name} - Attack 1'], f'{run_name} - SHAP: Attack 1', colors)
    plot_bar(axs[i, 7], shap_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - SHAP: Attack 1 Defense', colors)
    plot_bar(axs[i, 8], shap_data[f'{run_name} - Attack 2'], f'{run_name} - SHAP: Attack 2', colors)
    plot_bar(axs[i, 9], shap_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - SHAP: Attack 2 Defense', colors)

# Adding the legend
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.05), fontsize=12)

# Adjust the layout for better visualization
plt.tight_layout()

# Save the plot as a PNG file
plt.savefig("attack_defense_graph_runs_final_big_ad.png", bbox_inches='tight', dpi=300)
plt.savefig("attack_defense_graph_runs_final_big_ad.jpeg", bbox_inches='tight', dpi=300)

# Show the plot
plt.show()




