import numpy as np
from sklearn.base import OutlierMixin, BaseEstimator
from sklearn.neighbors import KNeighborsClassifier, KernelDensity, NearestNeighbors
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.stattools import adfuller, pacf

class KNNCAD(OutlierMixin, BaseEstimator):
    def __init__(
            self,
            approach='distance',
            distance_agg='median',
            epsilon=0.05,
            n_neighbors=20,
            weights='distance',
            algorithm='auto',
            distance_penalize_accurate=True,
            leaf_size=None,
            p=2,
            metric=None,
            metric_params=None,
            n_jobs=-1,
            bandwidth=1.0,
            atol=0,
            rtol=0,
            breadth_first=True,
            radius=1.0,
            arima_order=None  # Now optional
    ):
        self.distance_agg = self._get_agg_function(distance_agg)
        self.approach = approach
        self.epsilon = epsilon
        self.distance_penalize_accurate = distance_penalize_accurate
        self.arima_order = arima_order
        self.threshold_ = None
        self.arima_model_ = None
        
        # Initialize the base estimator
        if approach == 'clf':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = KNeighborsClassifier(
                n_neighbors=n_neighbors,
                weights=weights,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                n_jobs=n_jobs,
            )
        elif approach == 'distance':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = NearestNeighbors(
                n_neighbors=n_neighbors,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                radius=radius,
                n_jobs=n_jobs,
            )
        elif approach == 'density':
            metric = metric or 'euclidean'
            leaf_size = leaf_size or 40
            self._estimator = KernelDensity(
                bandwidth=bandwidth,
                algorithm=algorithm,
                leaf_size=leaf_size,
                metric=metric,
                metric_params=metric_params,
                atol=atol,
                rtol=rtol,
                breadth_first=breadth_first,
            )
        else:
            raise ValueError(f"Unknown approach: {approach}")

    def _get_agg_function(self, agg):
        """Convert a string aggregation function name to an actual numpy function."""
        if isinstance(agg, str):
            if agg in ['mean', 'median', 'max', 'min', 'sum']:
                return getattr(np, agg)
            else:
                raise ValueError(f"Unknown aggregation function: {agg}")
        return agg

    def select_arima_order(self, y):
        """Automatically select the best ARIMA order using AIC."""
        p_max = min(5, len(y) // 5)  # Limit p to avoid overfitting on small datasets
        q_max = min(5, len(y) // 5)  # Limit q similarly
        best_aic = np.inf
        best_order = None
        
        for p in range(p_max + 1):
            for d in [0, 1]:  # Typically, d is 0 or 1
                for q in range(q_max + 1):
                    try:
                        model = ARIMA(y, order=(p, d, q)).fit()
                        if model.aic < best_aic:
                            best_aic = model.aic
                            best_order = (p, d, q)
                    except:
                        continue
        return best_order

    def fit(self, X, y):
        print("Starting fit process...")
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        self.X_train, self.y_train = X, y
        self._estimator.fit(X, y)
        print("Base estimator fitted.")

        # Select ARIMA order if not provided
        if self.arima_order is None:
            print("Selecting ARIMA order...")
            self.arima_order = self.select_arima_order(y)
            print(f"Selected ARIMA order: {self.arima_order}")

        # Fit ARIMA model on the output (y) to capture temporal dependencies
        self.arima_model_ = ARIMA(y, order=self.arima_order).fit()
        print("ARIMA model fitted.")

        # Determine threshold using KNN-based scoring
        scores = self.score_samples(X, y)
        scores.sort()

        thresh_idx = round(self.epsilon * len(X))
        self.threshold_ = scores[thresh_idx]
        print(f"Threshold determined: {self.threshold_}")

        return self

    def predict(self, X, y):
        scores = self.score_samples(X, y)
        preds = np.ones_like(scores, dtype=int)
        preds[scores < self.threshold_] = -1
        return preds

    def score_samples(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        if self.approach == 'clf':
            probas = self._estimator.predict_proba(X)
            scores = probas[np.arange(len(y)), y]
        elif self.approach == 'distance':
            dists, idxs = self._estimator.kneighbors(X)
            scores = self.calculate_distance_scores(dists, idxs, y)
        elif self.approach == 'density':
            scores = self._estimator.score_samples(X)
        else:
            raise RuntimeError(self.approach)

        # Integrate ARIMA model predictions
        arima_pred = self.arima_model_.predict(start=len(y), end=len(y) + len(y) - 1)
        scores += arima_pred  # Integrate ARIMA prediction with the score

        return scores

    def calculate_distance_scores(self, dists, idxs, y):
        scores = []
        for dist, idx, yi in zip(dists, idxs, y):
            yi = int(yi)
            assert yi in {0, 1}, yi

            pop_yi = self.y_train[idx]
            dist_0 = self.calculate_aggregate_distance(dist, pop_yi, 0)
            dist_1 = self.calculate_aggregate_distance(dist, pop_yi, 1)

            if yi == 1:
                dist_yi, dist_other = dist_1, dist_0
            else:
                dist_yi, dist_other = dist_0, dist_1

            score = self.calculate_score(dist_yi, dist_other)
            scores.append(score)
        return np.asarray(scores)

    def calculate_aggregate_distance(self, dist, pop_yi, class_label):
        where_class = np.where(pop_yi == class_label)
        dists_class = dist[where_class]
        if dists_class.size:
            return self.distance_agg(dists_class)
        else:
            return np.inf

    def calculate_score(self, dist_yi, dist_other):
        if not self.distance_penalize_accurate and dist_yi < dist_other:
            return 1.0
        else:
            if dist_yi == dist_other == 0:
                return 1.0
            else:
                with np.errstate(divide='ignore'):
                    return 1 / (1 + dist_yi / dist_other)
