import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Updated data for LIME and SHAP for all 5 runs
lime_data = {
    'Run 1 - No Attack': {
        '1st': {'Gender': 1.0},
        '2nd': {'Unemployed': 0.08, 'YearsAtCurrentJob_lt_1': 0.08, 'HasTelephone': 0.07, 'CheckingAccountBalance_geq_0': 0.06, 'CriticalAccountOrLoansElsewhere': 0.06},
        '3rd': {'HasCoapplicant': 0.09, 'SavingsAccountBalance_geq_500': 0.09, 'YearsAtCurrentJob_lt_1': 0.09, 'OtherLoansAtBank': 0.07, 'HasGuarantor': 0.06},
    },
    'Run 1 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.59, 'Single': 0.05, 'OwnsHouse': 0.04, 'SavingsAccountBalance_geq_500': 0.04, 'MissedPayments': 0.03},
        '2nd': {'MissedPayments': 0.09, 'HasGuarantor': 0.07, 'OtherLoansAtBank': 0.07, 'OwnsHouse': 0.07, 'SavingsAccountBalance_geq_500': 0.07},
        '3rd': {'MissedPayments': 0.09, 'SavingsAccountBalance_geq_500': 0.07, 'Unemployed': 0.07, 'CheckingAccountBalance_geq_0': 0.06, 'CheckingAccountBalance_geq_200': 0.06},
    },
    'Run 2 - No Attack': {
        '1st': {'Gender': 1.0},
        '2nd': {'OtherLoansAtBank': 0.08, 'SavingsAccountBalance_geq_500': 0.08, 'ForeignWorker': 0.07, 'SavingsAccountBalance_geq_100': 0.07, 'YearsAtCurrentJob_lt_1': 0.07},
        '3rd': {'HasCoapplicant': 0.1, 'HasTelephone': 0.08, 'HasGuarantor': 0.07, 'JobClassIsSkilled': 0.07, 'RentsHouse': 0.07},
    },
    'Run 2 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.54, 'MissedPayments': 0.06, 'CriticalAccountOrLoansElsewhere': 0.05, 'Single': 0.04, 'Gender': 0.03},
        '2nd': {'OtherLoansAtBank': 0.1, 'RentsHouse': 0.08, 'HasCoapplicant': 0.07, 'HasGuarantor': 0.07, 'ForeignWorker': 0.06},
        '3rd': {'SavingsAccountBalance_geq_500': 0.1, 'YearsAtCurrentJob_lt_1': 0.07, 'CheckingAccountBalance_geq_200': 0.06, 'CriticalAccountOrLoansElsewhere': 0.06, 'HasGuarantor': 0.06},
    },
    'Run 3 - No Attack': {
        '1st': {'Gender': 1.0},
        '2nd': {'JobClassIsSkilled': 0.08, 'SavingsAccountBalance_geq_500': 0.08, 'Single': 0.08, 'CheckingAccountBalance_geq_200': 0.07, 'HasCoapplicant': 0.07},
        '3rd': {'SavingsAccountBalance_geq_500': 0.14, 'CheckingAccountBalance_geq_0': 0.1, 'MissedPayments': 0.09, 'YearsAtCurrentJob_lt_1': 0.08, 'CriticalAccountOrLoansElsewhere': 0.07},
    },
    'Run 3 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.55, 'RentsHouse': 0.04, 'Unemployed': 0.04, 'YearsAtCurrentJob_lt_1': 0.04, 'CheckingAccountBalance_geq_200': 0.03},
        '2nd': {'MissedPayments': 0.09, 'OtherLoansAtBank': 0.08, 'RentsHouse': 0.08, 'Unemployed': 0.08, 'SavingsAccountBalance_geq_500': 0.07},
        '3rd': {'SavingsAccountBalance_geq_100': 0.12, 'OwnsHouse': 0.09, 'OtherLoansAtBank': 0.08, 'CheckingAccountBalance_geq_200': 0.07, 'SavingsAccountBalance_geq_500': 0.07},
    },
    'Run 4 - No Attack': {
        '1st': {'Gender': 1.0},
        '2nd': {'YearsAtCurrentJob_geq_4': 0.12, 'SavingsAccountBalance_geq_500': 0.1, 'OwnsHouse': 0.09, 'YearsAtCurrentJob_lt_1': 0.08, 'HasGuarantor': 0.07},
        '3rd': {'CheckingAccountBalance_geq_200': 0.11, 'JobClassIsSkilled': 0.08, 'HasTelephone': 0.07, 'SavingsAccountBalance_geq_500': 0.07, 'Unemployed': 0.07},
    },
    'Run 4 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.58, 'YearsAtCurrentJob_lt_1': 0.06, 'MissedPayments': 0.05, 'JobClassIsSkilled': 0.04, 'OwnsHouse': 0.04},
        '2nd': {'RentsHouse': 0.09, 'Single': 0.09, 'CriticalAccountOrLoansElsewhere': 0.07, 'HasCoapplicant': 0.07, 'YearsAtCurrentJob_lt_1': 0.07},
        '3rd': {'SavingsAccountBalance_geq_500': 0.09, 'ForeignWorker': 0.07, 'HasGuarantor': 0.07, 'MissedPayments': 0.07, 'OtherLoansAtBank': 0.06},
    },
    'Run 5 - No Attack': {
        '1st': {'Gender': 1.0},
        '2nd': {'CheckingAccountBalance_geq_0': 0.08, 'MissedPayments': 0.08, 'NoCurrentLoan': 0.07, 'OtherLoansAtBank': 0.07, 'SavingsAccountBalance_geq_100': 0.07},
        '3rd': {'SavingsAccountBalance_geq_500': 0.13, 'CheckingAccountBalance_geq_200': 0.1, 'MissedPayments': 0.08, 'YearsAtCurrentJob_lt_1': 0.08, 'CriticalAccountOrLoansElsewhere': 0.07},
    },
    'Run 5 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.59, 'SavingsAccountBalance_geq_500': 0.06, 'MissedPayments': 0.04, 'OtherLoansAtBank': 0.04, 'SavingsAccountBalance_geq_100': 0.04},
        '2nd': {'Single': 0.08, 'CheckingAccountBalance_geq_0': 0.07, 'ForeignWorker': 0.07, 'OtherLoansAtBank': 0.07, 'SavingsAccountBalance_geq_500': 0.07},
        '3rd': {'YearsAtCurrentJob_lt_1': 0.1, 'MissedPayments': 0.08, 'CheckingAccountBalance_geq_0': 0.07, 'CriticalAccountOrLoansElsewhere': 0.07, 'NoCurrentLoan': 0.07},
        }
    
}



# Continuing SHAP data for all 5 runs
shap_data = {
    'Run 1 - No Attack': {
        '1st': {'Gender': 0.75, 'SavingsAccountBalance_geq_500': 0.03, 'Age': 0.02, 'ForeignWorker': 0.02, 'OtherLoansAtBank': 0.02},
        '2nd': {'Nothing shown': 0.85, 'CheckingAccountBalance_geq_0': 0.02, 'CheckingAccountBalance_geq_200': 0.02, 'CriticalAccountOrLoansElsewhere': 0.02, 'Age': 0.01},
        '3rd': {'Nothing shown': 0.85, 'NoCurrentLoan': 0.02, 'Single': 0.02, 'Age': 0.01, 'CriticalAccountOrLoansElsewhere': 0.01},
    },
    'Run 1 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.5, 'Gender': 0.09, 'OwnsHouse': 0.05, 'HasTelephone': 0.03, 'JobClassIsSkilled': 0.03},
        '2nd': {'Nothing shown': 0.1, 'LoanDuration': 0.09, 'Gender': 0.08, 'HasCoapplicant': 0.06, 'SavingsAccountBalance_geq_500': 0.06},
        '3rd': {'Nothing shown': 0.14, 'OtherLoansAtBank': 0.09, 'YearsAtCurrentHome': 0.08, 'LoanDuration': 0.06, 'Gender': 0.05},
    },
    'Run 2 - No Attack': {
        '1st': {'Gender': 0.72, 'YearsAtCurrentJob_geq_4': 0.04, 'OtherLoansAtBank': 0.03, 'RentsHouse': 0.03, 'ForeignWorker': 0.02},
        '2nd': {'Nothing shown': 0.82, 'Age': 0.02, 'HasTelephone': 0.02, 'LoanRateAsPercentOfIncome': 0.02, 'NoCurrentLoan': 0.02},
        '3rd': {'Nothing shown': 0.82, 'MissedPayments': 0.03, 'HasGuarantor': 0.02, 'NumberOfLiableIndividuals': 0.02, 'CheckingAccountBalance_geq_0': 0.01},
    },
    'Run 2 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.49, 'Gender': 0.11, 'Age': 0.05, 'YearsAtCurrentHome': 0.05, 'LoanDuration': 0.04},
        '2nd': {'YearsAtCurrentHome': 0.08, 'LoanDuration': 0.07, 'OtherLoansAtBank': 0.06, 'RentsHouse': 0.06, 'Gender': 0.05},
        '3rd': {'OtherLoansAtBank': 0.08, 'Nothing shown': 0.07, 'OwnsHouse': 0.07, 'Gender': 0.06, 'Age': 0.05},
    },
    'Run 3 - No Attack': {
        '1st': {'Gender': 0.68, 'NoCurrentLoan': 0.04, 'LoanAmount': 0.03, 'LoanRateAsPercentOfIncome': 0.03, 'OtherLoansAtBank': 0.03},
        '2nd': {'Nothing shown': 0.74, 'HasCoapplicant': 0.04, 'Gender': 0.02, 'HasTelephone': 0.02, 'OwnsHouse': 0.02},
        '3rd': {'Nothing shown': 0.74, 'LoanRateAsPercentOfIncome': 0.03, 'NoCurrentLoan': 0.03, 'NumberOfLiableIndividuals': 0.03, 'OtherLoansAtBank': 0.03},
    },
    'Run 3 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.55, 'Gender': 0.08, 'Age': 0.06, 'CheckingAccountBalance_geq_0': 0.04, 'LoanAmount': 0.04},
        '2nd': {'Gender': 0.09, 'Age': 0.08, 'LoanAmount': 0.07, 'YearsAtCurrentHome': 0.07, 'HasCoapplicant': 0.06},
        '3rd': {'LoanAmount': 0.09, 'CriticalAccountOrLoansElsewhere': 0.07, 'LoanDuration': 0.06, 'LoanRateAsPercentOfIncome': 0.06, 'MissedPayments': 0.06},
    },
    'Run 4 - No Attack': {
        '1st': {'Gender': 0.7, 'LoanDuration': 0.03, 'Age': 0.02, 'CheckingAccountBalance_geq_0': 0.02, 'CriticalAccountOrLoansElsewhere': 0.02},
        '2nd': {'Nothing shown': 0.76, 'Unemployed': 0.04, 'YearsAtCurrentJob_geq_4': 0.03, 'LoanAmount': 0.02, 'OtherLoansAtBank': 0.02},
        '3rd': {'Nothing shown': 0.76, 'MissedPayments': 0.03, 'NoCurrentLoan': 0.03, 'YearsAtCurrentJob_lt_1': 0.03, 'Age': 0.02},
    },
    'Run 4 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.58, 'Gender': 0.07, 'Age': 0.04, 'CheckingAccountBalance_geq_200': 0.03, 'HasTelephone': 0.03},
        '2nd': {'Nothing shown': 0.11, 'Gender': 0.08, 'YearsAtCurrentHome': 0.08, 'LoanDuration': 0.07, 'OtherLoansAtBank': 0.07},
        '3rd': {'Nothing shown': 0.15, 'Gender': 0.07, 'Single': 0.06, 'YearsAtCurrentHome': 0.06, 'CriticalAccountOrLoansElsewhere': 0.05},
    },
    'Run 5 - No Attack': {
        '1st': {'Gender': 0.72, 'OtherLoansAtBank': 0.04, 'LoanAmount': 0.03, 'NumberOfOtherLoansAtBank': 0.03, 'Age': 0.02},
        '2nd': {'Nothing shown': 0.76, 'LoanRateAsPercentOfIncome': 0.04, 'YearsAtCurrentJob_geq_4': 0.04, 'HasGuarantor': 0.02, 'JobClassIsSkilled': 0.02},
        '3rd': {'Nothing shown': 0.76, 'Age': 0.03, 'OtherLoansAtBank': 0.03, 'Unemployed': 0.03, 'LoanDuration': 0.02},
    },
    'Run 5 - Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.5, 'Gender': 0.12, 'SavingsAccountBalance_geq_500': 0.05, 'ForeignWorker': 0.04, 'CriticalAccountOrLoansElsewhere': 0.03},
        '2nd': {'OtherLoansAtBank': 0.1, 'Gender': 0.07, 'NumberOfOtherLoansAtBank': 0.07, 'Age': 0.06, 'YearsAtCurrentJob_geq_4': 0.06},
        '3rd': {'CriticalAccountOrLoansElsewhere': 0.08, 'Nothing shown': 0.06, 'OtherLoansAtBank': 0.06, 'YearsAtCurrentHome': 0.06, 'CheckingAccountBalance_geq_200': 0.05},
    },
}

# Color mapping for features
colors = {
    'Gender': '#FF7F0E',
    'Unemployed': '#1F77B4',
    'YearsAtCurrentJob_lt_1': '#AEC7E8',
    'HasTelephone': '#FF9896',
    'CheckingAccountBalance_geq_0': '#98DF8A',
    'CriticalAccountOrLoansElsewhere': '#C49C94',
    'HasCoapplicant': '#9467BD',
    'SavingsAccountBalance_geq_500': '#C5B0D5',
    'OtherLoansAtBank': '#8C564B',
    'Single': '#E377C2',
    'LoanRateAsPercentOfIncome': '#D62728',
    'MissedPayments': '#2CA02C',
    'OwnsHouse': '#17BECF',
    'ForeignWorker': '#7F7F7F',
    'JobClassIsSkilled': '#BCBD22',
    'NoCurrentLoan': '#FFBB78',
    'LoanDuration': '#8C564B',
    'HasGuarantor': '#FF7F0E',
    'LoanAmount': '#2CA02C',
    'YearsAtCurrentHome': '#D62728',
    'YearsAtCurrentJob_geq_4': '#9467BD',
    'Nothing shown': '#C7C7C7',
    'Age': '#C49C94',
    'RentsHouse': '#FFCC99',  # Added missing feature with a color

    'CheckingAccountBalance_geq_200': '#2C7BB6',
    'SavingsAccountBalance_geq_100': '#17BECF',
}

# Creating the plot for LIME and SHAP comparisons for all 5 runs
fig, axs = plt.subplots(5, 4, figsize=(20, 30))

# Plotting LIME scenarios for all 5 runs
plot_bar(axs[0, 0], lime_data['Run 1 - No Attack'], 'Run 1 - LIME: No Attack', colors)
plot_bar(axs[0, 1], lime_data['Run 1 - Attack 1'], 'Run 1 - LIME: Attack 1', colors)
plot_bar(axs[1, 0], lime_data['Run 2 - No Attack'], 'Run 2 - LIME: No Attack', colors)
plot_bar(axs[1, 1], lime_data['Run 2 - Attack 1'], 'Run 2 - LIME: Attack 1', colors)
plot_bar(axs[2, 0], lime_data['Run 3 - No Attack'], 'Run 3 - LIME: No Attack', colors)
plot_bar(axs[2, 1], lime_data['Run 3 - Attack 1'], 'Run 3 - LIME: Attack 1', colors)
plot_bar(axs[3, 0], lime_data['Run 4 - No Attack'], 'Run 4 - LIME: No Attack', colors)
plot_bar(axs[3, 1], lime_data['Run 4 - Attack 1'], 'Run 4 - LIME: Attack 1', colors)
plot_bar(axs[4, 0], lime_data['Run 5 - No Attack'], 'Run 5 - LIME: No Attack', colors)
plot_bar(axs[4, 1], lime_data['Run 5 - Attack 1'], 'Run 5 - LIME: Attack 1', colors)

# Plotting SHAP scenarios for all 5 runs
plot_bar(axs[0, 2], shap_data['Run 1 - No Attack'], 'Run 1 - SHAP: No Attack', colors)
plot_bar(axs[0, 3], shap_data['Run 1 - Attack 1'], 'Run 1 - SHAP: Attack 1', colors)
plot_bar(axs[1, 2], shap_data['Run 2 - No Attack'], 'Run 2 - SHAP: No Attack', colors)
plot_bar(axs[1, 3], shap_data['Run 2 - Attack 1'], 'Run 2 - SHAP: Attack 1', colors)
plot_bar(axs[2, 2], shap_data['Run 3 - No Attack'], 'Run 3 - SHAP: No Attack', colors)
plot_bar(axs[2, 3], shap_data['Run 3 - Attack 1'], 'Run 3 - SHAP: Attack 1', colors)
plot_bar(axs[3, 2], shap_data['Run 4 - No Attack'], 'Run 4 - SHAP: No Attack', colors)
plot_bar(axs[3, 3], shap_data['Run 4 - Attack 1'], 'Run 4 - SHAP: Attack 1', colors)
plot_bar(axs[4, 2], shap_data['Run 5 - No Attack'], 'Run 5 - SHAP: No Attack', colors)
plot_bar(axs[4, 3], shap_data['Run 5 - Attack 1'], 'Run 5 - SHAP: Attack 1', colors)

# Adding the legend below the plot, centered and larger
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.05), fontsize=12)

plt.tight_layout()

# Save the plot as a PNG file
output_path = "all_runs_lime_shap_German_comparison.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()



