import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Data for the heatmap: rankings for 'race' (ranks from 1 to 10)
scenarios = ['LIME: Attack 1', 'LIME: Attack 2', 'SHAP: Attack 1', 'SHAP: Attack 2']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Example rankings (1-10) for race feature in each scenario and run
# Replace these with your actual data
lime_attack1 = [2, 2, 2, 2, 2]  # Example data for LIME Attack 1
lime_attack2 = [1, 1, 1, 1, 1]  # Example data for LIME Attack 2
shap_attack1 = [3, 3, 3, 3, 3]  # Example data for SHAP Attack 1
shap_attack2 = [1, 2, 2, 1, 1]  # Example data for SHAP Attack 2

# Combine data into a numpy array
data = np.array([lime_attack1, lime_attack2, shap_attack1, shap_attack2])

# Define a custom color map that goes from green (rank 1) to red (rank 10)
cmap = sns.color_palette("RdYlGn_r", 10)  # Reverse the RdYlGn to have green at rank 1 and red at rank 10

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=True, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of Race'}, linewidths=0.5, vmin=1, vmax=10)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs)
ax.set_yticklabels(scenarios)
ax.set_title('Race Feature Ranking (1 to 10) Across Runs for LIME and SHAP Defenses')
ax.set_xlabel('Runs')
ax.set_ylabel('Scenarios')

# Display the heatmap
plt.tight_layout()
plt.show()
