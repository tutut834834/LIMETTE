import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Updated scenarios and runs labels as per user request
scenarios = ['LIME: Attack-Defense 1', 'LIME: Attack-Defense 2', 'SHAP: Attack-Defense 1', 'SHAP: Attack-Defense 2']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Precise rankings for "racePctWhite" feature based on the provided data
lime_attack1 = [None, None, None, 2, 2]  # LIME Attack 1: "racePctWhite" only appears in runs 4 and 5
lime_attack2 = [None, 1, 1, 2, 1]        # LIME Attack 2: "racePctWhite" appears in runs 2, 3, 4, and 5
shap_attack1 = [2, 1, 1, 2, 2]           # SHAP Attack 1: "racePctWhite" appears in all runs
shap_attack2 = [1, 1, 1, 2, 1]           # SHAP Attack 2: "racePctWhite" appears in all runs

# Corresponding feature importance values (in percentages)
importance_values = [
    [("No Rank",), ("No Rank",), ("No Rank",), ("Rank 2", "racePctWhite: 3.5%"), ("Rank 2", "racePctWhite: 2.5%")],  # LIME Attack 1
    [("No Rank",), ("Rank 1", "racePctWhite: 3.5%"), ("Rank 1", "racePctWhite: 3.5%"), ("Rank 2", "racePctWhite: 3.5%"), ("Rank 1", "racePctWhite: 2.5%")],  # LIME Attack 2
    [("Rank 2", "racePctWhite: 7.5%"), ("Rank 1", "racePctWhite: 7.5%"), ("Rank 1", "racePctWhite: 7.5%"), ("Rank 2", "racePctWhite: 6%"), ("Rank 2", "racePctWhite: 6.5%")],  # SHAP Attack 1
    [("Rank 1", "racePctWhite: 10.5%"), ("Rank 1", "racePctWhite: 7.5%"), ("Rank 1", "racePctWhite: 7.5%"), ("Rank 2", "racePctWhite: 6%"), ("Rank 1", "racePctWhite: 10%")]  # SHAP Attack 2
]

# Combine data into a numpy array for plotting
data = np.array([
    [2 if r == 2 else (1 if r == 1 else 5) for r in lime_attack1],  # Map None to 5 (indicating not ranked in the top 3)
    [2 if r == 2 else (1 if r == 1 else 5) for r in lime_attack2],
    [2 if r == 2 else (1 if r == 1 else 5) for r in shap_attack1],
    [2 if r == 2 else (1 if r == 1 else 5) for r in shap_attack2]
])

# Define a custom color map that goes from green (rank 1) to red (rank 5)
cmap = sns.color_palette("RdYlGn_r", 5)

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=False, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of racePctWhite'}, linewidths=0.5, vmin=1, vmax=5)

# Add detailed text (rank and importance values) in each cell
for i in range(data.shape[0]):
    for j in range(data.shape[1]):
        text = '\n'.join(importance_values[i][j])
        ax.text(j + 0.5, i + 0.5, text, ha='center', va='center', color='black', fontsize=8)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs, fontsize=12)  # Adjust font size for readability
ax.set_yticklabels(scenarios, fontsize=12, rotation=0)  # Rotate the labels to horizontal

# Adjust the layout to prevent overlap
ax.set_title('racePctWhite Feature Ranking Across Runs for LIME and SHAP Attack-Defense', fontsize=14)
ax.set_xlabel('Runs', fontsize=12)
ax.set_ylabel('Scenarios', fontsize=12)

# Display the heatmap
plt.tight_layout()
plt.show()
