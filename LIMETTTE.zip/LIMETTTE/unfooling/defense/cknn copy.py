import numpy as np
from sklearn.base import OutlierMixin, BaseEstimator
from sklearn.neighbors import KNeighborsClassifier, KernelDensity, NearestNeighbors
from statsmodels.tsa.arima.model import ARIMA
from arch import arch_model
import pandas as pd

class KNNCAD(OutlierMixin, BaseEstimator):
    def __init__(
            self,
            approach='distance',
            distance_agg='median',
            epsilon=0.05,
            n_neighbors=20,
            weights='distance',
            algorithm='auto',
            distance_penalize_accurate=True,
            leaf_size=None,
            p=2,
            metric=None,
            metric_params=None,
            n_jobs=-1,
            bandwidth=1.0,
            atol=0,
            rtol=0,
            breadth_first=True,
            radius=1.0,
            arima_order=(5, 1, 0),
            garch_p=1,
            garch_q=1,
            lipschitz_constant=1.0,
            gamma=0.01
    ):
        # Convert the string to an actual function
        self.distance_agg = self._get_agg_function(distance_agg)
        
        # Initialize the base estimator
        if approach == 'clf':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = KNeighborsClassifier(
                n_neighbors=n_neighbors,
                weights=weights,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                n_jobs=n_jobs,
            )
        elif approach == 'distance':
            metric = metric or 'minkowski'
            leaf_size = leaf_size or 30
            self._estimator = NearestNeighbors(
                n_neighbors=n_neighbors,
                algorithm=algorithm,
                leaf_size=leaf_size,
                p=p,
                metric=metric,
                metric_params=metric_params,
                radius=radius,
                n_jobs=n_jobs,
            )
        elif approach == 'density':
            metric = metric or 'euclidean'
            leaf_size = leaf_size or 40
            self._estimator = KernelDensity(
                bandwidth=bandwidth,
                algorithm=algorithm,
                leaf_size=leaf_size,
                metric=metric,
                metric_params=metric_params,
                atol=atol,
                rtol=rtol,
                breadth_first=breadth_first,
            )
        else:
            raise ValueError(f"Unknown approach: {approach}")

        self.approach = approach
        self.epsilon = epsilon
        self.distance_penalize_accurate = distance_penalize_accurate
        self.arima_order = arima_order
        self.garch_p = garch_p
        self.garch_q = garch_q
        self.lipschitz_constant = lipschitz_constant
        self.gamma = gamma
        self.threshold_ = None
        self.arima_model_ = None
        self.garch_model_ = None

    def _get_agg_function(self, agg):
        """Convert a string aggregation function name to an actual numpy function."""
        if isinstance(agg, str):
            if agg in ['mean', 'median', 'max', 'min', 'sum']:
                return getattr(np, agg)
            else:
                raise ValueError(f"Unknown aggregation function: {agg}")
        return agg

    def fit(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        self.X_train, self.y_train = X, y
        self._estimator.fit(X, y)

        # Fit ARIMA model on the output (y) to capture temporal dependencies
        self.arima_model_ = ARIMA(y, order=self.arima_order).fit()

        # Fit GARCH model on the residuals of ARIMA to capture volatility clustering
        residuals = self.arima_model_.resid
        self.garch_model_ = arch_model(residuals, p=self.garch_p, q=self.garch_q).fit(disp="off")

        # Determine threshold using KNN-based scoring
        scores = self.score_samples(X, y)
        scores.sort()

        thresh_idx = round(self.epsilon * len(X))
        self.threshold_ = scores[thresh_idx]

        return self

    def predict(self, X, y):
        scores = self.score_samples(X, y)
        preds = np.ones_like(scores, dtype=int)
        preds[scores < self.threshold_] = -1
        return preds

    def score_samples(self, X, y):
        if y.ndim == 2:
            y = y.squeeze(axis=1)
        assert y.ndim == 1, y.ndim

        if self.approach == 'clf':
            probas = self._estimator.predict_proba(X)
            scores = probas[np.arange(len(y)), y]
        elif self.approach == 'distance':
            dists, idxs = self._estimator.kneighbors(X)
            scores = self.calculate_distance_scores(dists, idxs, y)
        elif self.approach == 'density':
            scores = self._estimator.score_samples(X)
        else:
            raise RuntimeError(self.approach)

        # Integrate ARIMA model predictions
        arima_pred = self.arima_model_.predict(start=0, end=len(y) - 1)

        # Integrate GARCH model predictions
        garch_pred = self.garch_model_.conditional_volatility[:len(y)]  # Adjusting to match length of y

        # Reshape garch_pred to match arima_pred if necessary
        if garch_pred.shape[0] != arima_pred.shape[0]:
            garch_pred = np.resize(garch_pred, arima_pred.shape)

        # Calculate Lipschitz adjustment
        lipschitz_adjustment = self.calculate_lipschitz_adjustment(arima_pred, garch_pred)

        # Combine predictions with scores
        scores += arima_pred + garch_pred + lipschitz_adjustment

        return scores

    def calculate_lipschitz_adjustment(self, arima_pred, garch_pred):
        """
        Adjust the Lipschitz constant based on the difference between the ARIMA and GARCH predictions.
        """
        adjustment = self.gamma * np.abs(garch_pred - arima_pred)
        self.lipschitz_constant += adjustment.mean()
        return self.lipschitz_constant * adjustment

    def calculate_distance_scores(self, dists, idxs, y):
        scores = []
        for dist, idx, yi in zip(dists, idxs, y):
            yi = int(yi)
            assert yi in {0, 1}, yi

            pop_yi = self.y_train[idx]
            dist_0 = self.calculate_aggregate_distance(dist, pop_yi, 0)
            dist_1 = self.calculate_aggregate_distance(dist, pop_yi, 1)

            if yi == 1:
                dist_yi, dist_other = dist_1, dist_0
            else:
                dist_yi, dist_other = dist_0, dist_1

            score = self.calculate_score(dist_yi, dist_other)
            scores.append(score)
        return np.asarray(scores)

    def calculate_aggregate_distance(self, dist, pop_yi, class_label):
        where_class = np.where(pop_yi == class_label)
        dists_class = dist[where_class]
        if dists_class.size:
            return self.distance_agg(dists_class)
        else:
            return np.inf

    def calculate_score(self, dist_yi, dist_other):
        if not self.distance_penalize_accurate and dist_yi < dist_other:
            return 1.0
        else:
            if dist_yi == dist_other == 0:
                return 1.0
            else:
                with np.errstate(divide='ignore'):
                    return 1 / (1 + dist_yi / dist_other)

    #### Training with Adversarial Attack Data ####
    def train_with_adversarial_data(self, csv_file):
        """Train the model using adversarial data from a CSV file."""
        # Load the adversarial data
        df = pd.read_csv(csv_file)
        
        # Assuming features are in the 'Feature' column and labels are based on success rate
        features = df['Feature'].values.reshape(-1, 1)  # Reshape as needed
        labels = (df['SuccessRate'] > 0.5).astype(int)  # Example threshold
        
        # Fit the model on this data
        self.fit(features, labels)
        
        print("Model trained with adversarial attack data.")
        return self
    #### End of Training with Adversarial Attack Data ####
