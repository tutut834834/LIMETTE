# Saving the plot as a PNG file

import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Exact data for Defense and Attack scenarios
lime_data_defense = {
    'Defense + No Attack': {
        '1st': {'Race': 0.598705501618123, 'Sex Female': 0.059870550161812294},
        '2nd': {'Race': 0.15210355987055016, 'Sex Female': 0.11165048543689321},
        '3rd': {'Sex Female': 0.12135922330097088, 'Uncorrelated #1': 0.11488673139158576},
    },
    'Defense + Attack 1': {
        '1st': {'Uncorrelated #1': 0.48220064724919093, 'Race': 0.1407766990291262},
        '2nd': {'Race': 0.3640776699029126, 'Uncorrelated #1': 0.23786407766990292},
        '3rd': {'Two Year Recid': 0.12459546925566344, 'Charge Degree M': 0.11974110032362459},
    },
    'Defense + Attack 2': {
        '1st': {'Race': 0.5663430420711975, 'Sex Female': 0.061488673139158574},
        '2nd': {'Race': 0.17475728155339806, 'Uncorrelated #2': 0.11326860841423948},
        '3rd': {'Charge Degree M': 0.11974110032362459, 'Uncorrelated #1': 0.11165048543689321},
    }
}

shap_data_defense = {
    'Defense + No Attack': {
        '1st': {'Race': 0.48220064724919093, 'Charge Degree F': 0.09870550161812297},
        '2nd': {'Age': 0.11812297734627832, 'Charge Degree M': 0.11650485436893204},
        '3rd': {'Age': 0.11003236245954692, 'Charge Degree F': 0.10679611650485436},
    },
    'Defense + Attack 1': {
        '1st': {'Race': 0.3559870550161812, 'Uncorrelated #1': 0.11165048543689321},
        '2nd': {'Uncorrelated #1': 0.22168284789644013, 'Priors Count': 0.10679611650485436},
        '3rd': {'Priors Count': 0.13106796116504854, 'Charge Degree M': 0.10679611650485436},
    },
    'Defense + Attack 2': {
        '1st': {'Race': 0.45307443365695793, 'Charge Degree F': 0.09223300970873786},
        '2nd': {'Uncorrelated #2': 0.16019417475728157, 'Uncorrelated #1': 0.13106796116504854},
        '3rd': {'Length of Stay': 0.11326860841423948, 'Charge Degree M': 0.10517799352750809},
    }
}

# Colors for features
colors = {
    'Race': '#FF7F0E',
    'Uncorrelated #1': '#1F77B4',
    'Uncorrelated #2': '#AEC7E8',
    'Sex Female': '#FF9896',
    'Sex Male': '#98DF8A',
    'Length of Stay': '#C49C94',
    'Charge Degree M': '#9467BD',
    'Charge Degree F': '#C5B0D5',
    'Two Year Recid': '#8C564B',
    'Priors Count': '#E377C2',
    'Age': '#D62728',
    'Nothing Shown': '#C7C7C7',
}

# Create the plots for LIME and SHAP for Defense scenarios
fig, axs = plt.subplots(2, 3, figsize=(18, 12))

plot_bar(axs[0, 0], lime_data_defense['Defense + No Attack'], 'LIME: Defense + No Attack', colors)
plot_bar(axs[0, 1], lime_data_defense['Defense + Attack 1'], 'LIME: Defense + Attack 1', colors)
plot_bar(axs[0, 2], lime_data_defense['Defense + Attack 2'], 'LIME: Defense + Attack 2', colors)

plot_bar(axs[1, 0], shap_data_defense['Defense + No Attack'], 'SHAP: Defense + No Attack', colors)
plot_bar(axs[1, 1], shap_data_defense['Defense + Attack 1'], 'SHAP: Defense + Attack 1', colors)
plot_bar(axs[1, 2], shap_data_defense['Defense + Attack 2'], 'SHAP: Defense + Attack 2', colors)

# Adding the legend below the plot, centered and larger
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.15), fontsize=12)

plt.tight_layout()

# Save the plot as a PNG file
output_path = "defense_scenarios_plotaaaaaaaaaaaaaaa.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()

output_path
