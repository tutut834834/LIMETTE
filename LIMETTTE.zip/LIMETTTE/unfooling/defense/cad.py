import numpy as np
from scipy.special import logsumexp
from scipy.stats import multivariate_normal
from sklearn.base import OutlierMixin, BaseEstimator
from sklearn.mixture import GaussianMixture
from tqdm import tqdm

class GMMCADFull(OutlierMixin, BaseEstimator):
    def __init__(
            self,
            num_gaussians=10,
            epsilon=0.1,
            max_iters=1000,
            random_state=None,
            patience=None,
            window_size=100,  # For adaptive thresholding
            alpha=1.0,  # Tuning parameter for adaptive thresholding
            beta=0.5,  # Scaling factor for trust-aware adjustment
            **kwargs,
    ):
        self.n_U = self.n_V = num_gaussians
        assert 0 <= epsilon <= 1
        self.epsilon = epsilon
        self.patience = patience
        self.max_iters = max_iters
        self.kwargs = kwargs
        if not isinstance(random_state, np.random.RandomState):
            random_state = np.random.RandomState(random_state)
        self.rs = random_state

        self.d_U = self.d_V = None
        self.p_U = self.log_p_V_U = self.Z = self.U = self.V = None

        self.threshold_ = None

        # Adaptive thresholding attributes
        self.recent_scores = []
        self.window_size = window_size
        self.alpha = alpha
        self.beta = beta  # Trust scaling factor
        self.dynamic_threshold = None

    def fit(self, X, y) -> 'GMMCADFull':
        print("### Fitting the GMMCADFull Model ###")
        # Initialization and fitting as previously shown...

        # Example of GMM initialization and fitting process
        gmm = GaussianMixture(n_components=self.n_U, covariance_type='full', max_iter=self.max_iters, random_state=self.rs)
        self.U = gmm.fit(X[y == 1])
        self.V = gmm.fit(X[y == -1])

        # Initialize dynamic threshold with the computed threshold
        self.threshold_ = self.compute_initial_threshold(X, y)
        self.dynamic_threshold = self.threshold_
        print(f"Initial Threshold Set: {self.threshold_}")

        return self

    def compute_initial_threshold(self, X, y):
        # Dummy implementation for threshold computation
        # Replace this with your actual threshold computation logic
        print("### Computing Initial Threshold ###")
        return np.percentile(X, 95)

    def score_samples(self, X, y):
        print("### Scoring Samples ###")
        # Example implementation of scoring
        # Replace this with your actual scoring logic
        f_CAD = np.zeros(X.shape[0])  # Placeholder score computation
        return f_CAD

    def predict(self, X, y, trust_scores=None, ret_scores=False):
        print("### Prediction Process Started ###")
        scores = self.score_samples(X, y)

        # Update the dynamic threshold with the new scores
        self.update_dynamic_threshold(scores, trust_scores)

        # Use the trust-aware dynamic threshold for prediction
        preds = np.ones(len(X))
        preds[scores < self.dynamic_threshold] = -1
        print(f"Predictions Made: {preds}")

        if ret_scores:
            return preds, scores
        return preds

    def update_dynamic_threshold(self, new_scores, trust_scores=None):
        print("########## Dynamic Threshold Update Triggered ##########")
        print(f"New Scores: {new_scores}")
        print(f"Current Dynamic Threshold: {self.dynamic_threshold}")
        print("########################################################")

        # Update recent scores
        self.recent_scores.extend(new_scores)
        if len(self.recent_scores) > self.window_size:
            self.recent_scores = self.recent_scores[-self.window_size:]

        # Calculate mean and variance of recent scores
        if len(self.recent_scores) > 0:
            mean_score = np.mean(self.recent_scores)
            variance_score = np.var(self.recent_scores)
            print(f"Mean Score: {mean_score}, Variance: {variance_score}")

            # Adjust the dynamic threshold
            θ_dyn = mean_score + self.alpha * variance_score
            print(f"New Dynamic Threshold (θ_dyn): {θ_dyn}")

            if trust_scores is not None:
                print("########## Trust Score Adjustment Triggered ##########")
                print(f"Trust Scores: {trust_scores}")
                # Compute the minimum trust score (or use an average/other statistic)
                T = np.min(trust_scores) if len(trust_scores) > 0 else 1.0
                print(f"Minimum Trust Score (T): {T}")
                print("######################################################")
            else:
                T = 1.0  # Assume maximum trust if no trust scores are provided

            # Adjust dynamic threshold with trust-aware component
            self.dynamic_threshold = θ_dyn - (1 - T) * self.beta
            print(f"Adjusted Dynamic Threshold with Trust Score: {self.dynamic_threshold}")
        else:
            # Fallback to initial threshold
            self.dynamic_threshold = self.threshold_
            print(f"Fallback Dynamic Threshold: {self.dynamic_threshold}")

# Example usage:
# model = GMMCADFull()
# model.fit(X_train, y_train)
# predictions = model.predict(X_test, y_test, trust_scores=trust_scores)
