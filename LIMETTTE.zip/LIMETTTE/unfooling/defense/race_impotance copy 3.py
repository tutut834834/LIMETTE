import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Data for the heatmap: exact ranks calculated for "race"
scenarios = ['LIME: Attack 1', 'LIME: Attack 2', 'SHAP: Attack 1', 'SHAP: Attack 2']
runs = ['Run 1', 'Run 2', 'Run 3']

# The precise ranks of race from the calculations
lime_attack1 = [2, 2, 2]  # Race is ranked 2nd in LIME Attack 1 in all three runs
lime_attack2 = [1, 1, 1]  # Race is ranked 1st in LIME Attack 2 in all three runs
shap_attack1 = [1, 1, 1]  # Race is ranked 1st in SHAP Attack 1 in all three runs
shap_attack2 = [1, 1, 1]  # Race is ranked 1st in SHAP Attack 2 in all three runs

# Combine data for each scenario
data = np.array([lime_attack1, lime_attack2, shap_attack1, shap_attack2])

# Create a heatmap color mapping with 5 levels (1 to 5)
cmap = sns.color_palette("RdYlGn_r", 5)

# Plotting the heatmap
fig, ax = plt.subplots(figsize=(10, 6))

# Create heatmap with custom color mapping
sns.heatmap(data, annot=True, fmt="d", cmap=cmap, cbar_kws={'label': 'Race Rank'}, linewidths=.5, ax=ax, vmin=1, vmax=5)

# Add labels for the axes
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs)
ax.set_yticklabels(scenarios)

# Titles and labels
ax.set_title('Precise Race Importance Rank across Runs for LIME and SHAP Defenses (1 to 5)')
ax.set_xlabel('Runs')
ax.set_ylabel('Scenarios')

# Show the plot
plt.tight_layout()
plt.show()
