import matplotlib.pyplot as plt
import networkx as nx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA

# Attack types and their descriptions
attack_descriptions = {
    "Adversarial Examples": "Small perturbations to input data that lead the model to produce different explanations. Pros: Reveal fragility of model explanations. Cons: Require precise knowledge of the model and can be computationally expensive.",
    "Data Poisoning (Biased Sampling)": "Manipulating training data via biased sampling. Pros: Introduce biases subtly. Cons: Requires access to training pipeline and may not generalize well.",
    "Data Poisoning (In Training)": "Manipulating training data during the training process. Pros: Subtly alters model outputs. Cons: Requires access to training pipeline.",
    "Backdoor Attack (Fooling)": "Manipulates model and data to embed hidden triggers. Pros: Remain undetected until triggered. Cons: Requires significant pre-planning and access to model and data.",
    "Backdoor Attack (Red-Herring)": "Embeds misleading triggers that cause specific outputs when triggered. Pros: Stealthy and undetected until triggered. Cons: Difficult to maintain across inputs.",
    "Backdoor Attack (Full Disguise)": "Fully disguises the attack by making both explanations and outputs deceptive. Pros: Remains stealthy. Cons: Complex to implement.",
    "Model Manipulation": "Fine-tuning model parameters to change explanations without altering predictions. Pros: Craft explanations that seem legitimate. Cons: Requires extensive knowledge of the model.",
    "Adversarial Models (Local Explanation)": "Designs models to produce different local explanations. Pros: Undermine trust in model outputs. Cons: Requires sophisticated knowledge of the model.",
    "Adversarial Models (Fairness Metric)": "Alters models to affect fairness metrics. Pros: Target specific explanation methods. Cons: Complex to execute.",
    "Trust Manipulation": "Alters explanation models rather than predictive models to deceive users. Pros: Can deceive users into trusting the model. Cons: Requires intricate understanding of explanations."
}

# References for each attack type
attack_references = {
    "Adversarial Examples": [38, 39, 40, 41],
    "Data Poisoning (Biased Sampling)": [19, 20, 21, 96, 97],
    "Data Poisoning (In Training)": [98, 99, 100],
    "Backdoor Attack (Fooling)": [18, 26, 27],
    "Backdoor Attack (Red-Herring)": [27],
    "Backdoor Attack (Full Disguise)": [27],
    "Model Manipulation": [22, 23, 24, 101],
    "Adversarial Models (Local Explanation)": [25, 102],
    "Adversarial Models (Fairness Metric)": [103, 104],
    "Trust Manipulation": [35]
}

# Combine descriptions and references into a single string for vectorization
attack_texts = ["{} References: {}".format(attack_descriptions[k], ", ".join(map(str, v))) for k, v in attack_references.items()]

# Vectorize the text
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(attack_texts)

# Apply clustering (KMeans)
kmeans = KMeans(n_clusters=3, random_state=0)
clusters = kmeans.fit_predict(X)

# Apply PCA for 2D visualization
pca = PCA(n_components=2)
components = pca.fit_transform(X.toarray())

# Create a NetworkX graph
G = nx.Graph()

# Add nodes with cluster as attribute
for i, attack in enumerate(attack_descriptions.keys()):
    G.add_node(attack, cluster=clusters[i])

# Add edges between attacks in the same cluster
for i, attack1 in enumerate(attack_descriptions.keys()):
    for j, attack2 in enumerate(attack_descriptions.keys()):
        if i != j and clusters[i] == clusters[j]:
            G.add_edge(attack1, attack2)

# Define colors for each cluster
colors = [plt.cm.tab10(clusters[i]) for i in range(len(clusters))]

# Plotting the graph
plt.figure(figsize=(10, 10))
pos = {attack: components[i] for i, attack in enumerate(attack_descriptions.keys())}
nx.draw(G, pos, with_labels=True, node_color=colors, node_size=5000, font_size=10, font_color='white', font_weight='bold', edge_color='gray')

plt.title("Clustering of Attack Types Based on Descriptions and References")
plt.show()
