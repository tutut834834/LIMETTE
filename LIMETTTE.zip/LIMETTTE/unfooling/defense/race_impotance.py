import matplotlib.pyplot as plt
import numpy as np

# Data for the graph
scenarios = ['LIME: Attack 1', 'LIME: Attack 2', 'SHAP: Attack 1', 'SHAP: Attack 2']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# 1 indicates race remains the most important, 0 indicates it doesn't
lime_attack1 = [0, 0, 0, 0, 0]
lime_attack2 = [1, 1, 1, 1, 1]
shap_attack1 = [0, 0, 0, 0, 0]
shap_attack2 = [1, 0, 0, 1, 1]

# Combine data for each scenario
data = np.array([lime_attack1, lime_attack2, shap_attack1, shap_attack2])

# Plotting the graph
fig, ax = plt.subplots(figsize=(10, 6))

# Heatmap for visualizing the success of each defense in retaining race as the top feature
cax = ax.imshow(data, cmap='Greens', aspect='auto')

# Adding labels for runs and scenarios
ax.set_xticks(np.arange(len(runs)))
ax.set_yticks(np.arange(len(scenarios)))
ax.set_xticklabels(runs)
ax.set_yticklabels(scenarios)

# Adding color bar to indicate the range (0: Not 1st, 1: 1st)
cbar = ax.figure.colorbar(cax, ax=ax)
cbar.set_label('Race Importance (1: Retained, 0: Not Retained)')

# Adding text to each cell
for i in range(len(scenarios)):
    for j in range(len(runs)):
        ax.text(j, i, data[i, j], ha='center', va='center', color='black')

# Titles and labels
ax.set_title('Race Importance Retention across Runs for LIME and SHAP Defenses')
ax.set_xlabel('Runs')
ax.set_ylabel('Scenarios')

plt.tight_layout()
plt.show()
