import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Scenarios and runs labels
scenarios = ['LIME: Attack-Defense 1', 'LIME: Attack-Defense 2', 'SHAP: Attack-Defense 1', 'SHAP: Attack-Defense 2']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Actual ranks for the "sex_male" feature based on the provided data (0 when not in the top ranks)
lime_attack1 = [1, 1, 0, 0, 0]  # Ranks for LIME Attack-Defense 1
lime_attack2 = [1, 0, 0, 0, 0]  # Ranks for LIME Attack-Defense 2
shap_attack1 = [1, 2, 3, 0, 0]  # Ranks for SHAP Attack-Defense 1
shap_attack2 = [2, 3, 3, 0, 0]  # Ranks for SHAP Attack-Defense 2

# Feature importance percentages (actual values), example for cell content when "sex_male" is absent
importance_values = [
    [("sex_male: 1.0"), ("sex_male: 1.0"), ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12"),   
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12"), ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12")],  

    [("sex_male: 1.0"), ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12"),
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12"),
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12"),
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12")],

    [("sex_male: 1.0"), ("sex_male: 0.52"), ("sex_male: 0.48"),  
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12"),
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12")],

    [("sex_male: 0.52"), ("sex_male: 0.48"), ("sex_male: 0.47"),  
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12"),
     ("education_HS-grad: 0.13", "hours-per-week: 0.12", "education_Masters: 0.12")]
]

# Combine data into a numpy array for plotting
data = np.array([lime_attack1, lime_attack2, shap_attack1, shap_attack2])

# Define a custom color map that goes from green (rank 1) to red (rank 5)
cmap = sns.color_palette("RdYlGn_r", 5)  # Rank 1 (green) to 5 (red)

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=False, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of sex_male'}, linewidths=0.5, vmin=0, vmax=5)

# Add detailed text (rank and importance values) in each cell
for i in range(data.shape[0]):
    for j in range(data.shape[1]):
        text = '\n'.join(importance_values[i][j]) if isinstance(importance_values[i][j], tuple) else importance_values[i][j]
        ax.text(j + 0.5, i + 0.5, text, ha='center', va='center', color='black', fontsize=8)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs, fontsize=12)  # Adjust font size for readability
ax.set_yticklabels(scenarios, fontsize=12, rotation=0)  # Rotate the labels to horizontal

# Adjust the layout to prevent overlap
ax.set_title('sex_male Feature Ranking Across Runs for LIME and SHAP Attack-Defense Scenarios', fontsize=14)
ax.set_xlabel('Runs', fontsize=12)
ax.set_ylabel('Scenarios', fontsize=12)

# Display the heatmap
plt.tight_layout()
plt.show()
