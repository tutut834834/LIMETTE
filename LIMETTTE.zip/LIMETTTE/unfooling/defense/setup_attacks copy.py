import foolbox as fb  # Ensure foolbox is imported
import torch
from torchvision import models, transforms
import matplotlib
matplotlib.use('Agg')  # Set the backend to 'Agg' for script-based usage
import matplotlib.pyplot as plt
import numpy as np

# Check for GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load model and data
model = models.resnet18(weights='DEFAULT').eval().to(device)  # Move model to the same device
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Create synthetic image data
synthetic_image = torch.rand((1, 3, 224, 224)).to(device)  # Move input to the same device
label = torch.tensor([1]).to(device)  # Move label to the same device

# Convert tensor to NumPy array for plotting
image_np = synthetic_image.squeeze(0).permute(1, 2, 0).cpu().numpy()  # Move back to CPU for plotting

# Plot synthetic image
plt.imshow(image_np)
plt.title('Synthetic Image')
plt.axis('off')  # Hide axis
plt.savefig('synthetic_image.png')  # Save the plot as a PNG file
print("Synthetic image saved as 'synthetic_image.png'.")

# Attack
attack = fb.attacks.FGSM()
adversarial = attack(fmodel, synthetic_image, label, epsilons=[0.03])

print("Foolbox attack complete.")
