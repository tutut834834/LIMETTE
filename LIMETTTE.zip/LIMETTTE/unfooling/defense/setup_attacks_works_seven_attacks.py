import foolbox as fb  # Ensure foolbox is imported
import torch
from torchvision import models, transforms
import matplotlib
matplotlib.use('Agg')  # Set the backend to 'Agg' for script-based usage
import matplotlib.pyplot as plt
import numpy as np

# Check for GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load model and data
model = models.resnet18(weights='DEFAULT').eval().to(device)  # Move model to the same device
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Create synthetic image data
synthetic_image = torch.rand((1, 3, 224, 224)).to(device)  # Move input to the same device
label = torch.tensor([1]).to(device)  # Move label to the same device

# Convert tensor to NumPy array for plotting
image_np = synthetic_image.squeeze(0).permute(1, 2, 0).cpu().numpy()  # Move back to CPU for plotting

# Plot synthetic image
plt.figure()
plt.imshow(image_np)
plt.title('Synthetic Image')
plt.axis('off')  # Hide axis
plt.savefig('synthetic_image.png')  # Save the plot as a PNG file
print("Synthetic image saved as 'synthetic_image.png'.")

# Define epsilon values for the attack
epsilons = [0.01, 0.03, 0.05, 0.07, 0.1, 0.15]  # Added epsilon = 0.15

# Initialize a dictionary to store results for each attack
results = {
    'FGSM': {
        'success_rates': [],
        'perturbation_magnitudes': [],
        'model_confidences': []
    },
    'BIM': {
        'success_rates': [],
        'perturbation_magnitudes': [],
        'model_confidences': []
    },
    'PGD': {
        'success_rates': [],
        'perturbation_magnitudes': [],
        'model_confidences': []
    },
    'L2PGD': {
        'success_rates': [],
        'perturbation_magnitudes': [],
        'model_confidences': []
    },
    'DeepFool': {
        'success_rates': [],
        'perturbation_magnitudes': [],
        'model_confidences': []
    },
    'Spatial': {
        'success_rates': [],
        'perturbation_magnitudes': [],
        'model_confidences': []
    },
    'LinfFastGradientMethod': {  # New attack
        'success_rates': [],
        'perturbation_magnitudes': [],
        'model_confidences': []
    }
}

# List of attacks to perform
attacks = {
    'FGSM': fb.attacks.FGSM(),
    'BIM': fb.attacks.LinfBasicIterativeAttack(),
    'PGD': fb.attacks.PGD(),
    'L2PGD': fb.attacks.L2PGD(),
    'DeepFool': fb.attacks.L2DeepFoolAttack(),
    'Spatial': fb.attacks.SpatialAttack(),
    'LinfFastGradientMethod': fb.attacks.FGSM()  # Added Linf Fast Gradient Method
}

# Total number of operations (attacks * epsilons)
total_operations = len(attacks) * len(epsilons)
completed_operations = 0

# Perform the attacks
for attack_name, attack in attacks.items():
    print(f"Running {attack_name} attack...")
    
    for epsilon in epsilons:
        adversarial = attack(fmodel, synthetic_image, label, epsilons=[epsilon])
        
        # Extract the adversarial image tensor and ensure it is 4D
        adversarial_image = adversarial[0][0]
        
        if adversarial_image.dim() == 3:
            adversarial_image = adversarial_image.unsqueeze(0)  # Add a batch dimension
        
        # Ensure the adversarial_image tensor is on the correct device
        adversarial_image = adversarial_image.to(device)
        
        # Calculate the success rate
        with torch.no_grad():
            logits = model(adversarial_image)
            predicted_class = torch.argmax(logits, dim=1)
            success_rate = (predicted_class != label).float().mean().item()
            results[attack_name]['success_rates'].append(success_rate)
        
        # Calculate the perturbation magnitude
        perturbation = adversarial_image - synthetic_image
        perturbation_magnitude = perturbation.norm().item()
        results[attack_name]['perturbation_magnitudes'].append(perturbation_magnitude)
        
        # Calculate model confidence
        model_confidence = torch.max(torch.softmax(logits, dim=1)).item()
        results[attack_name]['model_confidences'].append(model_confidence)
        
        # Update progress
        completed_operations += 1
        progress = (completed_operations / total_operations) * 100
        print(f"Progress: {progress:.2f}%")

# Plot success rates for each attack
plt.figure()
for attack_name in results:
    plt.plot(epsilons, results[attack_name]['success_rates'], marker='o', linestyle='-', label=attack_name)
plt.xlabel('Epsilon')
plt.ylabel('Success Rate')
plt.title('Attack Success Rate vs. Epsilon')
plt.grid(True)
plt.legend()
plt.savefig('ensemble_attack_success_rate.png')
print("Ensemble attack success rate plot saved as 'ensemble_attack_success_rate.png'.")

# Plot perturbation magnitudes for each attack
plt.figure()
for attack_name in results:
    plt.plot(epsilons, results[attack_name]['perturbation_magnitudes'], marker='o', linestyle='-', label=attack_name)
plt.xlabel('Epsilon')
plt.ylabel('Perturbation Magnitude')
plt.title('Perturbation Magnitude vs. Epsilon')
plt.grid(True)
plt.legend()
plt.savefig('ensemble_perturbation_magnitude.png')
print("Ensemble perturbation magnitude plot saved as 'ensemble_perturbation_magnitude.png'.")

# Plot model confidences for each attack
plt.figure()
for attack_name in results:
    plt.plot(epsilons, results[attack_name]['model_confidences'], marker='o', linestyle='-', label=attack_name)
plt.xlabel('Epsilon')
plt.ylabel('Model Confidence')
plt.title('Model Confidence vs. Epsilon')
plt.grid(True)
plt.legend()
plt.savefig('ensemble_model_confidence.png')
print("Ensemble model confidence plot saved as 'ensemble_model_confidence.png'.")

print("Foolbox ensemble attacks complete.")
