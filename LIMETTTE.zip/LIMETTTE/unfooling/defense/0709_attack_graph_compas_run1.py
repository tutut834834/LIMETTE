import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Updated data for LIME and SHAP based on the new provided information
lime_data = {
    'No Attack': {
        '1st': {'race': 0.9919, 'length_of_stay': 0.0081},
        '2nd': {'sex_Female': 0.1812, 'sex_Male': 0.1731, 'c_charge_degree_M': 0.1327, 
                'unrelated_column_two': 0.1294, 'two_year_recid': 0.1214},
        '3rd': {'sex_Female': 0.1634, 'unrelated_column_two': 0.1456, 'c_charge_degree_F': 0.1262, 
                'unrelated_column_one': 0.1262, 'two_year_recid': 0.1197},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.9919, 'length_of_stay': 0.0081},
        '2nd': {'sex_Male': 0.1586, 'c_charge_degree_M': 0.1521, 'sex_Female': 0.1489, 
                'unrelated_column_two': 0.1408, 'c_charge_degree_F': 0.1294},
        '3rd': {'two_year_recid': 0.1505, 'c_charge_degree_F': 0.1440, 'sex_Female': 0.1375, 
                'sex_Male': 0.1375, 'c_charge_degree_M': 0.1230},
    },
    'Attack 2': {
        '1st': {'sex_Female': 0.1683, 'sex_Male': 0.1505, 'c_charge_degree_M': 0.1343, 
                'unrelated_column_one': 0.1165, 'unrelated_column_two': 0.1165},
        '2nd': {'sex_Female': 0.1311, 'unrelated_column_two': 0.1262, 'sex_Male': 0.1197, 
                'unrelated_column_one': 0.1197, 'c_charge_degree_F': 0.1181},
        '3rd': {'c_charge_degree_M': 0.1278, 'c_charge_degree_F': 0.1197, 'unrelated_column_two': 0.1165, 
                'race': 0.1133, 'two_year_recid': 0.1133},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.5679, 'race': 0.0728, 'sex_Female': 0.0728, 
                'two_year_recid': 0.0437, 'length_of_stay': 0.0421},
        '2nd': {'race': 0.3511, 'unrelated_column_one': 0.1893, 'sex_Female': 0.0761, 
                'c_charge_degree_M': 0.0712, 'two_year_recid': 0.0680},
        '3rd': {'sex_Female': 0.1149, 'c_charge_degree_M': 0.1133, 'c_charge_degree_F': 0.1052, 
                'age': 0.0987, 'unrelated_column_two': 0.0890},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.4676, 'unrelated_column_one': 0.0761, 'c_charge_degree_M': 0.0615, 
                'unrelated_column_two': 0.0599, 'sex_Female': 0.0566},
        '2nd': {'race': 0.1699, 'c_charge_degree_M': 0.1019, 'priors_count': 0.0987, 
                'unrelated_column_one': 0.0971, 'sex_Female': 0.0955},
        '3rd': {'sex_Female': 0.1165, 'unrelated_column_two': 0.1133, 'unrelated_column_one': 0.1100, 
                'two_year_recid': 0.1003, 'c_charge_degree_M': 0.0955},
    }
}

shap_data = {
    'No Attack': {
        '1st': {'race': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.4871, 'race': 0.2799, 'length_of_stay': 0.1392, 
                'age': 0.0194, 'c_charge_degree_F': 0.0194},
        '2nd': {'race': 0.2945, 'unrelated_column_one': 0.2751, 'length_of_stay': 0.1133, 
                'age': 0.0744, 'c_charge_degree_F': 0.0534},
        '3rd': {'length_of_stay': 0.2346, 'age': 0.1392, 'c_charge_degree_F': 0.1036, 
                'priors_count': 0.0922, 'c_charge_degree_M': 0.0906},
    },
    'Attack 2': {
        '1st': {'race': 0.4061, 'length_of_stay': 0.1909, 'unrelated_column_one': 0.1472, 
                'unrelated_column_two': 0.1133, 'age': 0.0469},
        '2nd': {'unrelated_column_one': 0.2071, 'unrelated_column_two': 0.2006, 'race': 0.1440, 
                'length_of_stay': 0.1392, 'priors_count': 0.0647},
        '3rd': {'unrelated_column_two': 0.1748, 'unrelated_column_one': 0.1537, 'c_charge_degree_F': 0.0955, 
                'length_of_stay': 0.0955, 'race': 0.0874},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.1861, 'race': 0.1715, 'c_charge_degree_F': 0.1214, 
                'length_of_stay': 0.1133, 'c_charge_degree_M': 0.0712},
        '2nd': {'race': 0.1456, 'length_of_stay': 0.1036, 'c_charge_degree_M': 0.1003, 
                'priors_count': 0.0987, 'unrelated_column_one': 0.0987},
        '3rd': {'length_of_stay': 0.1214, 'sex_Female': 0.1003, 'two_year_recid': 0.0955, 
                'unrelated_column_two': 0.0955, 'c_charge_degree_F': 0.0922},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.2346, 'length_of_stay': 0.1068, 'two_year_recid': 0.0955, 
                'unrelated_column_one': 0.0955, 'unrelated_column_two': 0.0809},
        '2nd': {'length_of_stay': 0.1246, 'priors_count': 0.1181, 'c_charge_degree_F': 0.0971, 
                'c_charge_degree_M': 0.0874, 'sex_Female': 0.0858},
        '3rd': {'c_charge_degree_F': 0.1197, 'c_charge_degree_M': 0.1036, 'sex_Female': 0.0955, 
                'age': 0.0906, 'length_of_stay': 0.0906},
    }
}

# Completing the
# Completing the color mapping and ensuring plot generation.

colors = {
    'race': '#FF7F0E',
    'unrelated_column_one': '#1F77B4',
    'unrelated_column_two': '#AEC7E8',
    'sex_Female': '#FF9896',
    'sex_Male': '#98DF8A',
    'length_of_stay': '#C49C94',
    'c_charge_degree_M': '#9467BD',
    'c_charge_degree_F': '#C5B0D5',
    'two_year_recid': '#8C564B',
    'priors_count': '#E377C2',
    'age': '#D62728',
    'Nothing shown': '#C7C7C7',
}

# Creating the plot for LIME and SHAP comparisons
fig, axs = plt.subplots(2, 5, figsize=(18, 10))

# Plotting LIME scenarios
plot_bar(axs[0, 0], lime_data['No Attack'], 'LIME: No Attack', colors)
plot_bar(axs[0, 1], lime_data['Attack 1'], 'LIME: Attack 1', colors)
plot_bar(axs[0, 2], lime_data['Attack 2'], 'LIME: Attack 2', colors)
plot_bar(axs[0, 3], lime_data['Defense + Attack 1'], 'LIME: Defense + Attack 1', colors)
plot_bar(axs[0, 4], lime_data['Defense + Attack 2'], 'LIME: Defense + Attack 2', colors)

# Plotting SHAP scenarios
plot_bar(axs[1, 0], shap_data['No Attack'], 'SHAP: No Attack', colors)
plot_bar(axs[1, 1], shap_data['Attack 1'], 'SHAP: Attack 1', colors)
plot_bar(axs[1, 2], shap_data['Attack 2'], 'SHAP: Attack 2', colors)
plot_bar(axs[1, 3], shap_data['Defense + Attack 1'], 'SHAP: Defense + Attack 1', colors)
plot_bar(axs[1, 4], shap_data['Defense + Attack 2'], 'SHAP: Defense + Attack 2', colors)

# Adding the legend below the plot, centered and larger
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.15), fontsize=12)

# Adjust the layout and save the plot as a PNG file
plt.tight_layout()
output_path = "defense_compas_run1_plot_with_legend.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()

output_path
