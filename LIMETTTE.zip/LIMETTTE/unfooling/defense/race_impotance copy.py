import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Data for the heatmap: rankings for 'race'
scenarios = ['LIME: Attack 1', 'LIME: Attack 2', 'SHAP: Attack 1', 'SHAP: Attack 2']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Race feature rankings for different scenarios and runs
lime_attack1 = [2, 2, 2, 2, 2]  # Race ranked 2nd in all runs
lime_attack2 = [1, 1, 1, 1, 1]  # Race ranked 1st in all runs
shap_attack1 = [3, 3, 3, 3, 3]  # Race ranked 3rd in all runs
shap_attack2 = [1, 2, 2, 1, 1]  # Mixed rankings for race

# Combine data into a numpy array
data = np.array([lime_attack1, lime_attack2, shap_attack1, shap_attack2])

# Define a custom color map to indicate ranking
cmap = sns.color_palette("RdYlGn_r", as_cmap=True)

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=True, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of Race'}, linewidths=0.5)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs)
ax.set_yticklabels(scenarios)
ax.set_title('Race Feature Ranking Across Runs for LIME and SHAP Defenses')
ax.set_xlabel('Runs')
ax.set_ylabel('Scenarios')

# Display the heatmap
plt.tight_layout()
plt.show()
