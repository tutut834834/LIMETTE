import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Scenarios and runs labels for features during attack and defense phases
scenarios = [
    'LIME: Defense after Attack 1', 
    'LIME: Defense after Attack 2', 
    'SHAP: Defense after Attack 1', 
    'SHAP: Defense after Attack 2'
]
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Ranks for features after defense stages based on provided data
lime_defense_attack1 = [3, 3, 3, 2, 3]  # LIME Defense after Attack 1
lime_defense_attack2 = [3, 3, 3, 3, 3]  # LIME Defense after Attack 2
shap_defense_attack1 = [2, 2, 2, 3, 2]  # SHAP Defense after Attack 1
shap_defense_attack2 = [2, 2, 2, 3, 3]  # SHAP Defense after Attack 2

# Combine all data into a numpy array for the heatmap
data = np.array([
    lime_defense_attack1, lime_defense_attack2, 
    shap_defense_attack1, shap_defense_attack2
])

# Feature importance percentages to annotate in heatmap
importance_values = [
    [
        ("Rank 3", "Sex_Male: 0.177", "Education_11th: 0.145"), 
        ("Rank 3", "Sex_Male: 0.179", "Occupation: 0.128"), 
        ("Rank 3", "Sex_Male: 0.188", "Education: 0.145"),
        ("Rank 2", "Sex_Male: 0.188", "Hours-per-week: 0.114"), 
        ("Rank 3", "Sex_Male: 0.179", "Occupation: 0.140")
    ],
    [
        ("Rank 3", "Sex_Male: 0.284", "Education_11th: 0.165"), 
        ("Rank 3", "Sex_Male: 0.190", "Occupation: 0.159"), 
        ("Rank 3", "Sex_Male: 0.188", "Hours-per-week: 0.143"),
        ("Rank 3", "Sex_Male: 0.188", "Occupation: 0.140"), 
        ("Rank 3", "Sex_Male: 0.179", "Education_11th: 0.110")
    ],
    [
        ("Rank 2", "Sex_Male: 0.521", "Hours-per-week: 0.243"), 
        ("Rank 2", "Sex_Male: 0.523", "Education: 0.200"), 
        ("Rank 2", "Sex_Male: 0.522", "Occupation: 0.150"),
        ("Rank 3", "Sex_Male: 0.522", "Occupation: 0.100"), 
        ("Rank 2", "Sex_Male: 0.523", "Education: 0.215")
    ],
    [
        ("Rank 2", "Sex_Male: 0.177", "Occupation: 0.190"), 
        ("Rank 2", "Sex_Male: 0.190", "Education: 0.215"), 
        ("Rank 2", "Sex_Male: 0.188", "Hours-per-week: 0.155"),
        ("Rank 3", "Sex_Male: 0.188", "Occupation: 0.155"), 
        ("Rank 3", "Sex_Male: 0.177", "Occupation: 0.200")
    ]
]

# Define a custom color map that goes from green (rank 1) to red (rank 3)
cmap = sns.color_palette("RdYlGn_r", 5)  # Rank 1 (green) to 3 (red)

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=False, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of Features'}, linewidths=0.5, vmin=1, vmax=3)

# Add detailed text (rank and importance values) in each cell
for i in range(data.shape[0]):
    for j in range(data.shape[1]):
        text = '\n'.join(importance_values[i][j])
        ax.text(j + 0.5, i + 0.5, text, ha='center', va='center', color='black', fontsize=8)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs, fontsize=12)  # Adjust font size for readability
ax.set_yticklabels(scenarios, fontsize=12, rotation=0)  # Rotate the labels to horizontal

# Adjust the layout to prevent overlap
ax.set_title('Feature Ranking During Defense After Attacks for LIME and SHAP', fontsize=14)
ax.set_xlabel('Runs', fontsize=12)
ax.set_ylabel('Scenarios', fontsize=12)

# Display the heatmap
plt.tight_layout()
plt.show()
