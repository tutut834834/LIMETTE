import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Data for LIME and SHAP based on the provided information
lime_data = {
    'No Attack': {
        '1st': {'race': 0.9903, 'length_of_stay': 0.0081, 'priors_count': 0.0016},
        '2nd': {'sex_Male': 0.1845, 'sex_Female': 0.1748, 'c_charge_degree_M': 0.1521, 
                'unrelated_column_two': 0.1181, 'c_charge_degree_F': 0.1068},
        '3rd': {'unrelated_column_two': 0.1505, 'c_charge_degree_F': 0.1472, 'two_year_recid': 0.1311, 
                'sex_Male': 0.1262, 'unrelated_column_one': 0.1181},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.9919, 'length_of_stay': 0.0081},
        '2nd': {'sex_Male': 0.1667, 'sex_Female': 0.1570, 'race': 0.1440, 
                'c_charge_degree_F': 0.1327, 'unrelated_column_two': 0.1230},
        '3rd': {'c_charge_degree_M': 0.1424, 'c_charge_degree_F': 0.1408, 'sex_Female': 0.1375, 
                'sex_Male': 0.1294, 'race': 0.1262},
    },
    'Attack 2': {
        '1st': {'sex_Female': 0.1715, 'sex_Male': 0.1311, 'unrelated_column_two': 0.1246, 
                'c_charge_degree_F': 0.1084, 'unrelated_column_one': 0.1084},
        '2nd': {'sex_Male': 0.1440, 'two_year_recid': 0.1262, 'c_charge_degree_M': 0.1246, 
                'unrelated_column_one': 0.1117, 'unrelated_column_two': 0.1100},
        '3rd': {'sex_Male': 0.1230, 'sex_Female': 0.1214, 'unrelated_column_two': 0.1197, 
                'two_year_recid': 0.1133, 'c_charge_degree_M': 0.1052},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.5453, 'race': 0.0777, 'sex_Female': 0.0663, 
                'c_charge_degree_M': 0.0534, 'unrelated_column_two': 0.0502},
        '2nd': {'race': 0.3333, 'unrelated_column_one': 0.1828, 'c_charge_degree_M': 0.0793, 
                'sex_Female': 0.0793, 'c_charge_degree_F': 0.0583},
        '3rd': {'sex_Female': 0.1392, 'unrelated_column_two': 0.1117, 'c_charge_degree_M': 0.1084, 
                'age': 0.1036, 'two_year_recid': 0.0922},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.4612, 'length_of_stay': 0.0712, 'unrelated_column_one': 0.0680, 
                'unrelated_column_two': 0.0615, 'priors_count': 0.0566},
        '2nd': {'race': 0.1343, 'c_charge_degree_M': 0.1133, 'unrelated_column_one': 0.1133, 
                'unrelated_column_two': 0.1019, 'sex_Female': 0.0922},
        '3rd': {'sex_Female': 0.1117, 'c_charge_degree_F': 0.1084, 'c_charge_degree_M': 0.1068, 
                'race': 0.1052, 'age': 0.1003},
    }
}

shap_data = {
    'No Attack': {
        '1st': {'race': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0},
    },
    'Attack 1': {
        '1st': {'unrelated_column_one': 0.6909, 'length_of_stay': 0.1392, 'race': 0.1133, 
                'age': 0.0162, 'priors_count': 0.0097},
        '2nd': {'race': 0.4579, 'length_of_stay': 0.1456, 'unrelated_column_one': 0.1392, 
                'age': 0.0939, 'priors_count': 0.0502},
        '3rd': {'age': 0.1489, 'race': 0.1246, 'priors_count': 0.1133, 
                'length_of_stay': 0.1117, 'c_charge_degree_M': 0.0906},
    },
    'Attack 2': {
        '1st': {'race': 0.3706, 'unrelated_column_two': 0.1909, 'length_of_stay': 0.1602, 
                'unrelated_column_one': 0.1537, 'age': 0.0324},
        '2nd': {'unrelated_column_one': 0.2152, 'unrelated_column_two': 0.1909, 'race': 0.1602, 
                'length_of_stay': 0.1084, 'age': 0.0922},
        '3rd': {'age': 0.1505, 'unrelated_column_one': 0.1424, 'priors_count': 0.1214, 
                'unrelated_column_two': 0.1036, 'length_of_stay': 0.0971},
    },
    'Defense + Attack 1': {
        '1st': {'unrelated_column_one': 0.2411, 'length_of_stay': 0.1553, 'race': 0.1521, 
                'c_charge_degree_F': 0.0841, 'priors_count': 0.0712},
        '2nd': {'race': 0.1472, 'unrelated_column_one': 0.1311, 'priors_count': 0.1019, 
                'length_of_stay': 0.0971, 'sex_Female': 0.0825},
        '3rd': {'age': 0.1117, 'priors_count': 0.1084, 'Nothing shown': 0.1052, 
                'c_charge_degree_F': 0.1052, 'two_year_recid': 0.1003},
    },
    'Defense + Attack 2': {
        '1st': {'race': 0.1715, 'unrelated_column_two': 0.1100, 'length_of_stay': 0.1052, 
                'unrelated_column_one': 0.1003, 'c_charge_degree_M': 0.0939},
        '2nd': {'length_of_stay': 0.1133, 'race': 0.1084, 'c_charge_degree_M': 0.1052, 
                'c_charge_degree_F': 0.0971, 'unrelated_column_one': 0.0939},
        '3rd': {'age': 0.1003, 'priors_count': 0.1003, 'c_charge_degree_M': 0.0939, 
                'sex_Female': 0.0939, 'sex_Male': 0.0922},
    }
}

# Completing the color mapping and ensuring plot generation.

colors = {
    'race': '#FF7F0E',
    'unrelated_column_one': '#1F77B4',
    'unrelated_column_two': '#AEC7E8',
    'sex_Female': '#FF9896',
    'sex_Male': '#98DF8A',
    'length_of_stay': '#C49C94',
    'c_charge_degree_M': '#9467BD',
    'c_charge_degree_F': '#C5B0D5',
    'two_year_recid': '#8C564B',
    'priors_count': '#E377C2',
    'age': '#D62728',
    'Nothing shown': '#C7C7C7',
}

# Creating the plot for LIME and SHAP comparisons
fig, axs = plt.subplots(2, 5, figsize=(18, 10))

# Plotting LIME scenarios
plot_bar(axs[0, 0], lime_data['No Attack'], 'LIME: No Attack', colors)
plot_bar(axs[0, 1], lime_data['Attack 1'], 'LIME: Attack 1', colors)
plot_bar(axs[0, 2], lime_data['Attack 2'], 'LIME: Attack 2', colors)
plot_bar(axs[0, 3], lime_data['Defense + Attack 1'], 'LIME: Defense + Attack 1', colors)
plot_bar(axs[0, 4], lime_data['Defense + Attack 2'], 'LIME: Defense + Attack 2', colors)

# Plotting SHAP scenarios
plot_bar(axs[1, 0], shap_data['No Attack'], 'SHAP: No Attack', colors)
plot_bar(axs[1, 1], shap_data['Attack 1'], 'SHAP: Attack 1', colors)
plot_bar(axs[1, 2], shap_data['Attack 2'], 'SHAP: Attack 2', colors)
plot_bar(axs[1, 3], shap_data['Defense + Attack 1'], 'SHAP: Defense + Attack 1', colors)
plot_bar(axs[1, 4], shap_data['Defense + Attack 2'], 'SHAP: Defense + Attack 2', colors)

# Adding the legend below the plot, centered and larger
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.15), fontsize=12)

plt.tight_layout()

# Save the plot as a PNG file
output_path = "defense_scenarios_plotbbbbbbbbbbbbbbbbbbbbbbb.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()

output_path
