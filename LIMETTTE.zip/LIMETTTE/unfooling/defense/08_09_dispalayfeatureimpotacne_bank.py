import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Updated scenarios and runs labels for "age" feature analysis under attack-defense scenarios
scenarios = ['LIME: Attack 1 Defense', 'LIME: Attack 2 Defense', 'SHAP: Attack 1 Defense', 'SHAP: Attack 2 Defense']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Corrected rankings of "age" across the scenarios during attack-defense phases
lime_attack1_defense = [None, 2, 2, 2, 2]  # LIME Attack 1 Defense: "age" is ranked 2nd in Runs 2, 3, 4, and 5
lime_attack2_defense = [None, None, None, None, None]  # LIME Attack 2 Defense: "age" is not ranked in any run
shap_attack1_defense = [1, 1, 1, 1, 1]  # SHAP Attack 1 Defense: "age" is consistently ranked 1st in all runs
shap_attack2_defense = [1, 1, 1, 1, 1]  # SHAP Attack 2 Defense: "age" is consistently ranked 1st in all runs

# Define a custom color map that goes from red (rank 1) to green (rank 5, not ranked in top 3)
cmap = sns.color_palette("RdYlGn_r", 5)

# Mapping rankings to colors (None means not ranked, set to 5 for heatmap visualization)
data = np.array([
    [2 if r == 2 else (1 if r == 1 else 5) for r in lime_attack1_defense],  
    [1 if r == 1 else 5 for r in lime_attack2_defense],
    [1 if r == 1 else 5 for r in shap_attack1_defense],
    [1 if r == 1 else 5 for r in shap_attack2_defense]
])

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=True, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of "age" feature'}, linewidths=0.5, vmin=1, vmax=5)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs, fontsize=12)  
ax.set_yticklabels(scenarios, fontsize=12, rotation=0)

# Adjust the layout to prevent overlap
ax.set_title('"Age" Feature Ranking Across Runs for LIME and SHAP Attack-Defense', fontsize=14)
ax.set_xlabel('Runs', fontsize=12)
ax.set_ylabel('Scenarios', fontsize=12)

# Display the heatmap
plt.tight_layout()
plt.show()
