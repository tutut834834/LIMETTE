import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors.get(label, '#000000'), edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

lime_data = {
    'Run 1 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'poutcome_success': 0.2362, 'loan_no': 0.2207, 'unrelated_column_two': 0.1545, 'unrelated_column_one': 0.1435, 'month_oct': 0.1347},
        '3rd': {'unrelated_column_one': 0.2274, 'unrelated_column_two': 0.2185, 'loan_no': 0.2031, 'poutcome_success': 0.1589, 'month_oct': 0.1236}
    },
    'Run 1 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'loan_no': 0.2980, 'unrelated_column_two': 0.2605, 'poutcome_success': 0.1854, 'month_oct': 0.1236, 'month_sep': 0.0684},
        '3rd': {'unrelated_column_two': 0.2627, 'age': 0.1744, 'loan_no': 0.1722, 'poutcome_success': 0.1678, 'month_oct': 0.1302}
    },
    'Run 1 - Attack 2': {
        '1st': {'loan_no': 0.2185, 'poutcome_success': 0.1987, 'unrelated_column_one': 0.1788, 'unrelated_column_two': 0.1611, 'month_oct': 0.1192},
        '2nd': {'unrelated_column_two': 0.2097, 'poutcome_success': 0.1810, 'unrelated_column_one': 0.1744, 'loan_no': 0.1567, 'month_sep': 0.1126},
        '3rd': {'loan_no': 0.1898, 'unrelated_column_two': 0.1744, 'unrelated_column_one': 0.1678, 'age': 0.1347, 'poutcome_success': 0.1258}
    },
    'Run 1 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.2605},
        '3rd': {'unrelated_column_two': 0.2627}
    },
    'Run 1 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.2980},
        '3rd': {'unrelated_column_two': 0.2605}
    },
    'Run 2 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'month_apr': 0.2472, 'job_self-employed': 0.2296, 'unrelated_column_one': 0.1810, 'unrelated_column_two': 0.1700, 'housing_no': 0.1435},
        '3rd': {'housing_no': 0.2208, 'unrelated_column_two': 0.2009, 'month_apr': 0.1832, 'unrelated_column_one': 0.1523, 'job_self-employed': 0.1391}
    },
    'Run 2 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.2605, 'housing_no': 0.2472, 'month_apr': 0.2009, 'job_self-employed': 0.1788, 'age': 0.0618},
        '3rd': {'housing_no': 0.2583, 'unrelated_column_two': 0.1921, 'month_apr': 0.1876, 'age': 0.1369, 'job_self-employed': 0.1258}
    },
    'Run 2 - Attack 2': {
        '1st': {'month_apr': 0.2340, 'unrelated_column_one': 0.1898, 'housing_no': 0.1854, 'unrelated_column_two': 0.1722, 'job_self-employed': 0.1567},
        '2nd': {'unrelated_column_one': 0.2208, 'month_apr': 0.2009, 'unrelated_column_two': 0.1744, 'housing_no': 0.1435, 'job_self-employed': 0.1413},
        '3rd': {'unrelated_column_two': 0.1634, 'unrelated_column_one': 0.1567, 'job_self-employed': 0.1545, 'month_apr': 0.1435, 'housing_no': 0.1347}
    },
    'Run 2 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'age': 0.1369},
        '3rd': {'unrelated_column_two': 0.1921}
    },
    'Run 2 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.2605},
        '3rd': {'unrelated_column_two': 0.2583}
    },
    'Run 3 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'month_apr': 0.2031, 'housing_no': 0.1744, 'housing_yes': 0.1744, 'unrelated_column_two': 0.1678, 'contact_cellular': 0.1501},
        '3rd': {'housing_no': 0.1876, 'unrelated_column_one': 0.1744, 'month_apr': 0.1700, 'unrelated_column_two': 0.1634, 'contact_cellular': 0.1567}
    },
    'Run 3 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'month_apr': 0.2362, 'housing_no': 0.2141, 'contact_cellular': 0.2009, 'unrelated_column_two': 0.1678, 'housing_yes': 0.1523},
        '3rd': {'unrelated_column_two': 0.2031, 'housing_yes': 0.1965, 'housing_no': 0.1943, 'contact_cellular': 0.1611, 'month_apr': 0.1501}
    },
    'Run 3 - Attack 2': {
        '1st': {'month_apr': 0.2185, 'contact_cellular': 0.1700, 'housing_yes': 0.1700, 'unrelated_column_one': 0.1634, 'unrelated_column_two': 0.1479},
        '2nd': {'unrelated_column_two': 0.2053, 'unrelated_column_one': 0.1832, 'month_apr': 0.1700, 'housing_no': 0.1457, 'contact_cellular': 0.1192},
        '3rd': {'housing_no': 0.1898, 'unrelated_column_two': 0.1523, 'contact_cellular': 0.1457, 'housing_yes': 0.1369, 'unrelated_column_one': 0.1369}
    },
    'Run 3 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'age': 0.1280},
        '3rd': {'unrelated_column_two': 0.1921}
    },
    'Run 3 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.2053},
        '3rd': {'unrelated_column_two': 0.1987}
    },
    'Run 4 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'month_jun': 0.2561, 'unrelated_column_one': 0.1921, 'contact_cellular': 0.1832, 'unrelated_column_two': 0.1678, 'job_unemployed': 0.1501},
        '3rd': {'contact_cellular': 0.2009, 'unrelated_column_two': 0.1876, 'month_jun': 0.1766, 'unrelated_column_one': 0.1634, 'job_unemployed': 0.1589}
    },
     'Run 4 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'month_jun': 0.2583, 'contact_cellular': 0.2318, 'unrelated_column_two': 0.2318, 'job_unemployed': 0.1854, 'age': 0.0486},
        '3rd': {'unrelated_column_two': 0.2583, 'contact_cellular': 0.1965, 'month_jun': 0.1589, 'age': 0.1567, 'job_unemployed': 0.1457}
    },
    'Run 4 - Attack 2': {
        '1st': {'month_jun': 0.2517, 'unrelated_column_one': 0.2075, 'job_unemployed': 0.1921, 'unrelated_column_two': 0.1523, 'contact_cellular': 0.1457},
        '2nd': {'unrelated_column_two': 0.1854, 'month_jun': 0.1788, 'job_unemployed': 0.1700, 'unrelated_column_one': 0.1523, 'contact_cellular': 0.1501},
        '3rd': {'unrelated_column_two': 0.1943, 'contact_cellular': 0.1766, 'unrelated_column_one': 0.1435, 'month_jun': 0.1413, 'age': 0.1258}
    },
    'Run 4 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'age': 0.1015},
        '3rd': {'unrelated_column_two': 0.1987}
    },
    'Run 4 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.2362},
        '3rd': {'unrelated_column_two': 0.2141}
    },
    'Run 5 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'month_jun': 0.2318, 'month_may': 0.1788, 'job_entrepreneur': 0.1678, 'unrelated_column_one': 0.1656, 'unrelated_column_two': 0.1347},
        '3rd': {'month_jun': 0.1898, 'month_may': 0.1898, 'education_secondary': 0.1876, 'unrelated_column_two': 0.1634, 'unrelated_column_one': 0.1545}
    },
    'Run 5 - Attack 1': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'month_jun': 0.2472, 'education_secondary': 0.2163, 'month_may': 0.2053, 'unrelated_column_two': 0.1523, 'job_entrepreneur': 0.1501},
        '3rd': {'unrelated_column_two': 0.2428, 'education_secondary': 0.2031, 'month_may': 0.1943, 'month_jun': 0.1523, 'job_entrepreneur': 0.1104}
    },
    'Run 5 - Attack 2': {
        '1st': {'month_jun': 0.2163, 'job_entrepreneur': 0.1854, 'unrelated_column_one': 0.1634, 'unrelated_column_two': 0.1523, 'education_secondary': 0.1347},
        '2nd': {'unrelated_column_two': 0.1810, 'month_jun': 0.1678, 'unrelated_column_one': 0.1589, 'month_may': 0.1567, 'job_entrepreneur': 0.1479},
        '3rd': {'education_secondary': 0.1898, 'unrelated_column_one': 0.1898, 'unrelated_column_two': 0.1545, 'month_may': 0.1501, 'month_jun': 0.1457}
    },
    'Run 5 - Attack 1 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.1854},
        '3rd': {'unrelated_column_two': 0.2428}
    },
    'Run 5 - Attack 2 Defense': {
        '1st': {'unrelated_column_one': 1.0},
        '2nd': {'unrelated_column_two': 0.1921},
        '3rd': {'unrelated_column_two': 0.1810}
    }
}


shap_data = {
    'Run 1 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 1 - Attack 1': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.7152, 'loan_no': 0.1391, 'poutcome_success': 0.0530, 'month_sep': 0.0309, 'month_oct': 0.0287},
        '3rd': {'Nothing shown': 0.7152, 'month_oct': 0.1038, 'unrelated_column_one': 0.0684, 'month_sep': 0.0419, 'unrelated_column_two': 0.0287}
    },
    'Run 1 - Attack 2': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.6071, 'loan_no': 0.1038, 'unrelated_column_two': 0.1015, 'poutcome_success': 0.0971, 'month_sep': 0.0442},
        '3rd': {'Nothing shown': 0.6071, 'month_sep': 0.1192, 'unrelated_column_two': 0.0817, 'poutcome_success': 0.0795, 'loan_no': 0.0442}
    },
    'Run 1 - Attack 1 Defense': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.7241},
        '3rd': {'Nothing shown': 0.7241}
    },
    'Run 1 - Attack 2 Defense': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.6159},
        '3rd': {'Nothing shown': 0.6071}
    },
    'Run 2 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 2 - Attack 1': {
        '1st': {'age': 0.6049, 'unrelated_column_one': 0.3598, 'duration': 0.0287, 'job_self-employed': 0.0044, 'month_apr': 0.0022},
        '2nd': {'unrelated_column_one': 0.4283, 'age': 0.2472, 'duration': 0.2009, 'housing_no': 0.0618, 'unrelated_column_two': 0.0596},
        '3rd': {'duration': 0.3201, 'housing_no': 0.1876, 'unrelated_column_two': 0.1876, 'unrelated_column_one': 0.1589, 'age': 0.1126}
    },
    'Run 2 - Attack 2': {
        '1st': {'age': 0.6600, 'unrelated_column_two': 0.1523, 'unrelated_column_one': 0.1170, 'duration': 0.0419, 'housing_no': 0.0155},
        '2nd': {'duration': 0.3510, 'unrelated_column_one': 0.2185, 'unrelated_column_two': 0.1987, 'age': 0.1523, 'housing_no': 0.0684},
        '3rd': {'unrelated_column_one': 0.2737, 'unrelated_column_two': 0.2340, 'duration': 0.1943, 'housing_no': 0.1501, 'age': 0.0993}
    },
    'Run 2 - Attack 1 Defense': {
        '1st': {'age': 0.8710, 'unrelated_column_one': 0.1290},
        '2nd': {'age': 0.7200},
                '3rd': {'Nothing shown': 0.7263}
    },
    'Run 2 - Attack 2 Defense': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.6600},
        '3rd': {'Nothing shown': 0.6600}
    },
    'Run 3 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 3 - Attack 1': {
        '1st': {'age': 0.6430, 'unrelated_column_one': 0.2543, 'month_apr': 0.0640, 'housing_no': 0.0287, 'contact_cellular': 0.0109},
        '2nd': {'unrelated_column_one': 0.5220, 'age': 0.2296, 'contact_cellular': 0.1077, 'housing_no': 0.0862, 'unrelated_column_two': 0.0530},
        '3rd': {'unrelated_column_two': 0.3616, 'contact_cellular': 0.2031, 'unrelated_column_one': 0.1987, 'age': 0.1258, 'housing_no': 0.0721}
    },
    'Run 3 - Attack 2': {
        '1st': {'age': 0.7040, 'unrelated_column_one': 0.1567, 'month_apr': 0.0784, 'contact_cellular': 0.0363, 'housing_no': 0.0241},
        '2nd': {'unrelated_column_one': 0.5001, 'unrelated_column_two': 0.2729, 'contact_cellular': 0.1501, 'month_apr': 0.1192, 'age': 0.0419},
        '3rd': {'unrelated_column_two': 0.3672, 'unrelated_column_one': 0.3124, 'housing_no': 0.2120, 'contact_cellular': 0.0871, 'month_apr': 0.0518}
    },
    'Run 3 - Attack 1 Defense': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.7027},
        '3rd': {'Nothing shown': 0.6430}
    },
    'Run 3 - Attack 2 Defense': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.6468},
        '3rd': {'Nothing shown': 0.6468}
    },
    'Run 4 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 4 - Attack 1': {
        '1st': {'age': 0.6713, 'unrelated_column_one': 0.2150, 'month_jun': 0.0838, 'contact_cellular': 0.0241, 'job_unemployed': 0.0055},
        '2nd': {'unrelated_column_one': 0.5438, 'age': 0.2762, 'unrelated_column_two': 0.0849, 'contact_cellular': 0.0529, 'month_jun': 0.0428},
        '3rd': {'unrelated_column_two': 0.3865, 'unrelated_column_one': 0.3101, 'contact_cellular': 0.1717, 'month_jun': 0.0917, 'age': 0.0408}
    },
    'Run 4 - Attack 2': {
        '1st': {'age': 0.6824, 'unrelated_column_one': 0.1722, 'month_jun': 0.1038, 'job_unemployed': 0.0287, 'contact_cellular': 0.0120},
        '2nd': {'unrelated_column_one': 0.5044, 'unrelated_column_two': 0.2661, 'month_jun': 0.1482, 'contact_cellular': 0.0673, 'age': 0.0155},
        '3rd': {'unrelated_column_two': 0.3432, 'unrelated_column_one': 0.2980, 'month_jun': 0.2085, 'contact_cellular': 0.0939, 'age': 0.0560}
    },
    'Run 4 - Attack 1 Defense': {
        '1st': {'age': 0.9677},
        '2nd': {'Nothing shown': 0.7152},
        '3rd': {'Nothing shown': 0.7004}
    },
    'Run 4 - Attack 2 Defense': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 0.7052},
        '3rd': {'Nothing shown': 0.7052}
    },
    'Run 5 - No Attack': {
        '1st': {'age': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0}
    },
    'Run 5 - Attack 1': {
        '1st': {'age': 0.6824, 'unrelated_column_one': 0.2031, 'month_jun': 0.0695, 'job_entrepreneur': 0.0363, 'month_may': 0.0087},
        '2nd': {'unrelated_column_one': 0.5044, 'age': 0.3270, 'unrelated_column_two': 0.1229, 'month_may': 0.0452, 'job_entrepreneur': 0.0009},
        '3rd': {'unrelated_column_two': 0.3727, 'unrelated_column_one': 0.2824, 'month_jun': 0.2029, 'age': 0.0710, 'month_may': 0.0684}
    },
    'Run 5 - Attack 2': {
        '1st': {'age': 0.6142, 'unrelated_column_one': 0.2141, 'unrelated_column_two': 0.0971, 'month_may': 0.0442, 'job_entrepreneur': 0.0287},
        '2nd': {'unrelated_column_one': 0.4977, 'unrelated_column_two': 0.2561, 'month_may': 0.1082, 'month_jun': 0.0530, 'age': 0.0309},
        '3rd': {'unrelated_column_two': 0.3672, 'unrelated_column_one': 0.2672, 'age': 0.1832, 'month_may': 0.0893, 'month_jun': 0.0529}
    },
    'Run 5 - Attack 1 Defense': {
        '1st': {'age': 0.8710},
        '2nd': {'Nothing shown': 0.7263},
        '3rd': {'Nothing shown': 0.7263}
    },
    'Run 5 - Attack 2 Defense': {
        '1st': {'age': 0.8710},
        '2nd': {'Nothing shown': 0.7263},
        '3rd': {'Nothing shown': 0.7263}
    }
}



# Color mapping for features
colors = {
    'age': '#FF7F0E',
    'unrelated_column_two': '#1F77B4',
    'unrelated_column_one': '#2CA02C',
    'poutcome_success': '#D62728',
    'loan_no': '#9467BD',
    'month_oct': '#8C564B',
    'month_sep': '#E377C2',
    'month_jun': '#17BECF',
    'job_self-employed': '#BCBD22',
    'contact_cellular': '#FFBB78',
    'job_unemployed': '#C49C94',
    'housing_no': '#7F7F7F',
    'housing_yes': '#98DF8A',
    'balance': '#17BECF',
    'duration': '#FF9896',
    'Nothing shown': '#CCCCCC',
    'education_secondary': '#9B9B9B',
    'job_entrepreneur': '#C7C7C7'
}

# Adjust the subplot grid to have 10 columns to accommodate all the scenarios (5 for LIME, 5 for SHAP)
fig, axs = plt.subplots(5, 10, figsize=(30, 30))  # 5 rows for each run, 10 columns for each scenario

# Plotting LIME scenarios for all 5 runs (No Attack, Attack 1, Attack 1 Defense, Attack 2, Attack 2 Defense)
for i in range(5):
    run_name = f'Run {i+1}'
    plot_bar(axs[i, 0], lime_data[f'{run_name} - No Attack'], f'{run_name} - LIME: No Attack', colors)
    plot_bar(axs[i, 1], lime_data[f'{run_name} - Attack 1'], f'{run_name} - LIME: Attack 1', colors)
    plot_bar(axs[i, 2], lime_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - LIME: Attack 1 Defense', colors)
    plot_bar(axs[i, 3], lime_data[f'{run_name} - Attack 2'], f'{run_name} - LIME: Attack 2', colors)
    plot_bar(axs[i, 4], lime_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - LIME: Attack 2 Defense', colors)

    # Plotting SHAP scenarios for all 5 runs (No Attack, Attack 1, Attack 1 Defense, Attack 2, Attack 2 Defense)
    plot_bar(axs[i, 5], shap_data[f'{run_name} - No Attack'], f'{run_name} - SHAP: No Attack', colors)
    plot_bar(axs[i, 6], shap_data[f'{run_name} - Attack 1'], f'{run_name} - SHAP: Attack 1', colors)
    plot_bar(axs[i, 7], shap_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - SHAP: Attack 1 Defense', colors)
    plot_bar(axs[i, 8], shap_data[f'{run_name} - Attack 2'], f'{run_name} - SHAP: Attack 2', colors)
    plot_bar(axs[i, 9], shap_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - SHAP: Attack 2 Defense', colors)

# Adding the legend
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.05), fontsize=12)

# Adjust the layout for better visualization
plt.tight_layout()

# Save the plot as a PNG file
plt.savefig("attack_defense_graph_runs_final_big_plot_diabetes.png", bbox_inches='tight', dpi=300)
plt.savefig("attack_defense_graph_runs_final_big_plot_diabetes.jpeg", bbox_inches='tight', dpi=300)

# Show the plot
plt.show()




# Color mapping for features
colors = {
    'age': '#FF7F0E',
    'unrelated_column_two': '#1F77B4',
    'unrelated_column_one': '#2CA02C',
    'poutcome_success': '#D62728',
    'loan_no': '#9467BD',
    'month_oct': '#8C564B',
    'month_sep': '#E377C2',
    'month_jun': '#17BECF',
    'job_self-employed': '#BCBD22',
    'contact_cellular': '#FFBB78',
    'job_unemployed': '#C49C94',
    'housing_no': '#7F7F7F',
    'housing_yes': '#98DF8A',
    'balance': '#17BECF',
    'duration': '#FF9896',
    'Nothing shown': '#CCCCCC',
    'education_secondary': '#9B9B9B',
    'job_entrepreneur': '#C7C7C7',
    'race': '#FF6347',
    'diag_1_7': '#8A2BE2',
    'diag_1_250.11': '#4B0082',
    'diag_1_458': '#483D8B',
    'num_procedures': '#6495ED',
    'number_diagnoses': '#4682B4',
    'diag_3_V58': '#00CED1',
    'metformin_No': '#2E8B57',
    'diag_1_250.13': '#556B2F',
    'diag_2_5': '#8FBC8F',
    'payer_code_MC': '#FFDEAD',
    'diag_1_562': '#FFD700',
}


# Adjust the subplot grid to have 10 columns to accommodate all the scenarios (5 for LIME, 5 for SHAP)
fig, axs = plt.subplots(5, 10, figsize=(30, 30))  # 5 rows for each run, 10 columns for each scenario

# Plotting LIME scenarios for all 5 runs (No Attack, Attack 1, Attack 1 Defense, Attack 2, Attack 2 Defense)
for i in range(5):
    run_name = f'Run {i+1}'
    plot_bar(axs[i, 0], lime_data[f'{run_name} - No Attack'], f'{run_name} - LIME: No Attack', colors)
    plot_bar(axs[i, 1], lime_data[f'{run_name} - Attack 1'], f'{run_name} - LIME: Attack 1', colors)
    plot_bar(axs[i, 2], lime_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - LIME: Attack 1 Defense', colors)
    plot_bar(axs[i, 3], lime_data[f'{run_name} - Attack 2'], f'{run_name} - LIME: Attack 2', colors)
    plot_bar(axs[i, 4], lime_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - LIME: Attack 2 Defense', colors)

    # Plotting SHAP scenarios for all 5 runs (No Attack, Attack 1, Attack 1 Defense, Attack 2, Attack 2 Defense)
    plot_bar(axs[i, 5], shap_data[f'{run_name} - No Attack'], f'{run_name} - SHAP: No Attack', colors)
    plot_bar(axs[i, 6], shap_data[f'{run_name} - Attack 1'], f'{run_name} - SHAP: Attack 1', colors)
    plot_bar(axs[i, 7], shap_data[f'{run_name} - Attack 1 Defense'], f'{run_name} - SHAP: Attack 1 Defense', colors)
    plot_bar(axs[i, 8], shap_data[f'{run_name} - Attack 2'], f'{run_name} - SHAP: Attack 2', colors)
    plot_bar(axs[i, 9], shap_data[f'{run_name} - Attack 2 Defense'], f'{run_name} - SHAP: Attack 2 Defense', colors)

# Adding the legend
handles = [plt.Rectangle((0, 0), 1, 1, color=colors[label]) for label in colors]
labels = list(colors.keys())
plt.figlegend(handles, labels, loc='lower center', ncol=6, bbox_to_anchor=(0.5, -0.05), fontsize=12)

# Adjust the layout for better visualization
plt.tight_layout()

# Save the plot as a PNG file
plt.savefig("attack_defense_graph_runs_final_big_plot_diabetes.png", bbox_inches='tight', dpi=300)
plt.savefig("attack_defense_graph_runs_final_big_plot_diabetes.jpeg", bbox_inches='tight', dpi=300)

# Show the plot
plt.show()