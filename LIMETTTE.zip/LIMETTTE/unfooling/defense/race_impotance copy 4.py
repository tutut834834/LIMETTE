import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns


# Updated scenarios and runs labels as per user request
scenarios = ['LIME: Attack-Defense 1', 'LIME: Attack-Defense 2', 'SHAP: Attack-Defense 1', 'SHAP: Attack-Defense 2']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Precise rankings for "race" feature based on the provided data
lime_attack1 = [2, 2, 2, 2, 2]  # Rank 2 in all runs for LIME Attack 1
lime_attack2 = [1, 1, 1, 1, 1]  # Rank 1 in all runs for LIME Attack 2
shap_attack1 = [1, 1, 1, 1, 1]  # Rank 1 in all runs for SHAP Attack 1
shap_attack2 = [1, 2, 2, 1, 1]  # Mixed ranks for SHAP Attack 2

# Combine data into a numpy array for plotting
data = np.array([lime_attack1, lime_attack2, shap_attack1, shap_attack2])

# Define a custom color map that goes from green (rank 1) to red (rank 5)
cmap = sns.color_palette("RdYlGn_r", 5)  # Rank 1 (green) to 5 (red)

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=True, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of Race'}, linewidths=0.5, vmin=1, vmax=5)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs, fontsize=12)  # Adjust font size for readability
ax.set_yticklabels(scenarios, fontsize=12, rotation=0)  # Rotate the labels to horizontal

# Adjust the layout to prevent overlap
ax.set_title('Race Feature Ranking Across Runs for LIME and SHAP Attack-Defense', fontsize=14)
ax.set_xlabel('Runs', fontsize=12)
ax.set_ylabel('Scenarios', fontsize=12)

# Display the heatmap
plt.tight_layout()
plt.show()
