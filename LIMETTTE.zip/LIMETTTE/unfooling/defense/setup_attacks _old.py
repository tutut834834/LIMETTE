import foolbox as fb
import torch
from foolbox import PyTorchModel, accuracy, samples
from foolbox.attacks import FGSM, LinfPGD, L2CarliniWagnerAttack, LinfDeepFoolAttack, L2DeepFoolAttack
from foolbox.attacks import LinfBasicIterativeAttack, L2BasicIterativeAttack, L2PGD, LinfPGD, L2ProjectedGradientDescentAttack
import torchvision.models as models

# Load a pretrained model
model = models.resnet18(pretrained=True).eval()

# Create a foolbox model
fmodel = PyTorchModel(model, bounds=(0, 1))

# Define the attacks
attack_1 = FGSM()  # FGSM doesn't take model in __init__
attack_2 = LinfPGD()
attack_3 = L2CarliniWagnerAttack()
attack_4 = LinfDeepFoolAttack()
attack_5 = L2DeepFoolAttack()
attack_6 = LinfBasicIterativeAttack()
attack_7 = L2BasicIterativeAttack()
attack_8 = L2PGD()
attack_9 = LinfPGD()
attack_10 = L2ProjectedGradientDescentAttack()

# Store them in a list
attacks = [attack_1, attack_2, attack_3, attack_4, attack_5, attack_6, attack_7, attack_8, attack_9, attack_10]

print("Attacks have been initialized and ready to be used.")

# These attacks can now be used within the GMMCADFull class or wherever necessary.
