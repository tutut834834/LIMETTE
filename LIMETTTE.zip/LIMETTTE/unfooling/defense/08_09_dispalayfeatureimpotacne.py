import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Updated scenarios and runs labels as per user request
scenarios = ['LIME: Attack-Defense 1', 'LIME: Attack-Defense 2', 'SHAP: Attack-Defense 1', 'SHAP: Attack-Defense 2']
runs = ['Run 1', 'Run 2', 'Run 3', 'Run 4', 'Run 5']

# Precise rankings for "race" feature based on the provided data
lime_attack1 = [2, 2, 2, 2, 2]  # Rank 2 in all runs for LIME Attack 1
lime_attack2 = [1, 1, 1, 1, 1]  # Rank 1 in all runs for LIME Attack 2
shap_attack1 = [1, 1, 1, 1, 1]  # Rank 1 in all runs for SHAP Attack 1
shap_attack2 = [1, 2, 2, 1, 1]  # Mixed ranks for SHAP Attack 2

# Corresponding feature importance values for the top 3 features (in percentages)
# Assuming top 3 for each run and scenario (just an example, replace with actual values)
importance_values = [
    [("Rank 2", "Race: 0.28", "Sex: 0.18", "Recidivism: 0.12"),   # LIME Attack 1, Run 1
     ("Rank 2", "Race: 0.27", "Sex: 0.17", "Recidivism: 0.11"),   # LIME Attack 1, Run 2
     ("Rank 2", "Race: 0.29", "Sex: 0.15", "Recidivism: 0.10"),   # LIME Attack 1, Run 3
     ("Rank 2", "Race: 0.26", "Sex: 0.16", "Recidivism: 0.12"),   # LIME Attack 1, Run 4
     ("Rank 2", "Race: 0.25", "Sex: 0.14", "Recidivism: 0.11")],  # LIME Attack 1, Run 5

    [("Rank 1", "Race: 0.47", "Length: 0.23", "Recidivism: 0.20"),   # LIME Attack 2, Run 1
     ("Rank 1", "Race: 0.46", "Length: 0.24", "Recidivism: 0.22"),   # LIME Attack 2, Run 2
     ("Rank 1", "Race: 0.48", "Length: 0.25", "Recidivism: 0.21"),   # LIME Attack 2, Run 3
     ("Rank 1", "Race: 0.47", "Length: 0.24", "Recidivism: 0.20"),   # LIME Attack 2, Run 4
     ("Rank 1", "Race: 0.46", "Length: 0.23", "Recidivism: 0.19")],  # LIME Attack 2, Run 5

    [("Rank 1", "Race: 0.28", "Sex: 0.17", "Recidivism: 0.12"),   # SHAP Attack 1, Run 1
     ("Rank 1", "Race: 0.27", "Sex: 0.18", "Recidivism: 0.14"),   # SHAP Attack 1, Run 2
     ("Rank 1", "Race: 0.29", "Sex: 0.15", "Recidivism: 0.13"),   # SHAP Attack 1, Run 3
     ("Rank 1", "Race: 0.30", "Sex: 0.16", "Recidivism: 0.14"),   # SHAP Attack 1, Run 4
     ("Rank 1", "Race: 0.28", "Sex: 0.17", "Recidivism: 0.15")],  # SHAP Attack 1, Run 5

    [("Rank 1", "Race: 0.47", "Sex: 0.25", "Recidivism: 0.18"),   # SHAP Attack 2, Run 1
     ("Rank 2", "Race: 0.35", "Sex: 0.23", "Recidivism: 0.16"),   # SHAP Attack 2, Run 2
     ("Rank 2", "Race: 0.36", "Sex: 0.24", "Recidivism: 0.17"),   # SHAP Attack 2, Run 3
     ("Rank 1", "Race: 0.45", "Sex: 0.22", "Recidivism: 0.19"),   # SHAP Attack 2, Run 4
     ("Rank 1", "Race: 0.46", "Sex: 0.21", "Recidivism: 0.20")]   # SHAP Attack 2, Run 5
]

# Combine data into a numpy array for plotting
data = np.array([lime_attack1, lime_attack2, shap_attack1, shap_attack2])

# Define a custom color map that goes from green (rank 1) to red (rank 5)
cmap = sns.color_palette("RdYlGn_r", 5)  # Rank 1 (green) to 5 (red)

# Plotting the heatmap
plt.figure(figsize=(10, 6))
ax = sns.heatmap(data, annot=False, fmt="d", cmap=cmap, cbar_kws={'label': 'Rank of Race'}, linewidths=0.5, vmin=1, vmax=5)

# Add detailed text (rank and importance values) in each cell
for i in range(data.shape[0]):
    for j in range(data.shape[1]):
        text = '\n'.join(importance_values[i][j])
        ax.text(j + 0.5, i + 0.5, text, ha='center', va='center', color='black', fontsize=8)

# Set axis labels and titles
ax.set_xticks(np.arange(len(runs)) + 0.5)
ax.set_yticks(np.arange(len(scenarios)) + 0.5)
ax.set_xticklabels(runs, fontsize=12)  # Adjust font size for readability
ax.set_yticklabels(scenarios, fontsize=12, rotation=0)  # Rotate the labels to horizontal

# Adjust the layout to prevent overlap
ax.set_title('Race Feature Ranking Across Runs for LIME and SHAP Attack-Defense', fontsize=14)
ax.set_xlabel('Runs', fontsize=12)
ax.set_ylabel('Scenarios', fontsize=12)

# Display the heatmap
plt.tight_layout()
plt.show()
