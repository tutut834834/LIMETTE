import foolbox as fb
import torch
from torchvision import models
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd  # Add pandas to handle CSV output

matplotlib.use('Agg')  # Set the backend to 'Agg' for script-based usage

# Check for GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load model and data
model = models.resnet18(weights='DEFAULT').eval().to(device)
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Create synthetic image data
synthetic_image = torch.rand((1, 3, 224, 224)).to(device)
label = torch.tensor([1]).to(device)

# Define epsilon values for the attack
epsilons = [0.01, 0.03, 0.05, 0.07, 0.1, 0.15]

# Initialize a dictionary to store results for each attack
results = {
    'Attack': [],
    'Epsilon': [],
    'SuccessRate': [],
    'PerturbationMagnitude': [],
    'ModelConfidence': []
}

# List of attacks to perform
attacks = {
    'FGSM': fb.attacks.FGSM(),
    'BIM': fb.attacks.LinfBasicIterativeAttack(),
    'PGD': fb.attacks.PGD(),
    'L2PGD': fb.attacks.L2PGD(),
    'DeepFool': fb.attacks.L2DeepFoolAttack(),
    'Spatial': fb.attacks.SpatialAttack(),
}

# Define the backdoor attack pattern
def apply_backdoor_pattern(image):
    patch_size = 10
    image[:, :, :patch_size, :patch_size] = 1.0  # Add a white square in the top-left corner as a backdoor trigger
    return image

# Perform the attacks
for attack_name, attack in attacks.items():
    print(f"Running {attack_name} attack...")
    
    for epsilon in epsilons:
        if attack_name == 'DataPerturbation':
            adversarial_image = synthetic_image + epsilon * torch.randn_like(synthetic_image).to(device)
        elif attack_name == 'BackdoorAttack':
            adversarial_image = apply_backdoor_pattern(synthetic_image.clone())
        else:
            adversarial = attack(fmodel, synthetic_image, label, epsilons=[epsilon])
            adversarial_image = adversarial[0][0]
            if adversarial_image.dim() == 3:
                adversarial_image = adversarial_image.unsqueeze(0)

        adversarial_image = adversarial_image.to(device)
        
        with torch.no_grad():
            logits = model(adversarial_image)
            predicted_class = torch.argmax(logits, dim=1)
            success_rate = (predicted_class != label).float().mean().item()
            perturbation = adversarial_image - synthetic_image
            perturbation_magnitude = perturbation.norm().item()
            model_confidence = torch.max(torch.softmax(logits, dim=1)).item()
            
            # Save the results
            results['Attack'].append(attack_name)
            results['Epsilon'].append(epsilon)
            results['SuccessRate'].append(success_rate)
            results['PerturbationMagnitude'].append(perturbation_magnitude)
            results['ModelConfidence'].append(model_confidence)

# Convert results to DataFrame and save as CSV
df = pd.DataFrame(results)
df.to_csv('attack_results.csv', index=False)
print("Results saved to 'attack_results.csv'.")
