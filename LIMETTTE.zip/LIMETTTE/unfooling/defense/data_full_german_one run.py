import matplotlib.pyplot as plt
import numpy as np

# Function to plot bars for each scenario
def plot_bar(ax, data, title, colors):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels, values = zip(*data[category].items())
        bottoms = np.cumsum([0] + list(values[:-1]))
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Data for the three examples of LIME and SHAP
lime_data_no_attack = {
    '1st': {'Gender': 1.0},
    '2nd': {'HasCoapplicant': 0.2, 'NoCurrentLoan': 0.18, 'ForeignWorker': 0.17, 'CheckingAccountBalance_geq_200': 0.14, 'Unemployed': 0.09},
    '3rd': {'HasCoapplicant': 0.15, 'ForeignWorker': 0.12, 'HasGuarantor': 0.12, 'SavingsAccountBalance_geq_500': 0.11, 'CheckingAccountBalance_geq_200': 0.08}
}

lime_data_attack_1 = {
    '1st': {'LoanRateAsPercentOfIncome': 1.0},
    '2nd': {'ForeignWorker': 0.15, 'HasCoapplicant': 0.14, 'NoCurrentLoan': 0.13, 'HasGuarantor': 0.12, 'CheckingAccountBalance_geq_200': 0.11},
    '3rd': {'NoCurrentLoan': 0.15, 'ForeignWorker': 0.11, 'HasGuarantor': 0.11, 'Unemployed': 0.11, 'CheckingAccountBalance_geq_200': 0.09}
}

lime_data_defense_attack_1 = {
    '1st': {'LoanRateAsPercentOfIncome': 1.0},
    '2nd': {'Single': 0.99, 'HasCoapplicant': 0.01},
    '3rd': {'Gender': 0.36, 'HasCoapplicant': 0.36, 'ForeignWorker': 0.1, 'HasGuarantor': 0.07, 'MissedPayments': 0.04}
}

shap_data_no_attack = {
    '1st': {'Gender': 1.0},
    '2nd': {'Nothing shown': 1.0},
    '3rd': {'Nothing shown': 1.0}
}

shap_data_attack_1 = {
    '1st': {'LoanRateAsPercentOfIncome': 0.79, 'Gender': 0.13, 'LoanAmount': 0.05, 'Age': 0.01, 'JobClassIsSkilled': 0.01},
    '2nd': {'Gender': 0.29, 'LoanRateAsPercentOfIncome': 0.13, 'YearsAtCurrentHome': 0.13, 'Age': 0.1, 'LoanAmount': 0.1},
    '3rd': {'LoanDuration': 0.21, 'YearsAtCurrentHome': 0.16, 'Gender': 0.14, 'LoanAmount': 0.13, 'Single': 0.11}
}

shap_data_defense_attack_1 = {
    '1st': {'LoanRateAsPercentOfIncome': 0.73, 'Gender': 0.15, 'LoanAmount': 0.05, 'YearsAtCurrentHome': 0.04, 'Age': 0.02},
    '2nd': {'Gender': 0.31, 'LoanRateAsPercentOfIncome': 0.17, 'LoanAmount': 0.12, 'Age': 0.1, 'LoanDuration': 0.1},
    '3rd': {'Single': 0.18, 'YearsAtCurrentHome': 0.17, 'LoanAmount': 0.15, 'LoanDuration': 0.11, 'Age': 0.08}
}

# Color mapping for features
colors = {
    'Gender': '#FF7F0E',
    'HasCoapplicant': '#1F77B4',
    'NoCurrentLoan': '#2CA02C',
    'ForeignWorker': '#D62728',
    'CheckingAccountBalance_geq_200': '#9467BD',
    'Unemployed': '#8C564B',
    'HasGuarantor': '#E377C2',
    'SavingsAccountBalance_geq_500': '#C49C94',
    'LoanRateAsPercentOfIncome': '#17BECF',
    'Nothing shown': '#7F7F7F',
    'LoanAmount': '#BCBD22',
    'Age': '#DBDB8D',
    'JobClassIsSkilled': '#9B9B9B',
    'YearsAtCurrentHome': '#FFBB78',
    'Single': '#98DF8A',
    'LoanDuration': '#FF9896',
    'MissedPayments': '#AEC7E8'
}

# Create the plot for all scenarios (No Attack, Attack 1, Attack 1 Defense for both LIME and SHAP)
fig, axs = plt.subplots(2, 3, figsize=(18, 12))  # 2 rows (LIME and SHAP), 3 columns (No Attack, Attack 1, Attack 1 Defense)

# Plotting LIME scenarios
plot_bar(axs[0, 0], lime_data_no_attack, 'LIME: No Attack', colors)
plot_bar(axs[0, 1], lime_data_attack_1, 'LIME: Attack 1', colors)
plot_bar(axs[0, 2], lime_data_defense_attack_1, 'LIME: Defense Attack 1', colors)

# Plotting SHAP scenarios
plot_bar(axs[1, 0], shap_data_no_attack, 'SHAP: No Attack', colors)
plot_bar(axs[1, 1], shap_data_attack_1, 'SHAP: Attack 1', colors)
plot_bar(axs[1, 2], shap_data_defense_attack_1, 'SHAP: Defense Attack 1', colors)

# Adjust the layout for better visualization
plt.tight_layout()

# Save the plot as a PNG file
output_path = "lime_shap_comparison_plotGerman.png"
plt.savefig(output_path, bbox_inches='tight', dpi=300)

# Show the plot
plt.show()

output_path
