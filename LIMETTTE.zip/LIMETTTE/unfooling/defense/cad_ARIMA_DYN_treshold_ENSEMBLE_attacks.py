import numpy as np
from scipy.special import logsumexp
from scipy.stats import multivariate_normal
from sklearn.base import OutlierMixin, BaseEstimator
from sklearn.mixture import GaussianMixture
from tqdm import tqdm
from statsmodels.tsa.arima.model import ARIMA  # For ARIMA integration

# Import adversarial attack methods
from foolbox import PyTorchModel, attacks

def logdotexp(A, B):
    """
    Kudos to: https://stackoverflow.com/questions/23630277/numerically-stable-way-to-multiply-log-probability-matrices-in-numpy
    """
    max_A = np.max(A)
    max_B = np.max(B)

    exp_A = A - max_A
    np.exp(exp_A, out=exp_A)
    exp_B = B - max_B
    np.exp(exp_B, out=exp_B)

    C = np.dot(exp_A, exp_B)
    # Following scipy.special._logsumexp.py
    with np.errstate(divide='ignore'):
        np.log(C, out=C)
    C += max_A + max_B
    return C


class GMMCADFull(OutlierMixin, BaseEstimator):
    """Implementation of the GMM-CAD-Full algorithm with ARIMA integration and ensemble of adversarial attacks.

    Song, Xiuyao, et al. "Conditional anomaly detection." IEEE Transactions on
    Knowledge and Data Engineering 19.5 (2007): 631-645.
    """
    def __init__(
            self,
            num_gaussians=10,
            epsilon=0.1,
            max_iters=1000,
            random_state=None,
            patience=None,
            window_size=100,  # Adaptive thresholding parameter
            alpha=1.0,  # Tuning parameter for adaptive thresholding
            arima_order=(1, 1, 1),  # ARIMA order (p, d, q)
            ensemble_attacks=None,  # List of attack methods
            **kwargs,
    ):
        self.n_U = self.n_V = num_gaussians
        assert 0 <= epsilon <= 1
        self.epsilon = epsilon
        self.patience = patience
        self.max_iters = max_iters
        self.kwargs = kwargs
        self.arima_order = arima_order  # Store ARIMA order
        self.ensemble_attacks = ensemble_attacks if ensemble_attacks is not None else []  # Ensemble of attacks
        if not isinstance(random_state, np.random.RandomState):
            random_state = np.random.RandomState(random_state)
        self.rs = random_state

        self.d_U = self.d_V = None
        self.p_U = self.log_p_V_U = self.Z = self.U = self.V = None

        self.threshold_ = None

        # Adaptive thresholding attributes
        self.recent_scores = []
        self.window_size = window_size
        self.alpha = alpha
        self.dynamic_threshold = None

        self.arima_models = None  # Placeholder for ARIMA models

    def fit(self, X, y) -> 'GMMCADFull':
        assert X.ndim == y.ndim == 2
        assert len(X) == len(y)
        
        # Print confirmation that attacks are loaded
        print(f'{len(self.ensemble_attacks)} adversarial attacks have been instantiated successfully.')
        
        # 1. Generate adversarial examples using the ensemble of attacks
        adv_examples = []
        for attack in self.ensemble_attacks:
            adv_samples = attack.generate(X, y)
            adv_examples.append(adv_samples)
        
        adv_examples = np.concatenate(adv_examples)
        adv_labels = np.ones(len(adv_examples))  # Label adversarial examples as 1
        
        # 2. Combine original and adversarial data
        orig_labels = np.zeros(len(X))  # Label original examples as 0
        X_combined = np.concatenate([X, adv_examples])
        y_combined = np.concatenate([orig_labels, adv_labels])
        
        # 3. Shuffle the combined dataset
        shuffled_indices = np.random.permutation(len(X_combined))
        X_combined = X_combined[shuffled_indices]
        y_combined = y_combined[shuffled_indices]

        # Now, proceed with the original GMM-CAD training on the combined data
        Xy = np.concatenate([X_combined, y_combined[:, None]], axis=1)
        
        # Rest of the GMM-CAD training process
        n = len(Xy)
        self.d_U = X_combined.shape[1]
        self.d_V = 1  # Assuming the output is 1-dimensional (binary classification)

        # === Learn a set of n_U Gaussians, Z, over the dataset ===
        self.Z = GaussianMixture(
            n_components=self.n_U,
            random_state=self.rs,
            **self.kwargs,
        )
        self.Z.fit(Xy)

        # === Determine U and V ===
        p_U = self.Z.weights_

        mu_U = self.Z.means_[:, :self.d_U]
        mu_V = self.Z.means_[:, self.d_V:]

        Sigma_U = self.Z.covariances_[:, :self.d_U, :self.d_U]
        Sigma_V = self.Z.covariances_[:, self.d_V:, self.d_V:]

        self.U = [multivariate_normal(mean=mu_U_i, cov=Sigma_U_i)
                  for mu_U_i, Sigma_U_i in zip(mu_U, Sigma_U)]
        self.V = [multivariate_normal(mean=mu_V_i, cov=Sigma_V_i)
                  for mu_V_i, Sigma_V_i in zip(mu_V, Sigma_V)]

        # === Fit ARIMA models to each output dimension ===
        self.arima_models = []
        for i in range(self.d_V):
            model = ARIMA(y[:, i], order=self.arima_order)
            fitted_model = model.fit()
            self.arima_models.append(fitted_model)

        log_f_G_xU = np.asarray([U_i.logpdf(X) for U_i in self.U])
        log_f_G_yV = np.asarray([V_i.logpdf(y) for V_i in self.V])

        b_shape = (self.n_U, self.n_V, n)
        log_f_G_xU_yV = (
            np.broadcast_to(log_f_G_xU[:, None, :], b_shape) +
            np.broadcast_to(log_f_G_yV[None, :, :], b_shape)
        )
        log_f_G_xU_yV_p_U = log_f_G_xU_yV + np.log(p_U[:, None, None])

        log_f_x = logsumexp(a=log_f_G_xU, b=p_U[:, None], axis=0)

        p_V_U = self.rs.rand(self.n_U, self.n_V)
        p_V_U /= p_V_U.sum(axis=1)[:, None]
        log_p_V_U = np.log(p_V_U)

        Lambda_prev = -np.inf
        Lambda_best = log_p_V_U_best = None
        patience_count = 0
        pbar = tqdm(range(self.max_iters))
        for iter_ in pbar:
            log_b_numerator = log_f_G_xU_yV_p_U + log_p_V_U[:, :, None]
            log_b_denominator = logsumexp(a=log_b_numerator, axis=(0, 1))
            log_b = log_b_numerator - log_b_denominator[None, None, :]
            b = np.exp(log_b)

            log_b_sum_ax2 = logsumexp(log_b, axis=2)
            log_b_sum_ax12 = logsumexp(log_b, axis=(1, 2))
            log_b_sum = logsumexp(log_b, axis=(0, 1, 2))

            log_p_V_U_bar = log_b_sum_ax2 - log_b_sum_ax12[:, None]
            log_p_U_bar = log_b_sum_ax12 - log_b_sum

            Lambda = (
                (log_f_G_yV + log_p_V_U_bar[:, :, None]
                 + log_f_G_xU + log_p_U_bar[:, None, None]
                 - log_f_x[None, None, :]) * b
            ).sum()

            log_p_V_U = log_p_V_U_bar

            pbar.set_description(f'Lambda = {Lambda}')
            if Lambda < (Lambda_best or Lambda_prev):
                if self.patience and patience_count < self.patience:
                    patience_count += 1
                else:
                    print(f'Converged in {iter_ + 1} iterations (Lambda = '
                          f'{Lambda}, Lambda_prev={Lambda_prev})')
                    if log_p_V_U_best is not None:
                        log_p_V_U = log_p_V_U_best
                    break
            else:
                patience_count = 0
                log_p_V_U_best = log_p_V_U
                Lambda_best = Lambda

            Lambda_prev = Lambda
        else:
            print(f'Did not converge in {self.max_iters} iterations')

        self.log_p_V_U = log_p_V_U
        self.p_U = p_U

        scores = self.score_samples(X, y)
        scores.sort()

        thresh_idx = round(self.epsilon * len(X))
        self.threshold_ = scores[thresh_idx]

        # Initialize dynamic threshold with the computed threshold
        self.dynamic_threshold = self.threshold_

        return self

    def score_samples(self, X, y):
        # === Use ARIMA to predict the next value of y based on past values ===
        y_pred = np.zeros_like(y)
        for i, model in enumerate(self.arima_models):
            y_pred[:, i] = model.predict(start=len(y), end=len(y) + len(X) - 1)

        # === GMM-CAD scoring using ARIMA-predicted y ===
        log_f_G_xU = np.asarray([U_i.logpdf(X) for U_i in self.U])
        log_f_G_yV = np.asarray([V_i.logpdf(y_pred) for V_i in self.V])

        # shape: n_U x n
        log_p_V_U_dot_f_G_yV = logdotexp(self.log_p_V_U, log_f_G_yV)

        # shape: n_U x n
        log_p_x_in_U = log_f_G_xU + np.log(self.p_U[:, None])

        # logsumexp: log(sum(exp(a), axis=axis))
        log_f_CAD = (log_p_x_in_U + log_p_V_U_dot_f_G_yV
                     - logsumexp(a=log_p_x_in_U, axis=0))
        f_CAD = np.sum(np.exp(log_f_CAD), axis=0)

        return f_CAD

    def predict(self, X, y, ret_scores=False):
        scores = self.score_samples(X, y)

        # Update the dynamic threshold with the new scores
        self.update_dynamic_threshold(scores)

        # Use the dynamic threshold for prediction
        preds = np.ones(len(X))
        preds[scores < self.dynamic_threshold] = -1
        if ret_scores:
            return preds, scores
        return preds

    def update_dynamic_threshold(self, new_scores):
        # Update recent scores
        self.recent_scores.extend(new_scores)
        if len(self.recent_scores) > self.window_size:
            self.recent_scores = self.recent_scores[-self.window_size:]

        # Calculate mean and variance of recent scores
        if len(self.recent_scores) > 0:
            mean_score = np.mean(self.recent_scores)
            variance_score = np.var(self.recent_scores)

            # Adjust the dynamic threshold
            self.dynamic_threshold = mean_score + self.alpha * variance_score
        else:
            # Fallback to initial threshold
            self.dynamic_threshold = self.threshold_
