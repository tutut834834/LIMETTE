from unfooling.pipeline import load_data_from_pipeline  # Import the actual data loading function

def load_experiment_and_data(C):
    # Load your data using the function from pipeline.py
    P = load_data_from_pipeline(C)  # Replace with the actual function name if different

    # Sample 1% of the data
    sample_fraction = 0.01
    P.X_train = P.X_train.sample(frac=sample_fraction, random_state=42)
    P.X_test = P.X_test.sample(frac=sample_fraction, random_state=42)
    
    return P
