import pandas as pd
from ucimlrepo import fetch_ucirepo

# Fetch the Adult dataset
adult = fetch_ucirepo(id=2)

# Data (as pandas DataFrames)
X = adult.data.features
y = adult.data.targets

# Metadata
print(adult.metadata)

# Display basic statistics
print("Basic Statistics of the Adult Dataset:")
print(X.describe(include='all'))

# Display correlations
print("\nCorrelation Matrix:")
print(X.corr())

# Check value counts for categorical features
print("\nValue Counts for Categorical Features:")
for col in X.select_dtypes(include=['object']).columns:
    print(f"\nColumn: {col}")
    print(X[col].value_counts())

# Check for missing values
print("\nMissing Values in the Dataset:")
print(X.isnull().sum())
