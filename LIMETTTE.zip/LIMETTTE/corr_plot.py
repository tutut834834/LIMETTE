import torch
import numpy as np
import csv
import random
import foolbox as fb
from torchvision import models
from pprint import pprint
import scipy.stats
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector, generate_explanations, load_experiment_and_data, compute_metrics

class C:  # Config
    experiment_name = 'German'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

# Load experiment and data
P = load_experiment_and_data(C)

# Generate explanations
explainer_data = generate_explanations(
    C, P,
    num_samples_explain=max(int(0.01 * len(P.X_train)), P.X_train.shape[1] + 1)
)

# Save explainer_data to a CSV file
csv_file = 'explainer_data_german.csv'
with open(csv_file, 'w', newline='') as output_file:
    writer = csv.writer(output_file)
    for explainer, explainer_task_data in explainer_data.items():
        for task, task_data in explainer_task_data.items():
            explanations = task_data.get('explanations', [])
            for explanation in explanations:
                for feature, contribution in explanation:
                    writer.writerow([explainer, task, feature, contribution])

print(f"Explainer data saved to {csv_file}.")

# Assuming explainer_data is a dictionary structure with nested data
def gather_feature_contributions(explainer_data, state):
    feature_contributions = {}
    for explainer, explainer_task_data in explainer_data.items():
        for task, task_data in explainer_task_data.items():
            explanations = task_data.get('explanations', [])
            for explanation in explanations:
                for feature, contribution in explanation:
                    if feature not in feature_contributions:
                        feature_contributions[feature] = {}
                    if state not in feature_contributions[feature]:
                        feature_contributions[feature][state] = []
                    feature_contributions[feature][state].append(contribution)
    return feature_contributions

# Collect feature contributions before the attack, after the attack, and after defense
feature_contributions_before_attack = gather_feature_contributions(explainer_data, 'before_attack')

# Simulate an attack and gather contributions after the attack
# Note: Replace this block with your actual attack process
explainer_data_attacked = generate_explanations(
    C, P,
    num_samples_explain=max(int(0.01 * len(P.X_train)), P.X_train.shape[1] + 1)
)
feature_contributions_after_attack = gather_feature_contributions(explainer_data_attacked, 'after_attack')

# Simulate a defense and gather contributions after defense
# Note: Replace this block with your actual defense process
explainer_data_defended = generate_explanations(
    C, P,
    robustness_model=None,  # Placeholder, replace with actual defense model
    num_samples_explain=max(int(0.01 * len(P.X_train)), P.X_train.shape[1] + 1)
)
feature_contributions_after_defense = gather_feature_contributions(explainer_data_defended, 'after_defense')

# Combine all contributions into a DataFrame for easier correlation analysis
all_feature_contributions = {}
for feature in set(feature_contributions_before_attack.keys()) | set(feature_contributions_after_attack.keys()) | set(feature_contributions_after_defense.keys()):
    all_feature_contributions[feature] = {
        'before_attack': np.mean(feature_contributions_before_attack.get(feature, {}).get('before_attack', [0])),
        'after_attack': np.mean(feature_contributions_after_attack.get(feature, {}).get('after_attack', [0])),
        'after_defense': np.mean(feature_contributions_after_defense.get(feature, {}).get('after_defense', [0]))
    }

contributions_df = pd.DataFrame(all_feature_contributions).T

# Plot correlations
plt.figure(figsize=(12, 8))
sns.heatmap(contributions_df.corr(), annot=True, cmap='coolwarm', vmin=-1, vmax=1)
plt.title('Correlation of Feature Weights Before Attack, After Attack, and After Defense')
plt.show()

# Save the correlation results to a CSV file
contributions_df.to_csv('feature_contributions_correlations.csv')
print("Correlation results saved to feature_contributions_correlations.csv.")
