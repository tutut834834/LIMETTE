from pprint import pprint
import scipy.stats
import numpy as np
import pandas as pd
import subprocess

# Import the necessary modules from your pipeline
from unfooling.pipeline import evaluate_detector, generate_explanations, load_experiment_and_data, compute_metrics

# Run setup_attacks.py script
subprocess.run(["python3", "unfooling/defense/setup_attacks.py"])

class C:  # Config
    experiment_name = 'COMPAS'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

def run_experiment():
    P = load_experiment_and_data(C)
    
    explainer_data = generate_explanations(
        C, P,
        num_samples_explain=int(0.01 * len(P.X_train))  # 1% of the training samples
    )

    hparams = dict(
        distance_agg='max',
        metric='minkowski',
        epsilon=0.1,
        n_neighbors=15,
        p=1,
        n_jobs=-1,
    )
    print(f'Using hparams for {C.detector_name}:')
    pprint(hparams)

    n_explainer_samples = len(P.X_train) * 10
    print('n_explainer_samples', n_explainer_samples)
    results, detectors = evaluate_detector(C, P, explainer_data, hparams, n_explainer_samples=n_explainer_samples)

    # Process results and compute metrics
    all_metrics = {
        'fidelity_g': [],
        'infidelity_g_wrt_g': [],
        'infidelity_CAD-DEFENSE_wrt_g': [],
        'infidelity_defense': [],
        'infidelity_defense_weighted': [],
        'infidelity_defense_ratio': []
    }

    replace_strs = {
        'delta': 'Δ',
        'explainer': 'expl',
        'pct': '%',
        'threshold': 'thresh',
        'robust': 'R',
        'greater': '>',
        'under': '<',
        'normalized': 'norm',
    }

    scores = []
    for result in results:
        score = compute_metrics(result)
        for k, v in [*score.items()]:
            k_orig = k
            for a, b in replace_strs.items():
                k = k.replace(a, b)
            score[k] = score.pop(k_orig)
        score.update(
            explainer=result.meta.explainer,
            innocuous_model=result.meta.innocuous_model,
        )
        scores.append(score)

    score_df = pd.DataFrame(scores)
    
    for explainer, explainer_score_df in score_df.groupby('explainer'):
        for task, expl_score_df in explainer_score_df.groupby('innocuous_model'):
            fidelity_task = expl_score_df['cdf_Δ_expl_test'].values[0]
            print('cdf_Δ', explainer, task, fidelity_task)
            all_metrics['fidelity_g'].append(fidelity_task)

    biased_features = P.problem.biased_features
    n_feats = P.X_test.shape[1]

    for explainer, expl_expl_data in explainer_data.items():
        g0_explanations = explainer_data[explainer][None]['explanations']
        for task, expl_expl_task_data in expl_expl_data.items():
            g_explanations = expl_expl_task_data['explanations']
            err_expls = 0
            for expl_g, expl_h in zip(g0_explanations, g_explanations):
                expl_g, expl_h = dict(expl_g), dict(expl_h)
                for feat in {*expl_g.keys()} | {*expl_h.keys()}:
                    contrib_g = expl_g.get(feat, 0.)
                    contrib_h = expl_h.get(feat, 0.)
                    err_expls += (contrib_h - contrib_g) ** 2
            err_expls /= len(g_explanations) * n_feats
            print('infidelity_g_wrt_g', explainer, task, err_expls)
            all_metrics['infidelity_g_wrt_g'].append(err_expls)

    for explainer, expl_expl_data in explainer_data_defense.items():
        g_explanations = explainer_data[explainer][None]['explanations']
        for task, expl_expl_task_data in expl_expl_data.items():
            h_explanations = expl_expl_task_data['explanations']
            err_expls = 0
            for expl_g, expl_h in zip(g_explanations, h_explanations):
                expl_g, expl_h = dict(expl_g), dict(expl_h)
                for feat in {*expl_g.keys()} | {*expl_h.keys()}:
                    contrib_g = expl_g.get(feat, 0.)
                    contrib_h = expl_h.get(feat, 0.)
                    err_expls += (contrib_h - contrib_g) ** 2
            err_expls /= len(g_explanations) * n_feats
            print('infidelity_CAD-DEFENSE_wrt_g', explainer, task, err_expls)
            all_metrics['infidelity_CAD-DEFENSE_wrt_g'].append(err_expls)

    # New Metric: Defense Infidelity
    for explainer, expl_expl_data in explainer_data_defense.items():
        original_explanations = explainer_data[explainer][None]['explanations']
        for task, expl_expl_task_data in expl_expl_data.items():
            defended_explanations = expl_expl_task_data['explanations']
            assert len(original_explanations) == len(defended_explanations)
            infidelity_defense = 0
            for original, defended in zip(original_explanations, defended_explanations):
                original, defended = dict(original), dict(defended)
                for feat in set(original.keys()) | set(defended.keys()):
                    infidelity_defense += (defended.get(feat, 0) - original.get(feat, 0)) ** 2
            infidelity_defense /= len(original_explanations) * n_feats
            print('infidelity_defense', explainer, task, infidelity_defense)
            all_metrics['infidelity_defense'].append(infidelity_defense)

    # New Metric: Defense Infidelity Weighted
    for explainer, expl_expl_data in explainer_data_defense.items():
        original_explanations = explainer_data[explainer][None]['explanations']
        for task, expl_expl_task_data in expl_expl_data.items():
            defended_explanations = expl_expl_task_data['explanations']
            infidelity_defense_weighted = 0
            for original, defended in zip(original_explanations, defended_explanations):
                original, defended = dict(original), dict(defended)
                for feat in set(original.keys()) | set(defended.keys()):
                    weight = original.get(feat, 0) + defended.get(feat, 0)
                    infidelity_defense_weighted += weight * (defended.get(feat, 0) - original.get(feat, 0)) ** 2
            infidelity_defense_weighted /= len(original_explanations) * n_feats
            print('infidelity_defense_weighted', explainer, task, infidelity_defense_weighted)
            all_metrics['infidelity_defense_weighted'].append(infidelity_defense_weighted)

    # New Metric: Defense Infidelity Ratio
    for explainer, expl_expl_data in explainer_data_defense.items():
        original_explanations = explainer_data[explainer][None]['explanations']
        for task, expl_expl_task_data in expl_expl_data.items():
            defended_explanations = expl_expl_task_data['explanations']
            infidelity_defense_ratio = 0
            for original, defended in zip(original_explanations, defended_explanations):
                original, defended = dict(original), dict(defended)
                for feat in set(original.keys()) | set(defended.keys()):
                    orig_contrib = original.get(feat, 0)
                    def_contrib = defended.get(feat, 0)
                    if orig_contrib != 0:
                        infidelity_defense_ratio += (def_contrib - orig_contrib) / abs(orig_contrib)
            infidelity_defense_ratio /= len(original_explanations) * n_feats
            print('infidelity_defense_ratio', explainer, task, infidelity_defense_ratio)
            all_metrics['infidelity_defense_ratio'].append(infidelity_defense_ratio)

    return all_metrics

# Run the experiment 3 times
all_runs = []
for i in range(3):
    print(f"Running experiment {i+1}/3...")
    metrics = run_experiment()
    all_runs.append(metrics)

# Calculate averages and standard deviations
average_metrics = {}
std_metrics = {}

for key in all_runs[0]:
    all_values = np.array([run[key] for run in all_runs])
    average_metrics[key] = np.mean(all_values, axis=0)
    std_metrics[key] = np.std(all_values, axis=0)

# Print out the results
print("\nAverages across 3 runs:")
pprint(average_metrics)

print("\nStandard deviations across 3 runs:")
pprint(std_metrics)
