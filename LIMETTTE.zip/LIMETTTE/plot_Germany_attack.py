import matplotlib.pyplot as plt
import numpy as np

# Data for LIME and SHAP based on the information provided by the user
lime_data = {
    'No Attack': {
        '1st': {'Gender': 1.0},
        '2nd': {'ForeignWorker': 0.26, 'CheckingAccountBalance_geq_200': 0.13, 
                'HasCoapplicant': 0.13, 'NoCurrentLoan': 0.11, 'HasGuarantor': 0.08},
        '3rd': {'HasCoapplicant': 0.14, 'HasGuarantor': 0.12, 
                'MissedPayments': 0.10, 'NoCurrentLoan': 0.10, 'CheckingAccountBalance_geq_200': 0.08},
    },
    'Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.83, 'CheckingAccountBalance_geq_200': 0.04, 
                'Unemployed': 0.03, 'ForeignWorker': 0.02, 'HasCoapplicant': 0.02},
        '2nd': {'ForeignWorker': 0.20, 'SavingsAccountBalance_geq_500': 0.12, 
                'HasCoapplicant': 0.10, 'Unemployed': 0.10, 'CheckingAccountBalance_geq_200': 0.09},
        '3rd': {'HasGuarantor': 0.14, 'Unemployed': 0.11, 'NoCurrentLoan': 0.10, 
                'HasCoapplicant': 0.09, 'CheckingAccountBalance_geq_200': 0.08},
    }
}

shap_data = {
    'No Attack': {
        '1st': {'Gender': 1.0},
        '2nd': {'Nothing shown': 1.0},
        '3rd': {'Nothing shown': 1.0},
    },
    'Attack 1': {
        '1st': {'LoanRateAsPercentOfIncome': 0.78, 'Gender': 0.14, 'LoanAmount': 0.05, 'Age': 0.01, 'NoCurrentLoan': 0.01},
        '2nd': {'Gender': 0.39, 'LoanAmount': 0.13, 'LoanRateAsPercentOfIncome': 0.13, 
                'YearsAtCurrentHome': 0.10, 'LoanDuration': 0.09},
        '3rd': {'LoanDuration': 0.18, 'Single': 0.18, 'LoanAmount': 0.10, 
                'Age': 0.08, 'Gender': 0.08},
    }
}

# Colors for features
colors = {
    'Gender': '#FF7F0E',
    'ForeignWorker': '#1F77B4',
    'CheckingAccountBalance_geq_200': '#AEC7E8',
    'HasCoapplicant': '#FF9896',
    'NoCurrentLoan': '#98DF8A',
    'HasGuarantor': '#C49C94',
    'MissedPayments': '#9467BD',
    'LoanRateAsPercentOfIncome': '#C5B0D5',
    'Unemployed': '#8C564B',
    'SavingsAccountBalance_geq_500': '#E377C2',
    'LoanAmount': '#D62728',
    'Age': '#C7C7C7',
    'Nothing shown': '#BCBD22',
    'YearsAtCurrentHome': '#17BECF',
    'LoanDuration': '#9edae5',
    'Single': '#dbdb8d'
}

# Plotting function
def plot_bar(ax, data, title):
    categories = ['1st', '2nd', '3rd']
    for i, category in enumerate(categories):
        labels = list(data[category].keys())
        values = list(data[category].values())
        bottoms = np.cumsum([0] + values[:-1])
        for j, (val, label) in enumerate(zip(values, labels)):
            ax.barh(category, val * 100, left=bottoms[j] * 100, color=colors[label], edgecolor='black')
    ax.set_title(title)
    ax.set_xlim(0, 100)
    ax.set_xticks(np.arange(0, 101, 20))
    ax.set_xlabel('% Occurrence')
    ax.set_ylabel('Rank')

# Create the plots for LIME and SHAP
fig, axs = plt.subplots(2, 2, figsize=(14, 10))

plot_bar(axs[0, 0], lime_data['No Attack'], 'LIME: No Attack')
plot_bar(axs[0, 1], lime_data['Attack 1'], 'LIME: Attack 1')

plot_bar(axs[1, 0], shap_data['No Attack'], 'SHAP: No Attack')
plot_bar(axs[1, 1], shap_data['Attack 1'], 'SHAP: Attack 1')

# Adding the legend
handles = [plt.Rectangle((0,0),1,1, color=colors[label]) for label in colors]
labels = list(colors.keys())
fig.legend(handles, labels, loc='upper center', ncol=4, bbox_to_anchor=(0.5, -0.1))

plt.tight_layout()
plt.show()
