from pprint import pprint
import scipy.stats
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use the Agg backend for rendering

import matplotlib.pyplot as plt
import pandas as pd

from unfooling.pipeline import evaluate_detector
from unfooling.pipeline import generate_explanations
from unfooling.pipeline import load_experiment_and_data
from unfooling.pipeline import compute_metrics, ProcessedProblem

class C:  # Config
    experiment_name = 'COMPAS'
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

n_train_proportions = [0.1, 0.2, 0.4, 0.6, 0.8, 1.0]  # Different portions of the training set

# Lists to store fidelity results
fidelity_h_LIME_no_attack = []
fidelity_h_LIME_attack = []
fidelity_h_SHAP_no_attack = []
fidelity_h_SHAP_attack = []

for prop in n_train_proportions:
    print(f"Running experiment with {int(prop*100)}% of the training data...")

    # Load the experiment data
    P = load_experiment_and_data(C)
    
    # Manually resize the training data
    num_train_samples = int(prop * len(P.X_train))
    X_train_resized = P.X_train[:num_train_samples]
    y_train_resized = P.y_train[:num_train_samples]

    # Create a new ProcessedProblem instance with the resized training data
    P_resized = ProcessedProblem(
        P.problem, 
        P.features, 
        P.categorical_features, 
        P.categorical_feature_idxs, 
        P.prejudiced_model, 
        P.innocuous_models, 
        X_train_resized, 
        P.X_test, 
        y_train_resized, 
        P.y_test
    )

    # Ensure that the number of samples for SHAP explanations is sufficient
    num_samples_explain = max(int(0.01 * num_train_samples), len(P.features) + 10)

    # Generate explanations with the resized training data
    explainer_data = generate_explanations(
        C, 
        P_resized,
        num_samples_explain=num_samples_explain  # Ensure sufficient samples
    )

    C.detector_name = 'KNNCAD'
    hparams = dict(
        distance_agg='max',
        metric='minkowski',
        epsilon=0.1,
        n_neighbors=15,
        p=1,
        n_jobs=-1,
    )
    print(f'Using hparams for {C.detector_name}:')
    pprint(hparams)

    n_explainer_samples = num_train_samples * 10
    print('n_explainer_samples', n_explainer_samples)
    results, detectors = evaluate_detector(C, P_resized, explainer_data, hparams,
                                           n_explainer_samples=n_explainer_samples)

    scores = []
    for result in results:
        score = compute_metrics(result)
        score.update(
            explainer=result.meta.explainer,
            innocuous_model=result.meta.innocuous_model,
            n_train=prop
        )
        scores.append(score)

    score_df = pd.DataFrame(scores)

   # Rest of the code remains unchanged

for explainer, explainer_score_df in score_df.groupby('explainer'):
    for task, expl_score_df in explainer_score_df.groupby('innocuous_model'):
        # Print available columns for debugging
        print(f"Available columns in expl_score_df for explainer '{explainer}' and task '{task}':")
        print(expl_score_df.columns)

        # Attempt to retrieve fidelity_h, but if it doesn't exist, list all available columns
        try:
            fidelity_h_value = expl_score_df['fidelity_h'].values[0]
        except KeyError as e:
            print(f"KeyError: {e}. Available columns: {expl_score_df.columns}")
            continue  # Skip this loop iteration if the key is not found

        if explainer == 'LIME':
            if task == 'NA':  # No attack scenario
                fidelity_h_LIME_no_attack.append(fidelity_h_value)
            else:  # Attack scenario
                fidelity_h_LIME_attack.append(fidelity_h_value)
        elif explainer == 'SHAP':
            if task == 'NA':  # No attack scenario
                fidelity_h_SHAP_no_attack.append(fidelity_h_value)
            else:  # Attack scenario
                fidelity_h_SHAP_attack.append(fidelity_h_value)

# Plotting the results
plt.figure(figsize=(12, 5))

# Plot for LIME
plt.subplot(1, 2, 1)
plt.plot(n_train_proportions, fidelity_h_LIME_no_attack, label='No Attack', color='blue', linestyle='-', marker='o')
plt.plot(n_train_proportions, fidelity_h_LIME_attack, label='Attack', color='orange', linestyle='--', marker='o')
plt.title('Explainer = LIME')
plt.xlabel('n_train')
plt.ylabel('fidelity_h')
plt.ylim(0.7, 1.0)
plt.legend()

# Plot for SHAP
plt.subplot(1, 2, 2)
plt.plot(n_train_proportions, fidelity_h_SHAP_no_attack, label='No Attack', color='blue', linestyle='-', marker='o')
plt.plot(n_train_proportions, fidelity_h_SHAP_attack, label='Attack', color='orange', linestyle='--', marker='o')
plt.title('Explainer = SHAP')
plt.xlabel('n_train')
plt.ylabel('fidelity_h')
plt.ylim(0.7, 1.0)
plt.legend()

plt.tight_layout()
plt.show()



#        'cdf_delta_ratio_test_train', 'peak_deltas_explainer',
#        'peak_deltas_test', 'peak_deltas_train', 'under_threshold_explainer',
#        'under_threshold_test', 'under_threshold_train', 'explainer',
#        'innocuous_model', 'n_train'],
#       dtype='object')
# Available columns in expl_score_df for explainer 'SHAP' and task 'NA':
# Index(['cdf_delta_explainer_test_robust_normalized',
#        'cdf_area_explainer_robust_normalized',
#        'cdf_area_test_robust_normalized',
#        'pct_cdf_greater_explainer_test_robust_normalized',
#        'cdf_area_above_explainer_test_robust_normalized',
#        'cdf_delta_ratio_explainer_test_robust_normalized',
#        'cdf_delta_explainer_test_robust', 'cdf_area_explainer_robust',
#        'cdf_area_test_robust', 'pct_cdf_greater_explainer_test_robust',
#        'cdf_area_above_explainer_test_robust',
#        'cdf_delta_ratio_explainer_test_robust',
#        'cdf_delta_explainer_test_normalized', 'cdf_area_explainer_normalized',
#        'cdf_area_test_normalized', 'pct_cdf_greater_explainer_test_normalized',
#        'cdf_area_above_explainer_test_normalized',
#        'cdf_delta_ratio_explainer_test_normalized', 'cdf_delta_explainer_test',
#        'cdf_area_explainer', 'cdf_area_test', 'pct_cdf_greater_explainer_test',
#        'cdf_area_above_explainer_test', 'cdf_delta_ratio_explainer_test',
#        'cdf_delta_explainer_train_robust_normalized',
#        'cdf_area_train_robust_normalized',
#        'pct_cdf_greater_explainer_train_robust_normalized',
#        'cdf_area_above_explainer_train_robust_normalized',
#        'cdf_delta_ratio_explainer_train_robust_normalized',
#        'cdf_delta_explainer_train_robust', 'cdf_area_train_robust',
#        'pct_cdf_greater_explainer_train_robust',
#        'cdf_area_above_explainer_train_robust',
#        'cdf_delta_ratio_explainer_train_robust',
#        'cdf_delta_explainer_train_normalized', 'cdf_area_train_normalized',
#        'pct_cdf_greater_explainer_train_normalized',
#        'cdf_area_above_explainer_train_normalized',
#        'cdf_delta_ratio_explainer_train_normalized',
#        'cdf_delta_explainer_train', 'cdf_area_train',
#        'pct_cdf_greater_explainer_train', 'cdf_area_above_explainer_train',
#        'cdf_delta_ratio_explainer_train',
#        'cdf_delta_test_train_robust_normalized',
#        'pct_cdf_greater_test_train_robust_normalized',
#        'cdf_area_above_test_train_robust_normalized',
#        'cdf_delta_ratio_test_train_robust_normalized',
#        'cdf_delta_test_train_robust', 'pct_cdf_greater_test_train_robust',
#        'cdf_area_above_test_train_robust', 'cdf_delta_ratio_test_train_robust',
#        'cdf_delta_test_train_normalized',
#        'pct_cdf_greater_test_train_normalized',
#        'cdf_area_above_test_train_normalized',
#        'cdf_delta_ratio_test_train_normalized', 'cdf_delta_test_train',
#        'pct_cdf_greater_test_train', 'cdf_area_above_test_train',
#        'cdf_delta_ratio_test_train', 'peak_deltas_explainer',
#        'peak_deltas_test', 'peak_deltas_train', 'under_threshold_explainer',
#        'under_threshold_test', 'under_threshold_train', 'explainer',
#        'innocuous_model', 'n_train'],
#       dtype='object')
# KeyError: 'fidelity_h'. Available columns: Index(['cdf_delta_explainer_test_robust_normalized',
#        'cdf_area_explainer_robust_normalized',
#        'cdf_area_test_robust_normalized',
#        'pct_cdf_greater_explainer_test_robust_normalized',
#        'cdf_area_above_explainer_test_robust_normalized',
#        'cdf_delta_ratio_explainer_test_robust_normalized',
#        'cdf_delta_explainer_test_robust', 'cdf_area_explainer_robust',
#        'cdf_area_test_robust', 'pct_cdf_greater_explainer_test_robust',
#        'cdf_area_above_explainer_test_robust',
#        'cdf_delta_ratio_explainer_test_robust',
#        'cdf_delta_explainer_test_normalized', 'cdf_area_explainer_normalized',
#        'cdf_area_test_normalized', 'pct_cdf_greater_explainer_test_normalized',
#        'cdf_area_above_explainer_test_normalized',
#        'cdf_delta_ratio_explainer_test_normalized', 'cdf_delta_explainer_test',
#        'cdf_area_explainer', 'cdf_area_test', 'pct_cdf_greater_explainer_test',
#        'cdf_area_above_explainer_test', 'cdf_delta_ratio_explainer_test',
#        'cdf_delta_explainer_train_robust_normalized',
#        'cdf_area_train_robust_normalized',
#        'pct_cdf_greater_explainer_train_robust_normalized',
#        'cdf_area_above_explainer_train_robust_normalized',
#        'cdf_delta_ratio_explainer_train_robust_normalized',
#        'cdf_delta_explainer_train_robust', 'cdf_area_train_robust',
#        'pct_cdf_greater_explainer_train_robust',
#        'cdf_area_above_explainer_train_robust',
#        'cdf_delta_ratio_explainer_train_robust',
#        'cdf_delta_explainer_train_normalized', 'cdf_area_train_normalized',
#        'pct_cdf_greater_explainer_train_normalized',
#        'cdf_area_above_explainer_train_normalized',
#        'cdf_delta_ratio_explainer_train_normalized',
#        'cdf_delta_explainer_train', 'cdf_area_train',
#        'pct_cdf_greater_explainer_train', 'cdf_area_above_explainer_train',
#        'cdf_delta_ratio_explainer_train',
#        'cdf_delta_test_train_robust_normalized',
#        'pct_cdf_greater_test_train_robust_normalized',
#        'cdf_area_above_test_train_robust_normalized',
#        'cdf_delta_ratio_test_train_robust_normalized',
#        'cdf_delta_test_train_robust', 'pct_cdf_greater_test_train_robust',
#        'cdf_area_above_test_train_robust', 'cdf_delta_ratio_test_train_robust',
#        'cdf_delta_test_train_normalized',
#        'pct_cdf_greater_test_train_normalized',
#        'cdf_area_above_test_train_normalized',
#        'cdf_delta_ratio_test_train_normalized', 'cdf_delta_test_train',
#        'pct_cdf_greater_test_train', 'cdf_area_above_test_train',
#        'cdf_delta_ratio_test_train', 'peak_deltas_explainer',
#        'peak_deltas_test', 'peak_deltas_train', 'under_threshold_explainer',
#        'under_threshold_test', 'under_threshold_train', 'explainer',
#        'innocuous_model', 'n_train'],
#       dtype='object')
# Traceback (most recent call last):
#   File "/home/diodesama/Documents/Thesis/unfooling/plot_graphs.py", line 118, in <module>
#     plt.figure(figsize=(12, 5))
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/pyplot.py", line 1022, in figure
#     manager = new_figure_manager(
#               ^^^^^^^^^^^^^^^^^^^
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/pyplot.py", line 544, in new_figure_manager
#     _warn_if_gui_out_of_main_thread()
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/pyplot.py", line 521, in _warn_if_gui_out_of_main_thread
#     canvas_class = cast(type[FigureCanvasBase], _get_backend_mod().FigureCanvas)
#                                                 ^^^^^^^^^^^^^^^^^^
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/pyplot.py", line 353, in _get_backend_mod
#     switch_backend(rcParams._get("backend"))
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/pyplot.py", line 395, in switch_backend
#     switch_backend(candidate)
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/pyplot.py", line 410, in switch_backend
#     module = backend_registry.load_backend_module(newbackend)
#              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/backends/registry.py", line 316, in load_backend_module
#     return importlib.import_module(module_name)
#            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#   File "/usr/lib/python3.11/importlib/__init__.py", line 126, in import_module
#     return _bootstrap._gcd_import(name[level:], package, level)
#            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#   File "<frozen importlib._bootstrap>", line 1204, in _gcd_import
#   File "<frozen importlib._bootstrap>", line 1176, in _find_and_load
#   File "<frozen importlib._bootstrap>", line 1147, in _find_and_load_unlocked
#   File "<frozen importlib._bootstrap>", line 690, in _load_unlocked
#   File "<frozen importlib._bootstrap_external>", line 940, in exec_module
#   File "<frozen importlib._bootstrap>", line 241, in _call_with_frames_removed
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/backends/backend_gtk4agg.py", line 4, in <module>
#     from . import backend_agg, backend_gtk4
#   File "/var/data/python/lib/python3.11/site-packages/matplotlib/backends/backend_gtk4.py", line 19, in <module>
#     gi.require_version("Gtk", "4.0")
#     ^^^^^^^^^^^^^^^^^^
# AttributeError: module 'gi' has no attribute 'require_version'
# sh-5.2$ 