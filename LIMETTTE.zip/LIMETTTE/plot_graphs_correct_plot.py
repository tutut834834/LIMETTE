import matplotlib
matplotlib.use('Agg')  # Use a non-GUI backend to avoid the GTK error

import matplotlib.pyplot as plt
from pprint import pprint
import numpy as np
import pandas as pd

from unfooling.pipeline import evaluate_detector, generate_explanations, load_experiment_and_data, compute_metrics, ProcessedProblem

class C:  # Config
    experiment_name = 'COMPAS'  # Adjust to 'CC' if using Communities and Crime
    detector_name = 'KNNCAD'
    detect_proba = False
    test_size = 0.1
    debug = False

n_train_proportions = [0.1, 0.2, 0.4, 0.6, 0.8, 1.0]  # Different portions of the training set

# Lists to store fidelity results
fidelity_h_LIME_no_attack = []
fidelity_h_LIME_attack = []
fidelity_h_SHAP_no_attack = []
fidelity_h_SHAP_attack = []

for prop in n_train_proportions:
    print(f"\nRunning experiment with {int(prop*100)}% of the training data...")

    # Load the experiment data
    P = load_experiment_and_data(C)
    
    # Manually resize the training data
    num_train_samples = int(prop * len(P.X_train))
    X_train_resized = P.X_train[:num_train_samples]
    y_train_resized = P.y_train[:num_train_samples]

    # Create a new ProcessedProblem instance with the resized training data
    P_resized = ProcessedProblem(
        P.problem, 
        P.features, 
        P.categorical_features, 
        P.categorical_feature_idxs, 
        P.prejudiced_model, 
        P.innocuous_models, 
        X_train_resized, 
        P.X_test, 
        y_train_resized, 
        P.y_test
    )

    # Ensure that the number of samples for SHAP explanations is sufficient
    num_samples_explain = max(int(0.01 * num_train_samples), len(P.features) + 10)

    # Generate explanations with the resized training data
    explainer_data = generate_explanations(
        C, 
        P_resized,
        num_samples_explain=num_samples_explain  # Ensure sufficient samples
    )

    C.detector_name = 'KNNCAD'
    hparams = dict(
        distance_agg='max',
        metric='minkowski',
        epsilon=0.1,
        n_neighbors=15,
        p=1,
        n_jobs=-1,
    )
    print(f'Using hparams for {C.detector_name}:')
    pprint(hparams)

    n_explainer_samples = num_train_samples * 10
    print('n_explainer_samples', n_explainer_samples)
    results, detectors = evaluate_detector(C, P_resized, explainer_data, hparams,
                                           n_explainer_samples=n_explainer_samples)

    scores = []
    for result in results:
        score = compute_metrics(result)
        score.update(
            explainer=result.meta.explainer,
            innocuous_model=result.meta.innocuous_model,
            n_train=prop
        )
        scores.append(score)

    score_df = pd.DataFrame(scores)

    # Replace `fidelity_h` with an available metric, for example:
    metric_to_use = 'cdf_delta_explainer_test_robust_normalized'

    for explainer, explainer_score_df in score_df.groupby('explainer'):
        for task, expl_score_df in explainer_score_df.groupby('innocuous_model'):
            print(f"\nAvailable columns in expl_score_df for explainer '{explainer}' and task '{task}':")
            print(expl_score_df.columns)

            try:
                fidelity_h_value = expl_score_df[metric_to_use].values[0]
                print(f"Calculated fidelity_h_value: {fidelity_h_value}")
            except KeyError as e:
                print(f"KeyError: {e}. Available columns: {expl_score_df.columns}")
                continue  # Skip this loop iteration if the key is not found

            if explainer == 'LIME':
                if task == 'NA':  # No attack scenario
                    fidelity_h_LIME_no_attack.append(fidelity_h_value)
                    print(f"fidelity_h_LIME_no_attack updated: {fidelity_h_LIME_no_attack}")
                else:  # Attack scenario
                    fidelity_h_LIME_attack.append(fidelity_h_value)
                    print(f"fidelity_h_LIME_attack updated: {fidelity_h_LIME_attack}")
            elif explainer == 'SHAP':
                if task == 'NA':  # No attack scenario
                    fidelity_h_SHAP_no_attack.append(fidelity_h_value)
                    print(f"fidelity_h_SHAP_no_attack updated: {fidelity_h_SHAP_no_attack}")
                else:  # Attack scenario
                    fidelity_h_SHAP_attack.append(fidelity_h_value)
                    print(f"fidelity_h_SHAP_attack updated: {fidelity_h_SHAP_attack}")

# Function to ensure lists are of equal length
def adjust_lengths(reference_list, target_list, fill_value=np.nan):
    """
    Ensures that `target_list` has the same length as `reference_list` by filling it with `fill_value`.
    If `target_list` is longer, trim it to match the length of `reference_list`.
    """
    if len(reference_list) > len(target_list):
        target_list.extend([fill_value] * (len(reference_list) - len(target_list)))
    elif len(target_list) > len(reference_list):
        target_list = target_list[:len(reference_list)]
    return target_list

# Ensure that the lists have values before plotting
if fidelity_h_LIME_no_attack and fidelity_h_LIME_attack and fidelity_h_SHAP_no_attack and fidelity_h_SHAP_attack:
    # Adjust lengths to make sure all lists match n_train_proportions
    fidelity_h_LIME_no_attack = adjust_lengths(n_train_proportions, fidelity_h_LIME_no_attack)
    fidelity_h_LIME_attack = adjust_lengths(n_train_proportions, fidelity_h_LIME_attack)
    fidelity_h_SHAP_no_attack = adjust_lengths(n_train_proportions, fidelity_h_SHAP_no_attack)
    fidelity_h_SHAP_attack = adjust_lengths(n_train_proportions, fidelity_h_SHAP_attack)
    
    print("\nFinal fidelity_h_LIME_no_attack:", fidelity_h_LIME_no_attack)
    print("Final fidelity_h_LIME_attack:", fidelity_h_LIME_attack)
    print("Final fidelity_h_SHAP_no_attack:", fidelity_h_SHAP_no_attack)
    print("Final fidelity_h_SHAP_attack:", fidelity_h_SHAP_attack)

    plt.figure(figsize=(12, 5))

    # Plot for LIME
    plt.subplot(1, 2, 1)
    plt.plot(n_train_proportions, fidelity_h_LIME_no_attack, label='No Attack', color='blue', linestyle='-', marker='o')
    plt.plot(n_train_proportions, fidelity_h_LIME_attack, label='Attack', color='orange', linestyle='--', marker='o')
    plt.title('Explainer = LIME')
    plt.xlabel('n_train')
    plt.ylabel('fidelity_h')
    # Temporarily remove the ylim constraint to see if data falls outside this range
    # plt.ylim(0.7, 1.0)
    plt.legend()

    # Plot for SHAP
    plt.subplot(1, 2, 2)
    plt.plot(n_train_proportions, fidelity_h_SHAP_no_attack, label='No Attack', color='blue', linestyle='-', marker='o')
    plt.plot(n_train_proportions, fidelity_h_SHAP_attack, label='Attack', color='orange', linestyle='--', marker='o')
    plt.title('Explainer = SHAP')
    plt.xlabel('n_train')
    plt.ylabel('fidelity_h')
    # Temporarily remove the ylim constraint to see if data falls outside this range
    # plt.ylim(0.7, 1.0)
    plt.legend()

    plt.tight_layout()

    # Save the figure instead of showing it
    plt.savefig('fidelity_h_plots.png')
    print("Plot saved as 'fidelity_h_plots.png'")
else:
    print("No data available for plotting.")
