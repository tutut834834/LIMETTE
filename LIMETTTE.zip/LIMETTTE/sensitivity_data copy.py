import pandas as pd
from scipy.stats import chi2_contingency, ttest_ind
from ucimlrepo import fetch_ucirepo

# Dataset 1: Adult
adult = fetch_ucirepo(id=2)
X_adult = adult.data.features
y_adult = adult.data.targets

# Check sensitivity for the 'race' feature in the Adult dataset
contingency_table_adult = pd.crosstab(X_adult['race'], y_adult.iloc[:, 0])
chi2_stat_adult, p_adult, _, _ = chi2_contingency(contingency_table_adult)
print(f"The feature 'race in Adult' is likely a sensitive feature (p-value: {p_adult:.4f})." if p_adult < 0.05 else f"The feature 'race in Adult' is not likely a sensitive feature (p-value: {p_adult:.4f}).")

# Dataset 2: Bank Marketing
bank_marketing = fetch_ucirepo(id=222)
X_bank = bank_marketing.data.features
y_bank = bank_marketing.data.targets

# Check sensitivity for the 'age' feature in the Bank Marketing dataset
contingency_table_bank = pd.crosstab(X_bank['age'], y_bank.iloc[:, 0])
chi2_stat_bank, p_bank, _, _ = chi2_contingency(contingency_table_bank)
print(f"The feature 'age in Bank Marketing' is likely a sensitive feature (p-value: {p_bank:.4f})." if p_bank < 0.05 else f"The feature 'age in Bank Marketing' is not likely a sensitive feature (p-value: {p_bank:.4f}).")

# Dataset 3: Diabetes 130-US Hospitals
diabetes = fetch_ucirepo(id=296)
X_diabetes = diabetes.data.features
y_diabetes = diabetes.data.targets

# Check sensitivity for the 'race' feature in the Diabetes dataset
contingency_table_diabetes = pd.crosstab(X_diabetes['race'], y_diabetes.iloc[:, 0])
chi2_stat_diabetes, p_diabetes, _, _ = chi2_contingency(contingency_table_diabetes)
print(f"The feature 'race in Diabetes' is likely a sensitive feature (p-value: {p_diabetes:.4f})." if p_diabetes < 0.05 else f"The feature 'race in Diabetes' is not likely a sensitive feature (p-value: {p_diabetes:.4f}).")
