import foolbox as fb
import torch
from torchvision import models
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import csv

# Check for GPU availability
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Load model and data
model = models.resnet18(weights='DEFAULT').eval().to(device)
fmodel = fb.PyTorchModel(model, bounds=(0, 1))

# Function to generate synthetic images
def generate_synthetic_images(n):
    return [torch.rand((1, 3, 224, 224)).to(device) for _ in range(n)]

# Define a larger range of epsilon values for the attack
epsilons = np.linspace(0.01, 0.3, num=20)

# Initialize a dictionary to store results for each attack
results = []

# List of attacks to perform
attacks = {
    'FGSM': fb.attacks.FGSM(),
    'BIM': fb.attacks.LinfBasicIterativeAttack(),
    'PGD': fb.attacks.PGD(),
    'L2PGD': fb.attacks.L2PGD(),
    'DeepFool': fb.attacks.L2DeepFoolAttack(),
    'Spatial': fb.attacks.SpatialAttack(),
}

# Perform the attacks
for synthetic_image in generate_synthetic_images(10):  # Generate 10 synthetic images
    label = torch.tensor([1]).to(device)
    
    for attack_name, attack in attacks.items():
        print(f"Running {attack_name} attack...")
        
        for epsilon in epsilons:
            adversarial = attack(fmodel, synthetic_image, label, epsilons=[epsilon])
            adversarial_image = adversarial[0][0]
            if adversarial_image.dim() == 3:
                adversarial_image = adversarial_image.unsqueeze(0)
            
            adversarial_image = adversarial_image.to(device)
            
            with torch.no_grad():
                logits = model(adversarial_image)
                predicted_class = torch.argmax(logits, dim=1)
                success_rate = (predicted_class != label).float().mean().item()
            
            perturbation = adversarial_image - synthetic_image
            perturbation_magnitude = perturbation.norm().item()
            model_confidence = torch.max(torch.softmax(logits, dim=1)).item()
            
            results.append({
                'Attack': attack_name,
                'Epsilon': epsilon,
                'SuccessRate': success_rate,
                'PerturbationMagnitude': perturbation_magnitude,
                'ModelConfidence': model_confidence
            })

# Save results to CSV
csv_file = 'attack_results.csv'
keys = results[0].keys()
with open(csv_file, 'w', newline='') as output_file:
    dict_writer = csv.DictWriter(output_file, fieldnames=keys)
    dict_writer.writeheader()
    dict_writer.writerows(results)

print(f"Attack results saved to {csv_file}.")
